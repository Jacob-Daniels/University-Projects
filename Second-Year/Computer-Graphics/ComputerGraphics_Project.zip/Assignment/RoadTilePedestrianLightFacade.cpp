#include "RoadTilePedestrianLightFacade.h"
#include "PedestrianTrafficLightFacade.h"
#include "SelectionHandler.h"

Assignment::RoadTilePedestrianLightFacade::RoadTilePedestrianLightFacade(std::string sName, osg::Node* pAsset, osg::Matrixf m, bool bVisible) : TrafficSystem::RoadFacade(sName, pAsset, m, bVisible), m_uiCount(0), m_itCurrentPLight(m_plLights.end())
{
	// Set the callback loop to the matrix transform (Unique to this instance)
	m_pTransformation->setUpdateCallback(this);

	m_pRoot->setUserData(new Assignment::SelectionHandler(this));
}

Assignment::RoadTilePedestrianLightFacade::~RoadTilePedestrianLightFacade()
{
}

void Assignment::RoadTilePedestrianLightFacade::addLight(PedestrianTrafficLightFacade* pPTL)
{
	// Assign the traffic lights parent (road tile)
	pPTL->setRoadTileParent(this);

	// Add the traffic light to the list (can then be looped to change the state)
	m_plLights.push_back(pPTL);
	m_pTransformation->addChild(pPTL->root());

	pPTL->setState(PedestrianTrafficLightFacade::STOP);
}

void Assignment::RoadTilePedestrianLightFacade::toggleState()
{
	// Return if tile doesn't contain pedestrian traffic lights
	if (m_plLights.empty()) return;

	// Set the timer for the pedestrian light
	if ((*m_plLights.begin())->getState() == PedestrianTrafficLightFacade::GO) m_uiCount = 400;
	else m_uiCount = 0;
}

bool Assignment::RoadTilePedestrianLightFacade::run(osg::Object* object, osg::Object* data)
{
	// Simple timer to change pedestrian light state
	if (m_uiCount >= 0)
	{
		if (m_uiCount == 400)
		{
			m_itCurrentPLight = m_plLights.begin();
			while (m_itCurrentPLight != m_plLights.end()) {
				(*m_itCurrentPLight)->setPedestrianState(PedestrianTrafficLightFacade::SLOW, data);

				m_itCurrentPLight++;
			}
		}
		else if (m_uiCount == 350)
		{
			m_itCurrentPLight = m_plLights.begin();
			while (m_itCurrentPLight != m_plLights.end()) {
				(*m_itCurrentPLight)->setPedestrianState(PedestrianTrafficLightFacade::STOP, data);
				m_itCurrentPLight++;
			}
		}
		else if (m_uiCount == 50)
		{
			m_itCurrentPLight = m_plLights.begin();
			while (m_itCurrentPLight != m_plLights.end()) {
				(*m_itCurrentPLight)->setPedestrianState(PedestrianTrafficLightFacade::READY, data);
				m_itCurrentPLight++;
			}
		}
		else if (m_uiCount == 0) {
			m_itCurrentPLight = m_plLights.begin();
			while (m_itCurrentPLight != m_plLights.end()) {
				(*m_itCurrentPLight)->setPedestrianState(PedestrianTrafficLightFacade::GO, data);
				m_itCurrentPLight++;
			}
		}
		m_uiCount--;
	}
	return false;
}
