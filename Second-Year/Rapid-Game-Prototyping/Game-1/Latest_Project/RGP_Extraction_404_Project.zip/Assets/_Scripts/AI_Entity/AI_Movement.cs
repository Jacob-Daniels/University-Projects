using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AI_Movement : MonoBehaviour
{
    public Rigidbody2D rb;
    public float speed = 5f;
    public bool grounded;

    private void Update()
    {
        // Move AI horizontally
        transform.position += new Vector3(speed * Time.deltaTime, 0, 0);

        // Limit Velocity
        // Max X velocity
        if (rb.velocity.x > 15)
        {
            rb.velocity = new Vector2(15, rb.velocity.y);
        }
        else if (rb.velocity.x < -15)
        {
            rb.velocity = new Vector2(-15, rb.velocity.y);
        }
        // Max Y velocity
        if (rb.velocity.y > 15)
        {
            rb.velocity = new Vector2(rb.velocity.x, 15);
        }
        else if (rb.velocity.y < -15)
        {
            rb.velocity = new Vector2(rb.velocity.x, -15);
        }
    }

    public void ReverseDirection()
    {
        // Reverse/flip direction of entity
        speed *= -1;
        transform.localScale = new Vector3(transform.localScale.x * -1, transform.localScale.y, transform.localScale.z);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        // Colliding with wall whilst grounded
        if (collision.gameObject.tag == "Wall")
        {
            ReverseDirection();
        }
        // Grounded
        if (collision.gameObject.tag == "Ground")
        {
            grounded = true;
        }
        // Other entity collision
        if (collision.gameObject.tag == "AIEntity")
        {
            Physics2D.IgnoreCollision(collision.collider, GetComponent<Collider2D>());
        }
        // End (Delete object)
        if (collision.gameObject.tag == "Finish")
        {
            Destroy(gameObject);
            AI_Manager.instance.IncreaseSavedAI();
        }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        // Not grounded
        if (collision.gameObject.tag == "Ground")
        {
            grounded = false;
        }
    }
}