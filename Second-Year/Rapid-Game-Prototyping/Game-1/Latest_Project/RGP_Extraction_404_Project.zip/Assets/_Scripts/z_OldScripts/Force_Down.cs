using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Force_Down : MonoBehaviour
{
    public float force = 15f;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "AIEntity")
        {
            // Apply force
            collision.gameObject.GetComponent<Rigidbody2D>().AddForce(transform.up * -force, ForceMode2D.Impulse);
        }
    }
}
