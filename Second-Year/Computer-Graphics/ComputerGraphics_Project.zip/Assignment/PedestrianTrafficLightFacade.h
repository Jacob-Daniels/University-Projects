#pragma once

#include <windows.h>
#include <osg/Material>
#include <TrafficSystem/TrafficLightFacade.h>
#include "ControllableTrafficLightFacade.h"
#include "RoadTilePedestrianLightFacade.h"

// Enable the walk shader -> This removes the background and applies a lighting to the "icon/pedestrian"
#define WALK_SHADER

namespace Assignment {
	class RoadTilePedestrianLightFacade;

	class PedestrianTrafficLightFacade : public Assignment::ControllableTrafficLightFacade
	{
	public:
		PedestrianTrafficLightFacade(std::string sName, osg::Node* pAsset, osg::Matrixf m, bool bVisible);
		virtual ~PedestrianTrafficLightFacade();

		void setPedestrianState(LightState eState, osg::Object* data);

		RoadTilePedestrianLightFacade* getRoadTileParent();
		void setRoadTileParent(RoadTilePedestrianLightFacade* pPRT);

	protected:
		osg::MatrixTransform* m_pSelectTransform;
		unsigned int m_uiCount;
		RoadTilePedestrianLightFacade* m_pParentRoadTile;

#ifdef WALK_SHADER
		osg::Uniform* m_pWalkTimeUniform;
		osg::Uniform* m_pWalkStateUniform;
#else
		osg::Switch* m_pTextureSwitch;
#endif
	};
}
