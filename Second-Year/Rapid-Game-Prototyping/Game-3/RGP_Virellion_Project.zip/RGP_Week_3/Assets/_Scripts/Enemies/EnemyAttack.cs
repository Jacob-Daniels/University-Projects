using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyAttack : MonoBehaviour
{
    [Header("Bullet Properties:")]
    [SerializeField] private GameObject bulletPrefab;
    [SerializeField] private int[] bulletsToSpawn = new int[2] { 4, 8 };
    [SerializeField] private float bulletSpeed;
    [SerializeField] private float spawnRate;
    [SerializeField] private int maxSpawnRate;

    private void Update()
    {
        SpawnBullets();
    }

    private void SpawnBullets()
    {
        // Counter to spawn bullet
        if (spawnRate >= maxSpawnRate)
        {
            // Spawn bullet
            spawnRate = 0f;
            BulletManager.instance.CircularBulletSpawn(bulletPrefab ,transform.position, Random.Range(bulletsToSpawn[0], bulletsToSpawn[1]), bulletSpeed);
        } else
        {
            // Decrease bullet spawn timer
            spawnRate += Time.deltaTime;
        }
    }
}
