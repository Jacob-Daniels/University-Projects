#pragma once
#include <SFML/Graphics.hpp>

class Input
{
	constexpr static unsigned int LEFT = 1;
	constexpr static unsigned int RIGHT = 2;
	constexpr static unsigned int JUMP = 4;
	constexpr static unsigned int FIRE = 8;
	unsigned int control = 0;
public:
	Input() {};
	void Update()
	{
		control = 0;
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left) || sf::Keyboard::isKeyPressed(sf::Keyboard::A))
			control |= LEFT;
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right) || sf::Keyboard::isKeyPressed(sf::Keyboard::D))
			control |= RIGHT;
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space))
			control |= JUMP;
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Return))
			control |= FIRE;
	}

	bool Left() const { return (control & LEFT) != 0; }
	bool Right() const { return (control & RIGHT) != 0; }
	bool Jump() const { return (control & JUMP) != 0; }
	bool Fire() const { return (control & FIRE) != 0; }
};