using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Serialization;
using Random = UnityEngine.Random;

public class MeshManager : MonoBehaviour
{
    public static MeshManager instance;
    [SerializeField] private MeshFilter meshFilter;
    
    [Header("Mesh Properties:")]
    [SerializeField] private List<Vector3> combinedVertices;
    [SerializeField] List<int> combinedTriangles;
    
    [Header("Predefined Mesh Properties:")]
    [Range(2, 10)] [SerializeField] private int xSize;
    [Range(2, 20)] [SerializeField] private int ySize;
    [Range(1, 500)] [SerializeField] private int startLength;

    [Header("Editable Mesh Properties:")]
    [Range(1, 20)] [SerializeField] private int radius = 1;
    [Range(1, 5)] [SerializeField] private int width = 1;
    
    [Header("Segment Mesh Properties (DISPLAYED FOR DEBUGGING):")]
    [SerializeField] private List<Vector3> startCentrePoint;
    [SerializeField] private List<Vector3> endCentrePoint;
    [SerializeField] private List<Vector3> startVertices = new List<Vector3>();
    [SerializeField] private List<Vector3> endVertices = new List<Vector3>();
    [SerializeField] private Vector3Int positionOffset;

    [Header("Rotation Properties:")]
    [SerializeField] private List<Vector3> segmentRotation;
    private Quaternion previousSegmentRotation;
    private const float clampedRotation = 0.0f;

    // Loop Properties
    private int totalSegments;
    private int savedMeshIndex;
    private int savedSegmentIndex;

    // Getters
    public Vector3 GetStartPoint()
    {
        // Return start point of second segment
        return startCentrePoint[1];
    }

    public int GetRadius() { return radius; }
    
    private void Awake()
    {
        // Singleton
        if (instance == null)
        {
            instance = this;
        } else
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        // Set a start length when application starts
        for (int i = 0; i < startLength; i++)
        {
            CreateMeshSegment();
        }
    }
    
    private void Update()
    {
        // Old input system:
        // Scroll up
        // if (Input.GetAxisRaw("Mouse ScrollWheel") > 0)
        // {
        //     CreateMeshSegment();
        //     
        //     // Create connection
        //     if (totalSegments > 1)
        //     {
        //         CreateConnectionMesh2();
        //     }
        // }
        // // Scroll down
        // if (Input.GetAxisRaw("Mouse ScrollWheel") < 0)
        // {
        //     DeleteFirstSegment();
        // }
    }
    
    private void ApplyMesh()
    {
        Mesh mesh = new Mesh();
        mesh.name = "String Mesh";
        mesh.vertices = combinedVertices.ToArray();
        mesh.triangles = combinedTriangles.ToArray();
        meshFilter.mesh = mesh;
    }

    public void CreateMeshSegment()
    {
        // Get new spawn position
        Vector3 newPosition = new Vector3(0, 0, 0);
        Quaternion rotation = Quaternion.Euler(0,0,0);
        if (totalSegments > 0)
        {
            // Generate a random rotation and clamp it within the given range
            float minRotation = Mathf.Clamp(segmentRotation[segmentRotation.Count - 1].y - 10, -80, 80);
            float maxRotation = Mathf.Clamp(segmentRotation[segmentRotation.Count - 1].y + 10, -80, 80);
            // Generate a random rotation and overwrite previous
            segmentRotation.Add(new Vector3(clampedRotation, UnityEngine.Random.Range(minRotation, maxRotation), clampedRotation));
            rotation = Quaternion.Euler(segmentRotation[segmentRotation.Count - 1]);
            // Assign the previous rotation to allign the next segment
            previousSegmentRotation = Quaternion.Euler(segmentRotation[segmentRotation.Count - 2]);

            // Create random position from previous end/start points
            Vector3 previousStartPoint = startCentrePoint[startCentrePoint.Count - 1];
            Vector3 previousEndPoint = endCentrePoint[endCentrePoint.Count - 1];
            // Generate the new position from the old segments position and rotation
            newPosition = previousSegmentRotation * (previousEndPoint + positionOffset - previousStartPoint) + previousStartPoint;
        }
        else
        {
            // Generate a random rotation for the first segment
            segmentRotation.Add(new Vector3(clampedRotation, UnityEngine.Random.Range(-80, 80), clampedRotation));
            rotation = Quaternion.Euler(segmentRotation[segmentRotation.Count - 1]);
        }

        // Get center points
        startCentrePoint.Add(new Vector3(newPosition.x, newPosition.y, newPosition.z));
        endCentrePoint.Add(new Vector3(newPosition.x + (xSize * width), newPosition.y, newPosition.z));

        // Declare Mesh values
        float zPoint = 0.0f;
        float yPoint = 0.0f;
        float angle = 0.0f;
        
        // Create a grid of vertices
        for (int index = 0, y = 0; y <= ySize; y++)
        {
            // Angle and position of vertex points y and z
            angle = (1.0f / ySize) * (Mathf.PI * 2) * y;
            yPoint = Mathf.Cos(angle) * radius;
            zPoint = Mathf.Sin(angle) * radius;
            // Create row of vectors at same y & z positions
            for (int x = 0; x <= xSize*width; x+=width, index++)
            {
                // Create vertex with a rotation from start center point
                combinedVertices.Add((rotation * (new Vector3(newPosition.x + x, newPosition.y + yPoint, newPosition.z + zPoint) - startCentrePoint[startCentrePoint.Count - 1]) + startCentrePoint[startCentrePoint.Count - 1]) - transform.position);

                // Grab start and end vertices
                if (x == 0)
                {
                    startVertices.Add(rotation * (new Vector3(newPosition.x, newPosition.y + yPoint, newPosition.z + zPoint) - startCentrePoint[startCentrePoint.Count - 1]) + startCentrePoint[startCentrePoint.Count - 1]);
                }
                else if (x == xSize * width)
                {
                    endVertices.Add(rotation * (new Vector3(newPosition.x + (xSize * width), newPosition.y + yPoint, newPosition.z + zPoint) - startCentrePoint[startCentrePoint.Count - 1]) + startCentrePoint[startCentrePoint.Count - 1]);
                }
            }
        }

        // Create triangles
        for (int vertexIndex = savedSegmentIndex, y = 0; y < ySize; y++, vertexIndex++)
        {
            // Create row of triangles
            for (int x = 0; x < xSize; vertexIndex++, x++)
            {
                combinedTriangles.Add(vertexIndex);
                combinedTriangles.Add(vertexIndex + xSize + 1);
                combinedTriangles.Add(vertexIndex + 1);
                combinedTriangles.Add(vertexIndex + xSize + 1);
                combinedTriangles.Add(vertexIndex + xSize + 2);
                combinedTriangles.Add(vertexIndex + 1);
            }
        }
        savedSegmentIndex = combinedVertices.Count;
        totalSegments++;
        
        // Create connection and apply mesh
        if (totalSegments > 1)
        {
            CreateConnectionMesh2();
        }
        // Apply mesh
        ApplyMesh();
    }
    
    private void CreateConnectionMesh2()
    {
        // Create mesh that connects the previous segment to the new segment
        for (int i = savedMeshIndex; i < totalSegments; i++)
        {
            if (i + 1 >= totalSegments) { break; }
            
            // start vertices
            for (int j = 0; j <= ySize; j++)
            {
                combinedVertices.Add(endVertices[j + (ySize * savedMeshIndex) + savedMeshIndex]);
            }
            // end vertices
            for (int j = 0; j <= ySize; j++)
            {
                // Return each frame (As the new mesh needs to be created fully before adding vertices)
                combinedVertices.Add(startVertices[j + (ySize * (savedMeshIndex + 1)) + savedMeshIndex + 1]);
            }
        }
        
        // Triangles
        for (int segmentIndex = savedSegmentIndex, meshCount = savedMeshIndex; meshCount < totalSegments; segmentIndex += 2, meshCount++)
        {
            if (meshCount + 1 >= totalSegments) { break; }
            // Loop y vertices (circle)
            for (int y = 0; y < ySize; segmentIndex++, y++)
            {
                // Create 2 triangles
                combinedTriangles.Add(segmentIndex + ySize + 1);
                combinedTriangles.Add(segmentIndex);
                combinedTriangles.Add(segmentIndex + 1);
                
                combinedTriangles.Add(segmentIndex + ySize + 2);
                combinedTriangles.Add(segmentIndex + ySize + 1);
                combinedTriangles.Add(segmentIndex + 1);
            }
            segmentIndex += ySize;
            // Save segment index
            savedSegmentIndex = segmentIndex + 2;
        }
        // save mesh index
        savedMeshIndex = totalSegments - 1;
    }

    public void DeleteFirstSegment()
    {
        if (totalSegments <= 0 || combinedVertices.Count <= 0 || combinedTriangles.Count <= 0) { return; }
        
        // Delete first segment
        if (totalSegments == 1)
        {
            // Remove first segment and reset start rotation
            combinedVertices.Clear();
            combinedTriangles.Clear();
            segmentRotation.Clear();
            startCentrePoint.Clear();
            endCentrePoint.Clear();
            startVertices.Clear();
            endVertices.Clear();
            savedSegmentIndex = 0;
            savedMeshIndex = 0;
            totalSegments = 0;
            ApplyMesh();
            return;
        }
        
        // First segment vertices
        for (int i = 0; i < (ySize * (xSize + 1) + xSize + 1); i++)
        {
            combinedVertices.RemoveAt(0);
        }
        // Remove Connection vertices
        for (int i = 0; i < (ySize * 2 + 2); i++)
        {
            combinedVertices.RemoveAt((ySize * (xSize + 1) + xSize + 1));
        }

        // Remove triangles for segment and connection
        for (int i = 0; i < ((ySize * xSize) * 6) + (ySize * 6); i++)
        {
            combinedTriangles.RemoveAt(combinedTriangles.Count - 1);
        }

        // Update lists and variables
        for (int i = 0; i < ySize + 1; i++)
        {
            startVertices.RemoveAt(0);
            endVertices.RemoveAt(0);
        }
        segmentRotation.RemoveAt(0);
        startCentrePoint.RemoveAt(0);
        endCentrePoint.RemoveAt(0);
        savedSegmentIndex -= (ySize * (xSize + 1) + xSize + 1) + (ySize * 2 + 2);
        savedMeshIndex -= 1;
        totalSegments -= 1;

        ApplyMesh();
    }

    private IEnumerator CreateConnectionMesh()
    {
        // Create mesh that connects the previous segment to the new segment
        for (int i = savedMeshIndex; i < totalSegments; i++)
        {
            if (i + 1 >= totalSegments) { break; }
            
            // start vertices
            for (int j = 0; j <= ySize; j++)
            {
                combinedVertices.Add(endVertices[j + (ySize * savedMeshIndex) + savedMeshIndex]);
            }
            // end vertices
            for (int j = 0; j <= ySize; j++)
            {
                // Return each frame (As the new mesh needs to be created fully before adding vertices)
                yield return null;
                combinedVertices.Add(startVertices[j + (ySize * (savedMeshIndex + 1)) + savedMeshIndex + 1]);
            }
        }
        
        // Triangles
        for (int segmentIndex = savedSegmentIndex, meshCount = savedMeshIndex; meshCount < totalSegments; segmentIndex += 2, meshCount++)
        {
            if (meshCount + 1 >= totalSegments) { break; }
            // Loop y vertices (circle)
            for (int y = 0; y < ySize; segmentIndex++, y++)
            {
                // Create 2 triangles
                combinedTriangles.Add(segmentIndex + ySize + 1);
                combinedTriangles.Add(segmentIndex);
                combinedTriangles.Add(segmentIndex + 1);
                
                combinedTriangles.Add(segmentIndex + ySize + 2);
                combinedTriangles.Add(segmentIndex + ySize + 1);
                combinedTriangles.Add(segmentIndex + 1);
            }
            segmentIndex += ySize;
            // Save segment index
            savedSegmentIndex = segmentIndex + 2;
        }
        // save mesh index
        savedMeshIndex = totalSegments - 1;

        // Apply mesh
        ApplyMesh();
    }

    private void DeleteLatestSegment()
    {
        if (totalSegments <= 0 || combinedVertices.Count <= 0 || combinedTriangles.Count <= 0) { return; }
        
        // Delete first segment
        if (totalSegments == 1)
        {
            // Remove first segment and reset start rotation
            combinedVertices.Clear();
            combinedTriangles.Clear();
            segmentRotation.Clear();
            startCentrePoint.Clear();
            endCentrePoint.Clear();
            startVertices.Clear();
            endVertices.Clear();
            savedSegmentIndex = 0;
            savedMeshIndex = 0;
            totalSegments = 0;
            ApplyMesh();
            return;
        }
        
        // Remove vertices for segment and connection
        for (int i = 0; i < (ySize * (xSize + 1) + xSize + 1) + (ySize * 2 + 2); i++)
        {
            combinedVertices.RemoveAt(combinedVertices.Count - 1);
        }
        
        // Remove triangles for segment and connection
        for (int i = 0; i < ((ySize * xSize) * 6) + (ySize * 6); i++)
        {
            combinedTriangles.RemoveAt(combinedTriangles.Count - 1);
        }
        
        // Update lists and variables
        for (int i = 0; i < ySize + 1; i++)
        {
            startVertices.RemoveAt(startVertices.Count - 1);
            endVertices.RemoveAt(endVertices.Count -1);
        }
        segmentRotation.RemoveAt(segmentRotation.Count - 1);
        startCentrePoint.RemoveAt(startCentrePoint.Count - 1);
        endCentrePoint.RemoveAt(endCentrePoint.Count - 1);
        savedSegmentIndex -= (ySize * (xSize + 1) + xSize + 1) + (ySize * 2 + 2);
        savedMeshIndex -= 1;
        totalSegments -= 1;
        
        ApplyMesh();
    }
}
