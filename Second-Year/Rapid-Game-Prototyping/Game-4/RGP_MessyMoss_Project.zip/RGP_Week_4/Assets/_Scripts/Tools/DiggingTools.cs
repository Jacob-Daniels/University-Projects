using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;
using System;
using Unity.Burst.CompilerServices;

public class DiggingTools : MonoBehaviour
{
    [Header("Tiles:")]
    [SerializeField] private Tile[] digTiles;
    [SerializeField] private Tile[] hammerTiles;
    [SerializeField] private Tile[] handTiles;

    private string selectedTool;
    private Vector3Int mouseMapPos;

    // Setter
    public void SetSelectedTool(string newTool) { selectedTool = newTool; }

    private void Update()
    {
        mouseMapPos = ToolManager.instance.mouseTilemapPos;

        if (Input.GetMouseButton(0))
        {
            // Grab tag of first raycast target
            RaycastHit2D hit = ToolManager.instance.hit;

            // Return if no collider is hit OR if tool cant be used
            if (hit.collider == null || !ToolManager.instance.GetCanUseTool()) { return; }

            // Check which tool is selected to remove the tile
            if (selectedTool == ToolManager.instance.GetShovelTag())
            {
                // Check tile exists in dig tile array
                Tile tileClicked = GetTileFromArray(digTiles, hit.collider.GetComponent<Tilemap>().GetTile<Tile>(mouseMapPos));
                if (tileClicked == null) { return; }
                // Audio
                AudioManager.instance.Play("MossDig");
                // Remove tile & call collectable
                CollectableManager.instance.CollectablePickedUp(tileClicked);
                hit.collider.GetComponent<Tilemap>().SetTile(ToolManager.instance.mouseTilemapPos, null);
            }
            else if (selectedTool == ToolManager.instance.GetHammerTag())
            {
                // Check tile exists in hammer tile array
                Tile tileClicked = GetTileFromArray(hammerTiles, hit.collider.GetComponent<Tilemap>().GetTile<Tile>(mouseMapPos));
                if (tileClicked == null) { return; }
                // Audio
                AudioManager.instance.Play("HammerHit");
                // Remove tile & call collectable
                CollectableManager.instance.CollectablePickedUp(tileClicked);
                hit.collider.GetComponent<Tilemap>().SetTile(ToolManager.instance.mouseTilemapPos, null);
            }
            else if (selectedTool == ToolManager.instance.GetHandTag())
            {
                // Check tile exists in hand tile array
                Tile tileClicked = GetTileFromArray(handTiles, hit.collider.GetComponent<Tilemap>().GetTile<Tile>(mouseMapPos));
                if (tileClicked == null) { return; }
                // Audio
                AudioManager.instance.Play("PickUpHand");
                // Remove tile & call collectable
                CollectableManager.instance.CollectablePickedUp(tileClicked);
                hit.collider.GetComponent<Tilemap>().SetTile(ToolManager.instance.mouseTilemapPos, null);
            }
        }
        // On mouse up input
        if (Input.GetMouseButtonUp(0))
        {
            // Get mouse position ysing raycast
            RaycastHit2D hit = ToolManager.instance.hit;
            // Check if shovel is hitting rock on mouse up
            if (selectedTool == ToolManager.instance.GetShovelTag())
            {
                // Check tile type to play audio clip
                Tile tileClickedOff = GetTileFromArray(hammerTiles, hit.collider.GetComponent<Tilemap>().GetTile<Tile>(mouseMapPos));
                if (tileClickedOff == null) { return; }
                // Play sound if shovel hits rock
                if (GetTileFromArray(hammerTiles, hit.collider.GetComponent<Tilemap>().GetTile<Tile>(mouseMapPos)).name == "Rock")
                {
                    AudioManager.instance.Play("BadShovelHit");
                }
            }
        }
    }
    
    private Tile GetTileFromArray(Tile[] _tileArray, Tile _tileType)
    {
        // Check tile exists in array
        Tile tileClicked = Array.Find(_tileArray, tile => tile == _tileType);
        if (tileClicked == null) { return null; }

        // Check tile is collectable
        //CollectableManager.instance.CollectablePickedUp(tileClicked);
        return tileClicked;
    }

    public void DisableScript()
    {
        // Disable script and reset variables
        selectedTool = null;
        enabled = false;
    }
}
