using UnityEngine;

public class Force_Reset : MonoBehaviour
{
    private AI_Movement currentObj;
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "AIEntity")
        {
            // Reduce/reset velocity
            collision.gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(collision.gameObject.GetComponent<AI_Movement>().speed, -3);
        }
    }
}
