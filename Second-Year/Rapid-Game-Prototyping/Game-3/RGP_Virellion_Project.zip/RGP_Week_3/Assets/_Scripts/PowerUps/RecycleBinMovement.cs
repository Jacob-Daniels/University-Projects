using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RecycleBinMovement : MonoBehaviour
{
    [SerializeField] private Rigidbody2D rb;
    [SerializeField] private Vector2 direction;
    [SerializeField] private float speed = 5f;
    private RecycleBinProperties binProperties;

    [Header("Rotation properties:")]
    [SerializeField] private Vector3 rotation;
    [SerializeField] private float rotateSpeed = 10f;

    private void Start()
    {
        binProperties = gameObject.GetComponent<RecycleBinProperties>();
        direction = Vector2.one.normalized;
    }

    private void FixedUpdate()
    {
        // Move recycle bin if it is not full
        if (!binProperties.isFull)
        {
            // Fix rotation
            transform.localRotation = Quaternion.Euler(0, 0, 0);
            // Move object
            rb.velocity = direction * speed;
        } else
        {
            // Reset velocity and rotate object
            rb.velocity = new Vector2(0, 0);
            transform.Rotate(rotation * rotateSpeed * Time.deltaTime);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Wall"))
        {
            direction.x = -direction.x;
        }
        else if (collision.gameObject.CompareTag("Wall2"))
        {
            direction.y = -direction.y;
        }
    }
}
