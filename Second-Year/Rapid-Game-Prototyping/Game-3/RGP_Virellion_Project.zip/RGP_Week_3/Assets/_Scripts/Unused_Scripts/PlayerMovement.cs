using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    [Header("Movement Properties:")]
    [SerializeField] private Rigidbody2D rb;
    [SerializeField] private float speed = 40f;
    [SerializeField] private float stopTime = 2f;
    private Vector2 moveInput;
    private Vector2 velocity;

    [Header("Dash Properties:")]
    [SerializeField] private DashState dashState;
    [SerializeField] private Vector2 savedVelocity;
    [SerializeField] private float dashForce = 20f;
    [SerializeField] private float dashTimer;
    [SerializeField] private float maxTime = 1f;
    [SerializeField] private float dashingTimer = 3f;
    [SerializeField] private float cooldownTimer = 2f;

    private void Start()
    {
        // Set the dash state
        dashState = DashState.CanDash;
    }

    private void Update()
    {
        // Movement input
        moveInput.x = Input.GetAxisRaw("Horizontal");
        moveInput.y = Input.GetAxisRaw("Vertical");
        moveInput.Normalize();

        // Player dash
        switch (dashState)
        {
            case DashState.CanDash:
                // Dash player
                if (Input.GetKeyDown(KeyCode.Space) && (moveInput.x != 0 || moveInput.y != 0))
                {
                    savedVelocity = rb.velocity;
                    rb.velocity = new Vector2(moveInput.x * dashForce, moveInput.y * dashForce);
                    dashState = DashState.Dashing;
                }
                break;
            case DashState.Dashing:
                // Player is dashing
                dashTimer += Time.deltaTime * dashingTimer;
                if (dashTimer >= maxTime)
                {
                    dashTimer = maxTime;
                    rb.velocity = savedVelocity;
                    dashState = DashState.Cooldown;
                }
                break;
            case DashState.Cooldown:
                // Dash on cooldown
                dashTimer -= Time.deltaTime * cooldownTimer;
                if (dashTimer <= 0)
                {
                    dashTimer = 0f;
                    dashState = DashState.CanDash;
                }
                break;
        }
        // Get vector for target location
        //velocity = Vector2.MoveTowards(velocity, moveInput * speed, Time.deltaTime * speed);
    }

    private void FixedUpdate()
    {
        // Move player
        //rb.MovePosition(rb.position + velocity * Time.deltaTime);
        rb.position = Vector2.MoveTowards(rb.position, rb.position + moveInput, speed * Time.deltaTime);
    }

    private enum DashState
    {
        // States for dashing
        CanDash,
        Dashing,
        Cooldown
    }
}
