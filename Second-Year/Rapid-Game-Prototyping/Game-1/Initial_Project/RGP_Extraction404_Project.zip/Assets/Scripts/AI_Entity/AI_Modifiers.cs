using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class AI_Modifiers : MonoBehaviour
{
    public AI_Movement movementScript;
    public float force = 15f;

    public void ResetVelocity()
    {
        movementScript.rb.velocity = new Vector2(0, -3);
    }

    public void FlipDirection()
    {
        // Flip direction of object
        movementScript.ReverseDirection();
    }

    public void RightForce()
    {
        // Apply positive force (right)
        movementScript.rb.AddForce(transform.right * force, ForceMode2D.Impulse);
    }

    public void LeftForce()
    {
        // Apply negative force (left)
        movementScript.rb.AddForce(transform.right * -force, ForceMode2D.Impulse);
    }

    public void UpForce()
    {
        // Apply positive force (up)
        movementScript.rb.AddForce(transform.up * force, ForceMode2D.Impulse);
    }

    public void DownForce()
    {
        // Apply negative force (down)
        movementScript.rb.AddForce(transform.up * -force, ForceMode2D.Impulse);
    }
}
