using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

// Scale player to the distance, within a given range
public class ScaleToDistance : MonoBehaviour
{
    public Transform player;

    public float stopResizeDistance = 5f;
    public float startResizeDistance = 20f;
    public float smallestSize = 0.1f;
    public float initialScale;

    private float distanceFromPlayer;
    private float distancePercentage;

    private void Awake()
    {
        player = GameObject.Find("Player").GetComponent<Transform>();
        initialScale = player.transform.localScale.x;
    }

    void Update()
    {
        // Calculate distance
        distanceFromPlayer = Vector3.Distance(transform.position, player.position);

        // Calculate percentage for resizing player
        if (distanceFromPlayer > startResizeDistance)
        {
            distancePercentage = 100f;
        } else
        {
            distancePercentage = Mathf.Abs(startResizeDistance / distanceFromPlayer);
        }

        // Resize player
        if (distanceFromPlayer < startResizeDistance && distanceFromPlayer > stopResizeDistance)
        {
            // Set scale by percentage
            float newScale = Mathf.Abs(initialScale / distancePercentage);
            if (newScale > smallestSize && newScale < initialScale)
            {
                player.transform.localScale = new Vector3(newScale, newScale, newScale);
            }
        }
    }

    private void OnDrawGizmos()
    {
        // Draw radius 
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, stopResizeDistance);
        Gizmos.color = Color.blue;
        Gizmos.DrawWireSphere(transform.position, startResizeDistance);
    }
}
