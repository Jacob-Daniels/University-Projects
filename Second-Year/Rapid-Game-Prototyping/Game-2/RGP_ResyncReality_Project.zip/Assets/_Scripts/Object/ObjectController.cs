using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectController : MonoBehaviour
{
    public bool isOpen = false;
    [SerializeField] private Vector3 startPos;
    [SerializeField] private Vector3 endPos;
    [SerializeField] private float speed = 2f;

    private void Awake()
    {
        startPos = transform.position;
    }

    private void Update()
    {
        // Change position of object depending whether its colliding with another object
        if (!isOpen)
        {
            transform.position = Vector3.MoveTowards(transform.position, startPos, speed * Time.deltaTime);
        }
        else
        {
            transform.position = Vector3.MoveTowards(transform.position, endPos, speed * Time.deltaTime);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        // Button pressed when large object is colliding
        if (other.gameObject.tag == "PickupObject")
        {
            if (other.gameObject.GetComponent<ObjectSize>().isBlack)
            {
                isOpen = true;
            }
        }
    }

    private void OnTriggerStay(Collider other)
    {
        if (other.gameObject.tag == "PickupObject")
        {
            if (other.gameObject.GetComponent<ObjectSize>().isBlack)
            {
                isOpen = true;
            } else
            {
                isOpen = false;
            }
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.gameObject.tag == "PickupObject")
        {
            isOpen = false;
        }
    }
}
