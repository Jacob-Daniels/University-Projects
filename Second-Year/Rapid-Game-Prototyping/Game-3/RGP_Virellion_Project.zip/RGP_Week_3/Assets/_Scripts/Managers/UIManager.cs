using Newtonsoft.Json.Bson;
using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{
    public static UIManager instance;
    [Header("Health Display Properties:")]
    [SerializeField] private PlayerProperties playerProperties;
    [SerializeField] private Image[] healthImages;
    [SerializeField] private Sprite[] numberSprites;
    [SerializeField] private Sprite nullSprite;

    [Header("Pause Menu Properties:")]
    public GameObject pauseMenu;
    private bool bgMusicMuted = false;

    [Header("Game Over Properties:")]
    public GameObject gameOverMenu;

    private void Awake()
    {
        // Singleton
        if (instance == null)
        {
            instance = this;
        } else
        {
            Destroy(gameObject);
        }
    }

    private void Update()
    {
        // Pause game
        if (Input.GetKeyDown(KeyCode.P) || Input.GetKeyDown(KeyCode.Escape))
        {
            GameManager.instance.PauseGame();
        }
        // Display health on screen by changing sprite
        SetHealthSprites();
    }

    private void SetHealthSprites()
    {
        // Convert health to string to split into character array
        char[] charInts = ((int)playerProperties.health).ToString().ToCharArray();

        // Length of health char array
        if (charInts.Length == 3)
        {
            // 3 digits long
            healthImages[0].sprite = numberSprites[(int)char.GetNumericValue(charInts[0])];
            healthImages[1].sprite = numberSprites[(int)char.GetNumericValue(charInts[1])];
            healthImages[2].sprite = numberSprites[(int)char.GetNumericValue(charInts[2])];
        }
        else if (charInts.Length == 2)
        {
            // 2 digits
            healthImages[0].sprite = nullSprite;
            healthImages[1].sprite = numberSprites[(int)char.GetNumericValue(charInts[0])];
            healthImages[2].sprite = numberSprites[(int)char.GetNumericValue(charInts[1])];
        }
        else if (charInts.Length == 1)
        {
            // single digit
            healthImages[0].sprite = nullSprite;
            healthImages[1].sprite = nullSprite;
            healthImages[2].sprite = numberSprites[(int)char.GetNumericValue(charInts[0])];
        }
    }

    public void MuteMusic()
    {
        if (bgMusicMuted)
        {
            // Unmute music
            AudioManager.instance.UnmuteBackgroundMusic();
            bgMusicMuted = false;
        } else
        {
            // Mute music
            AudioManager.instance.MuteBackgroundMusic();
            bgMusicMuted = true;
        }
    }

    public void MouseClick()
    {
        AudioManager.instance.Play("MouseClick");
    }
}
