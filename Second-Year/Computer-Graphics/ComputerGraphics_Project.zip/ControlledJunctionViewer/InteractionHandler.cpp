#include <windows.h>
#include <iostream>

#include <osgGA/GUIActionAdapter>
#include <osgGA/GUIEventAdapter>
#include <osgGA/NodeTrackerManipulator>

#include <Assignment/AnimatedCar.h>
#include <Assignment/PedestrianTrafficLightFacade.h>
#include <Assignment/RoadTileLightsFacade.h>
#include <Assignment/RoadTilePedestrianLightFacade.h>
#include <Assignment/SelectionHandler.h>
#include <Assignment/ShaderController.h>

#include "InteractionHandler.h"

InteractionHandler::InteractionHandler(KEY_FUNC* pFunc, Assignment::CameraController* pCamController, Assignment::ShaderController* pShaderController, Assignment::LightCycleController* pLightCycleController) : m_pFunc(pFunc), m_pCameraController(pCamController), m_pShaderController(pShaderController), m_pLightCycleController(pLightCycleController)
{
}

InteractionHandler::~InteractionHandler()
{
}

bool InteractionHandler::handle(const osgGA::GUIEventAdapter& ea, osgGA::GUIActionAdapter& aa, osg::Object*, osg::NodeVisitor*)
{
    // Debugging input handler
	switch (ea.getEventType())
	{
	case osgGA::GUIEventAdapter::KEYDOWN:
		//std::cout << "The " << ea.getKey() << "was pressed at window position [" << ea.getWindowX() << ", " << ea.getWindowY() << "]" << std::endl;

		if (m_pFunc)
		{
			m_pFunc(ea.getKey());
		}
		else
		{
			std::cout << "There is no specific help for this application" << std::endl;
		}
        // Print debugging content in console
		if (ea.getKey() == 'h')
		{
			std::cout << std::endl;
			std::cout << "Viewer help - osg key index" << std::endl;
			std::cout << "\tw - switch rendering mode (wireframe/points/filled)" << std::endl;
			std::cout << "\te - toggle frame barrier position" << std::endl;
			std::cout << "\tf - toggle fullscreen" << std::endl;
			std::cout << "\tt - toggle texture state (non shader)" << std::endl;
			std::cout << "\tt - toggle lighting (non shader)" << std::endl;
			std::cout << "\ts - performance display" << std::endl;
			std::cout << "\tm - threading model" << std::endl;
		}

        if (ea.getKey() == osgGA::GUIEventAdapter::KeySymbol::KEY_Space) {
            // Traverse through the shader switch children
            m_pShaderController->toggleShader();
        }
        if (ea.getKey() == 'b') {
            // Toggle lighting in the scene
            m_pLightCycleController->toggleLighting();
        }
        
        return true;
    case osgGA::GUIEventAdapter::PUSH:
        // Check for a Right mouse click on screen
        if (ea.getButtonMask() == osgGA::GUIEventAdapter::RIGHT_MOUSE_BUTTON) {
            // Build an intersector based on the mouse position
            osgUtil::LineSegmentIntersector* pRay = new osgUtil::LineSegmentIntersector(osgUtil::Intersector::PROJECTION, ea.getXnormalized(), ea.getYnormalized());
            osgUtil::IntersectionVisitor visitor(pRay);

            // Apply the intersection visitor to the scene
            aa.asView()->getCamera()->accept(visitor);
            if (pRay->containsIntersections()) // if a hit was detected
            {
                //get the first (nearest) hit
                osgUtil::LineSegmentIntersector::Intersection intersection = pRay->getFirstIntersection();

                if (intersection.drawable) // check the hit is a drawable
                {
                    // search up the drawable's path to find the root of the facade
                    // this will be the node we attached the user data to
                    for (osg::NodePath::iterator it = intersection.nodePath.begin(); it != intersection.nodePath.end(); it++)
                    {
                        // if a selection handler is found
                        if (Assignment::SelectionHandler* pSH = dynamic_cast<Assignment::SelectionHandler*>((*it)->getUserData()))
                        {
                            // Check the facade that has been clicked
                            if (Assignment::AnimatedCar* pAC = dynamic_cast<Assignment::AnimatedCar*>(pSH->facade()))
                            {
                                // Toggle the side camera
                                m_pCameraController->toggleCamera(pAC);
                            }
                            else if (Assignment::PedestrianTrafficLightFacade* pPTL = dynamic_cast<Assignment::PedestrianTrafficLightFacade*>(pSH->facade())) {
                                // Toggle the pedestrian traffic light by accessing the pedestrian lights parent tile
                                pPTL->getRoadTileParent()->toggleState();
                            }
                        }
                    }
                }
            }
        }
        return true;
    }

	return false;
}