#pragma once

#include <Windows.h>
#include <osg/Callback>
#include <osg/Switch>
#include <osg/LightSource>

namespace Assignment
{
	class LightCycleController : public osg::Callback
	{
	public:
		LightCycleController(osg::Group* pRoot);
		virtual ~LightCycleController();

		virtual bool run(osg::Object* object, osg::Object* data);

		void toggleLighting();

	protected:
		osg::Switch* m_pLightSwitch;
		osg::LightSource* m_pLightSource;
		osg::Light* m_pLight;
		bool bState, bCycleState;
		unsigned int uiCount, uiCycleLimit;
	};
}
