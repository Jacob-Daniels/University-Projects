#include "LightCycleController.h"

#include <iostream>

Assignment::LightCycleController::LightCycleController(osg::Group* pRoot) : m_pLightSource(new osg::LightSource()), m_pLightSwitch(new osg::Switch()), bState(false), bCycleState(true), uiCount(0), uiCycleLimit(1000)
{
	// Define the light
	m_pLight = new osg::Light(0);
	m_pLight->setPosition(osg::Vec4f(500.0f, 60.0f, 2000.0f, 1.0f));
	m_pLight->setDirection(osg::Vec3f(-1.0f, -0.5f, -20.0f));
	m_pLight->setAmbient(osg::Vec4(0.1f, 0.1f, 0.1f, 1.0f));
	//pLight->setDiffuse(osg::Vec4(0.8f, 0.8f, 0.8f, 1.0f));
	m_pLight->setDiffuse(osg::Vec4(0.0f, 0.0f, 0.0f, 1.0f));

	// State attribute of the light
	m_pLightSource->setLight(m_pLight);
	m_pLightSource->setLocalStateSetModes(osg::StateAttribute::ON);

	// Add light to switch and main root
	m_pLightSwitch->setNewChildDefaultValue(false);
	m_pLightSwitch->addChild(m_pLightSource);
	pRoot->addChild(m_pLightSwitch);

	// Set callback
	m_pLightSource->setUpdateCallback(this);
}

Assignment::LightCycleController::~LightCycleController()
{
	if (m_pLightSwitch) m_pLightSwitch->unref();
	if (m_pLightSource) m_pLightSource->unref();
}

bool Assignment::LightCycleController::run(osg::Object* object, osg::Object* data)
{
	if (!bState) return false;

	// Cycle through a timer to slowly progress from night and day
	if (bCycleState) {
		if (++uiCount < uiCycleLimit) {
			float lightDiffuse = (float)uiCount / uiCycleLimit;
			m_pLight->setDiffuse(osg::Vec4(lightDiffuse, lightDiffuse, lightDiffuse, 1.0f));
		}
		else {
			bCycleState = false;
		}
	}
	else {
		if (--uiCount > 0) {
			float lightDiffuse = (float)uiCount / uiCycleLimit;
			m_pLight->setDiffuse(osg::Vec4(lightDiffuse, lightDiffuse, lightDiffuse, 1.0f));
		}
		else {
			bCycleState = true;
		}
	}
	return false;
}

void Assignment::LightCycleController::toggleLighting()
{
	// Toggle the lighting node (via switch)
	bState = !bState;
	if (bState) {
		m_pLightSwitch->setAllChildrenOn();
	}
	else {
		m_pLightSwitch->setAllChildrenOff();
	}
}
