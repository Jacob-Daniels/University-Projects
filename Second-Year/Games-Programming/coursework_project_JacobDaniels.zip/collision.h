#pragma once
#include <SFML/Graphics.hpp>
#include <vector>
using namespace std;

struct CollisionQuad
{
	sf::Vector2f pos, size;
	CollisionQuad(sf::Vector2f pos, sf::Vector2f size ) : pos(pos), size(size) {}
	// Calculate the depth
	void CalculateDepth(float d, float& depth, sf::Vector2f& normal, float x, float y) {
		if (d < depth) {
			depth = d;
			normal = sf::Vector2f(x, y);
		}
	}

	bool Overlap(CollisionQuad other, float &depth, sf::Vector2f& normal)
	{
		if (other.pos.x + other.size.x < pos.x)
			return false;
		if (other.pos.x > pos.x + size.x)
			return false;
		if (other.pos.y + other.size.y < pos.y)
			return false;
		if (other.pos.y > pos.y + size.y)
			return false;

		// calculate the depth and normal, by finding the shortest distance to clear the overlap
		// of the four possible directions of movement of the other quad

		depth = 1e20f;
		float d;
		// +x
		CalculateDepth(pos.x + size.x - other.pos.x, depth, normal, 1.0f, 0.0f);
		// -x
		CalculateDepth(other.pos.x + other.size.x - pos.x, depth, normal, -1.0f, 0.0f);
		// +y
		CalculateDepth(pos.y + size.y - other.pos.y, depth, normal, 0.0f, 1.0f);
		// -y
		CalculateDepth(other.pos.y + other.size.y - pos.y, depth, normal, 0.0f, -1.0f);
		
		return true;
		#pragma region OldCode
		//// +x
		//d = pos.x + size.x - other.pos.x;
		//if (d < depth)
		//{
		//	depth = d;
		//	normal = sf::Vector2f(1.0f, 0.0f);
		//}
		//// -x 
		//d = other.pos.x + other.size.x - pos.x;
		//if (d < depth)
		//{
		//	depth = d;
		//	normal = sf::Vector2f(-1.0f, 0.0f);
		//}
		//// +y 
		//d = pos.y + size.y - other.pos.y;
		//if (d < depth)
		//{
		//	depth = d;
		//	normal = sf::Vector2f(0.0f, 1.0f);
		//}
		//// -y 
		//d = other.pos.y + other.size.y - pos.y;
		//if (d < depth)
		//{
		//	depth = d;
		//	normal = sf::Vector2f(0.0f, -1.0f);
		//}
		//return true;
		#pragma endregion
	}
	
	bool Overlap(const sf::Vector2f& point, float& depth, sf::Vector2f& normal)
	{
		bool overlap = point.x > pos.x && point.x < pos.x + size.x && point.y > pos.y && point.y < pos.y + size.y;
		if (overlap)
		{
			// find depth and normal - find shortest distance to move the point to clear the overlap
			depth = 1e20f;
			float d;
			// +x
			CalculateDepth(pos.x + size.x - point.x, depth, normal, 1.0f, 0.0f);
			// -x
			CalculateDepth(point.x - pos.x, depth, normal, -1.0f, 0.0f);
			// +y
			CalculateDepth(pos.y + size.y - point.y, depth, normal, 0.0f, 1.0f);
			// -y
			CalculateDepth(point.y - pos.y, depth, normal, 0.0f, -1.0f);
			#pragma region OldCode
			//// +x 
			//d = pos.x + size.x - point.x;
			//if (d < depth)
			//{
			//	depth = d;
			//	normal = sf::Vector2f(1.0f, 0.0f);
			//}
			//// -x 
			//d = point.x - pos.x;
			//if (d < depth)
			//{
			//	depth = d;
			//	normal = sf::Vector2f(-1.0f, 0.0f);
			//}
			//// +y 
			//d = pos.y + size.y - point.y;
			//if (d < depth)
			//{
			//	depth = d;
			//	normal = sf::Vector2f(0.0f, 1.0f);
			//}
			//// -y 
			//d = point.y - pos.y;
			//if (d < depth)
			//{
			//	depth = d;
			//	normal = sf::Vector2f(0.0f, -1.0f);
			//}
			#pragma endregion
		}
	}
};

class Collision
{
	// a simple 2D collision system with rectangle primitives
	vector<CollisionQuad> collisionWorld;
public:
	Collision() {}
	void AddStaticCollider(const sf::Vector2f pos, const sf::Vector2f size)
	{
		collisionWorld.push_back(CollisionQuad(pos, size));
	}
	// Platform Collision
	template <typename T> bool Overlap(T object, float& depth, sf::Vector2f& normal) {
		for (auto c : collisionWorld) {
			if (c.Overlap(object, depth, normal)) {
				return true;
			}
		}
		return false;
	}
};