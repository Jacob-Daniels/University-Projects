using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PortalCamera : MonoBehaviour
{
    public Transform playerCamera;
    public Transform portal;
    public Transform otherPortal;


    void Update()
    {
        // Get player offset from closest portal
        Vector3 playerOffsetFromPortal = playerCamera.position - otherPortal.position;
        // Set position of camera at second portal depending on player camera position
        transform.position = portal.position + playerOffsetFromPortal;

        // Prevent second portal camera from rotating
        float angularDifferenceBetweenPortalRotations = Quaternion.Angle(portal.rotation, otherPortal.rotation);

        Quaternion portalRotationalDifference = Quaternion.AngleAxis(angularDifferenceBetweenPortalRotations, Vector3.up);
        Vector3 newCameraDirection = portalRotationalDifference * playerCamera.forward;
        transform.rotation = Quaternion.LookRotation(newCameraDirection, Vector3.up);
    }
}
