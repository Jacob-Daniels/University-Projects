#include <SFML/Audio.hpp>
#include <SFML/Graphics.hpp>
#include <iostream>
#include <vector>
#include <random>
#include "PlatformWorld.h"
using namespace std;

void Update(PlatformWorld& world, float dt)
{
	world.Update(dt);
}

void Draw(PlatformWorld& world, sf::RenderWindow& window)
{
	world.Draw(window);
}

int main()
{
	// Create the main window
	sf::RenderWindow window(sf::VideoMode(800, 600), "SFML window");
	window.setVerticalSyncEnabled(true);
	window.setKeyRepeatEnabled(false);

	PlatformWorld world;

	// Floor/Platforms
	world.AddPlatform(sf::Vector2f(-1000, 560), sf::Vector2f(2800, 40));	// Floor/Ground
	world.AddPlatform(sf::Vector2f(150, 300), sf::Vector2f(100, 20));	// Left upper platform
	world.AddPlatform(sf::Vector2f(550, 300), sf::Vector2f(100, 20));	// Right upper platform
	world.AddPlatform(sf::Vector2f(350, 350), sf::Vector2f(100, 20));	// Middle Platform
	world.AddPlatform(sf::Vector2f(250, 450), sf::Vector2f(100, 20));	// Middle Left platform
	world.AddPlatform(sf::Vector2f(450, 450), sf::Vector2f(100, 20));	// Middle right platform
	world.AddPlatform(sf::Vector2f(150, 100), sf::Vector2f(200, 20));	// Top left platform
	world.AddPlatform(sf::Vector2f(450, 100), sf::Vector2f(220, 20));	// Top right platform

	// Walls
	world.AddPlatform(sf::Vector2f(750, 50), sf::Vector2f(20, 450));	// Right wall
	world.AddPlatform(sf::Vector2f(650, 300), sf::Vector2f(20, 200));	// Right2 wall
	world.AddPlatform(sf::Vector2f(50, 50), sf::Vector2f(20, 450));	// Left wall
	world.AddPlatform(sf::Vector2f(150, 300), sf::Vector2f(20, 200));	// Left2 wall
	world.AddPlatform(sf::Vector2f(340, 100), sf::Vector2f(20, 150));	// Middle-left wall
	world.AddPlatform(sf::Vector2f(440, 100), sf::Vector2f(20, 150));	// Middle-right wall


	// this line makes the game crash :(
	cout << "Pixel Density of level: " << world.CountPlatformPixels()/(window.getSize().x*window.getSize().y) << endl;
	while (window.isOpen())
	{
		// Process events
		sf::Event event;
		while (window.pollEvent(event))
		{
			// Close window: exit
			if (event.type == sf::Event::Closed)
				window.close();
		}
		Update(world, 1.0f/60.0f);
		// Clear screen
		window.clear();
		Draw(world, window);
		window.display();
	}
	return EXIT_SUCCESS;
}

