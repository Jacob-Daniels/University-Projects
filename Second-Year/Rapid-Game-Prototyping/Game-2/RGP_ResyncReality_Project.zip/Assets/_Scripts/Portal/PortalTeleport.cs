using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PortalTeleport : MonoBehaviour
{
    [Header("Teleport Player:")]
    public Transform player;
    public Transform receiver;
    public Camera playerCamera;
    private bool playerIsOverlapping = false;
    [SerializeField] private bool whiteBackground = false;

    [Header("Teleport Object:")]
    public GameObject teleportObject;
    [SerializeField] private Material newMaterial;
    private bool objectIsOverlapping = false;
 
    void LateUpdate()
    {
        if (playerIsOverlapping)
        {
            Vector3 portalToPlayer = player.position - transform.position;
            float dotProduct = Vector3.Dot(transform.up, portalToPlayer);

            // Player has moved across the portal
            if (dotProduct < 0f)
            {
                // Teleport player
                float rotationDiff = -Quaternion.Angle(transform.rotation, receiver.rotation);
                rotationDiff += 180;
                player.Rotate(Vector3.up, rotationDiff);

                Vector3 positionOffset = Quaternion.Euler(0f, rotationDiff, 0f) * portalToPlayer;
                player.position = receiver.position + positionOffset;
                playerIsOverlapping = false;

                // Change colour of camera
                if (whiteBackground)
                {
                    playerCamera.backgroundColor = Color.white;
                }
                else
                {
                    playerCamera.backgroundColor = Color.black;
                }
            }
        }

        if (objectIsOverlapping && teleportObject != null)
        {
            Vector3 portalToObject = teleportObject.transform.position - transform.position;
            float dotProduct = Vector3.Dot(transform.up, portalToObject);

            // Obvject has moved across the portal
            if (dotProduct < 0f)
            {
                // Deselect item from player hand
                if (ItemPickup.instance.heldObject != null)
                {
                    ItemPickup.instance.DropItem();
                }

                // Teleport player
                float rotationDiff = -Quaternion.Angle(transform.rotation, receiver.rotation);
                rotationDiff += 180;
                teleportObject.transform.Rotate(Vector3.up, rotationDiff);

                Vector3 positionOffset = Quaternion.Euler(0f, rotationDiff, 0f) * portalToObject;
                teleportObject.transform.position = receiver.position + positionOffset - new Vector3(0f, 0f, teleportObject.transform.localScale.z);
                objectIsOverlapping = false;
                // Change object properties to new world
                teleportObject.GetComponent<MeshRenderer>().material = newMaterial;
                if (whiteBackground)
                {
                    // Check to reduce size
                    if (teleportObject.GetComponent<ObjectSize>())
                    {
                        //teleportObject.GetComponent<ObjectSize>().DecreaseSize();
                    }
                    // Add force to Z
                    teleportObject.GetComponent<Rigidbody>().AddForce(Vector3.forward * ItemPickup.instance.throwForce / 2);
                }
                else
                {
                    // Check to increase size
                    if (teleportObject.GetComponent<ObjectSize>())
                    {
                        //teleportObject.GetComponent<ObjectSize>().IncreaseSize();
                    }
                    teleportObject.GetComponent<Rigidbody>().AddForce(-Vector3.forward * ItemPickup.instance.throwForce / 2);
                }
            }
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player")
        {
            playerIsOverlapping = true;
        }
        if (other.tag == "PickupObject")
        {
            teleportObject = other.gameObject;
            objectIsOverlapping = true;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.tag == "Player")
        {
            playerIsOverlapping = false;
        }
        if (other.tag == "PickupObject")
        {
            teleportObject = null;
            objectIsOverlapping = false;
        }
    }
}
