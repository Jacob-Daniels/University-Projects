using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using TMPro;
using UnityEngine;
using UnityEngine.Tilemaps;

public class TilemapManager : MonoBehaviour
{
    public static TilemapManager instance;

    [Header("Outline Tilemap Properties:")]
    public Tilemap outlineMap;
    public AnimatedTile selectedTile;
    public AnimatedTile nullTile;
    private Vector3Int prevMousePos = new Vector3Int();
    private Vector3 mousePos;
    private Vector3Int currentMousePos;

    [Header("Tile placement Properties:")]
    public Tilemap tilePlacementMap;
    public TextMeshProUGUI tileLimitText; 
    private int tileLimit = 5;

    [Header("Tile Properties:")]
    public Tilemap modifierTilemap;
    public AnimatedTile[] tiles;
    public int currentTile = 0;
    private Vector3Int location;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        } else
        {
            Destroy(gameObject);
            return;
        }
    }

    // Set tile
    public void SetTile(int tileId)
    {
        // Set the selected tile
        currentTile = tileId;
        if (tiles[currentTile] == null)
        {
            selectedTile = nullTile;
        }
        else
        {
            selectedTile = tiles[currentTile];
        }
    }

    private void Update()
    {
        // Get mouse position
        mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        currentMousePos = outlineMap.WorldToCell(mousePos);

        // Update mouse hover
        if (!currentMousePos.Equals(prevMousePos))
        {
            outlineMap.SetTile(prevMousePos, null);
            outlineMap.SetTile(currentMousePos, selectedTile);
            prevMousePos = currentMousePos;
        }

        // Place tile or remove tile, depending on tile selected
        if (Input.GetMouseButtonDown(0) && tilePlacementMap.GetTile(currentMousePos))
        {
            // Check whether tile can be placed before game starts
            if (GameManager.instance.levelStarted)
            {
                // Check what audio clip to play
                if (selectedTile == nullTile && modifierTilemap.GetTile(currentMousePos) != null)
                {
                    AudioManager.instance.Play("modifierRemoved");
                }
                else if (selectedTile != nullTile)
                {
                    AudioManager.instance.Play("modifierPlacement");
                }
                // Place tile once game has started (no limit)
                PlaceTile(mousePos);
            }
            else
            {
                // Check whether a tile exists at position
                if (modifierTilemap.GetTile(currentMousePos) == null)
                {
                    // Check to place a tile (if one is selected)
                    if (selectedTile != nullTile && tileLimit > 0)
                    {
                        tileLimit--;
                        tileLimitText.text = "Controls remaining: " + tileLimit;
                        // Place tile on tilemap
                        PlaceTile(mousePos);
                        // Play audio
                        AudioManager.instance.Play("modifierPlacement");
                    }
                }
                else
                {
                    // Check to remove tile
                    if (selectedTile == nullTile)
                    {
                        tileLimit++;
                        tileLimitText.text = "Controls remaining: " + tileLimit;
                        // Play audio
                        AudioManager.instance.Play("modifierRemoved");
                    }
                    else
                    {
                        AudioManager.instance.Play("modifierPlacement");
                    }
                    // Place tile on tilemap
                    PlaceTile(mousePos);
                }
            }
        }

        // Remove tile on right click
        if (Input.GetMouseButtonDown(1) && tilePlacementMap.GetTile(currentMousePos))
        {
            if (GameManager.instance.levelStarted)
            {
                if (modifierTilemap.GetTile(currentMousePos) != null)
                {
                    // Play audio
                    AudioManager.instance.Play("modifierRemoved");
                    // Remove tile at location
                    modifierTilemap.SetTile(currentMousePos, tiles[0]);
                }
            } else
            {
                if (modifierTilemap.GetTile(currentMousePos) != null)
                {
                    // Play audio
                    AudioManager.instance.Play("modifierRemoved");
                    // Increase limit counter
                    tileLimit++;
                    tileLimitText.text = "Controls remaining: " + tileLimit;
                    // Remove tile at location
                    modifierTilemap.SetTile(currentMousePos, tiles[0]);
                }
            }
        }
    }

    public void UpdateMouseHover()
    {
        // Force update mouse hover (called when shortcut key is pressed)
        outlineMap.SetTile(prevMousePos, null);
        outlineMap.SetTile(currentMousePos, selectedTile);
        prevMousePos = currentMousePos;
    }

    private void PlaceTile(Vector3 mousePos)
    {
        // Place tile at location
        //location = modifierTilemap.WorldToCell(mousePos);
        modifierTilemap.SetTile(currentMousePos, tiles[currentTile]);
    }

    public AnimatedTile CheckTileColl(Vector3Int tilePos)
    {
        // Return tile if it exists in the tiles array
        if (modifierTilemap.GetTile(tilePos) != null)
        {
            foreach (AnimatedTile t in tiles)
            {
                if (t == null) continue;
                if (t.name == modifierTilemap.GetTile(tilePos).name)
                {
                    // Tile found
                    return t;
                }
            }
        }
        return null;
    }
}
