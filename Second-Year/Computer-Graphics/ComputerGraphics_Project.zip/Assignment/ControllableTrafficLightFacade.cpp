#include <Windows.h>
#include <osg/Geode>
#include "ControllableTrafficLightFacade.h"
#include <Common/NodeFinderT.h>
#include <osg/Program>
#include <osg/Texture2D>
#include <osgDB/ReadFile>
#include <osg/ShapeDrawable>

osg::Material* Assignment::ControllableTrafficLightFacade::sm_pRedOn = 0;
osg::Material* Assignment::ControllableTrafficLightFacade::sm_pGreenOn = 0;
osg::Material* Assignment::ControllableTrafficLightFacade::sm_pAmberOn = 0;
osg::Material* Assignment::ControllableTrafficLightFacade::sm_pRedOff = 0;
osg::Material* Assignment::ControllableTrafficLightFacade::sm_pGreenOff = 0;
osg::Material* Assignment::ControllableTrafficLightFacade::sm_pAmberOff = 0;

Assignment::ControllableTrafficLightFacade::ControllableTrafficLightFacade(std::string sname, osg::Node* pAsset, osg::Matrixf m, bool bVisible): TrafficLightFacade(sname, pAsset, m, bVisible), m_pAmber(0), m_pRed(0), m_pGreen(0), v_pWCP(0)
{
	#pragma region Light Materials
	if (!sm_pRedOn)
	{
		sm_pRedOn = new osg::Material();
		sm_pRedOn->setAmbient(osg::Material::FRONT_AND_BACK, osg::Vec4f(0.2f, 0.0f, 0.0f, 1.0f));
		sm_pRedOn->setDiffuse(osg::Material::FRONT_AND_BACK, osg::Vec4f(0.7f, 0.0f, 0.0f, 1.0f));
		sm_pRedOn->setSpecular(osg::Material::FRONT_AND_BACK, osg::Vec4f(0.6f, 0.0f, 0.0f, 1.0f));
	}
	sm_pRedOn->ref();

	if (!sm_pRedOff)
	{
		sm_pRedOff = new osg::Material();
		sm_pRedOff->setAmbient(osg::Material::FRONT_AND_BACK, osg::Vec4f(0.1f, 0.0f, 0.0f, 1.0f));
		sm_pRedOff->setDiffuse(osg::Material::FRONT_AND_BACK, osg::Vec4f(0.2f, 0.0f, 0.0f, 1.0f));
		sm_pRedOff->setSpecular(osg::Material::FRONT_AND_BACK, osg::Vec4f(0.1f, 0.0f, 0.0f, 1.0f));
	}
	sm_pRedOff->ref();

	if (!sm_pGreenOn)
	{
		sm_pGreenOn = new osg::Material();
		sm_pGreenOn->setAmbient(osg::Material::FRONT_AND_BACK, osg::Vec4f(0.0f, 2.0f, 0.0f, 1.0f));
		sm_pGreenOn->setDiffuse(osg::Material::FRONT_AND_BACK, osg::Vec4f(0.0f, 7.0f, 0.0f, 1.0f));
		sm_pGreenOn->setSpecular(osg::Material::FRONT_AND_BACK, osg::Vec4f(0.0f, 6.0f, 0.0f, 1.0f));
	}
	sm_pGreenOn->ref();

	if (!sm_pGreenOff)
	{
		sm_pGreenOff = new osg::Material();
		sm_pGreenOff->setAmbient(osg::Material::FRONT_AND_BACK, osg::Vec4f(0.0f, 0.1f, 0.0f, 1.0f));
		sm_pGreenOff->setDiffuse(osg::Material::FRONT_AND_BACK, osg::Vec4f(0.0f, 0.2f, 0.0f, 1.0f));
		sm_pGreenOff->setSpecular(osg::Material::FRONT_AND_BACK, osg::Vec4f(0.0f, 0.1f, 0.0f, 1.0f));
	}
	sm_pGreenOff->ref();

	if (!sm_pAmberOn)
	{
		sm_pAmberOn = new osg::Material();
		sm_pAmberOn->setAmbient(osg::Material::FRONT_AND_BACK, osg::Vec4f(0.2f, 2.0f, 0.0f, 1.0f));
		sm_pAmberOn->setDiffuse(osg::Material::FRONT_AND_BACK, osg::Vec4f(0.7f, 7.0f, 0.0f, 1.0f));
		sm_pAmberOn->setSpecular(osg::Material::FRONT_AND_BACK, osg::Vec4f(0.6f, 6.0f, 0.0f, 1.0f));
	}
	sm_pAmberOn->ref();

	if (!sm_pAmberOff)
	{
		sm_pAmberOff = new osg::Material();
		sm_pAmberOff->setAmbient(osg::Material::FRONT_AND_BACK, osg::Vec4f(0.1f, 0.1f, 0.0f, 1.0f));
		sm_pAmberOff->setDiffuse(osg::Material::FRONT_AND_BACK, osg::Vec4f(0.2f, 0.2f, 0.0f, 1.0f));
		sm_pAmberOff->setSpecular(osg::Material::FRONT_AND_BACK, osg::Vec4f(0.1f, 0.1f, 0.0f, 1.0f));
	}
	sm_pAmberOff->ref();

	if (m_pAsset)
	{
		Common::NodeFinderT<osg::Geode> amberFinder("trafficLight::AmberLamp-GEODE");
		Common::NodeFinderT<osg::Geode> redFinder("trafficLight::RedLamp-GEODE");
		Common::NodeFinderT<osg::Geode> greenFinder("trafficLight::GreenLamp-GEODE");

		if (m_pAmber = amberFinder.find(m_pRoot)) m_pAmber->ref();
		if (m_pRed = redFinder.find(m_pRoot)) m_pRed->ref();
		if (m_pGreen = greenFinder.find(m_pRoot)) m_pGreen->ref();
	}
	setState(STOP);
	#pragma endregion

#pragma region Arrow Shader
	
	// Load a texture (Will be displayed above the active traffic light)
	osg::Texture2D* pTexture2D = new osg::Texture2D(osgDB::readImageFile("../../Data/downArrow.png"));
	pTexture2D->setFilter(osg::Texture::MIN_FILTER, osg::Texture::LINEAR_MIPMAP_NEAREST);
	pTexture2D->setFilter(osg::Texture::MAG_FILTER, osg::Texture::LINEAR_MIPMAP_LINEAR);

	// Define the geometry for the simple quad
	// Size of the texture
	osg::Vec3Array* pvVerts = new osg::Vec3Array();
	pvVerts->push_back(osg::Vec3f(-300.0f, 0.0f, -300.0f));
	pvVerts->push_back(osg::Vec3f(300.0f, 0.0f, -300.0f));
	pvVerts->push_back(osg::Vec3f(300.0f, 0.0f, 300.0f));
	pvVerts->push_back(osg::Vec3f(-300.0f, 0.0f, 300.0f));

	osg::Vec3Array* pvNorms = new osg::Vec3Array();
	pvNorms->push_back(osg::Vec3f(0.0f, 1.0f, 0.0f));

	// Points to load the texture from (0 - 1)
	osg::Vec2Array* pvTex0 = new osg::Vec2Array();
	pvTex0->push_back(osg::Vec2f(0.0f, 0.0f));
	pvTex0->push_back(osg::Vec2f(1.0f, 0.0f));
	pvTex0->push_back(osg::Vec2f(1.0f, 1.0f));
	pvTex0->push_back(osg::Vec2f(0.0f, 1.0f));

	osg::Vec2Array* pvTex1 = new osg::Vec2Array();
	pvTex1->push_back(osg::Vec2f(0.0f, 0.0f));
	pvTex1->push_back(osg::Vec2f(1.0f, 0.0f));
	pvTex1->push_back(osg::Vec2f(1.0f, 1.0f));
	pvTex1->push_back(osg::Vec2f(0.0f, 1.0f));

	// Transform of the texture
	osg::MatrixTransform* pTexTransform = new osg::MatrixTransform(osg::Matrix::rotate(osg::DegreesToRadians(0.0f), osg::Vec3f(0.0f, 0.0f, 1.0f)) * osg::Matrix::translate(osg::Vec3f(0.0f, 0.0f, 5000.0f)));

	// Creat the uniform
	osg::Shader* pArrowVert = new osg::Shader(osg::Shader::VERTEX);
	pArrowVert->loadShaderSourceFromFile("../../shaders/downArrow.vert");
	osg::Shader* pArrowFrag = new osg::Shader(osg::Shader::FRAGMENT);
	pArrowFrag->loadShaderSourceFromFile("../../shaders/downArrow.frag");

	osg::Program* pArrowProgram = new osg::Program();
	pArrowProgram->addShader(pArrowVert);
	pArrowProgram->addShader(pArrowFrag);

	m_pArrowStateUniform = new osg::Uniform(osg::Uniform::INT, "arrowState");
	m_pArrowColourUniform = new osg::Uniform(osg::Uniform::FLOAT_VEC4, "arrowColour");

	// Build the geometry
	osg::Geode* pTexGeode = new osg::Geode();
	pTexGeode->getOrCreateStateSet()->setAttributeAndModes(pArrowProgram, osg::StateAttribute::ON);
	pTexGeode->getOrCreateStateSet()->addUniform(m_pArrowStateUniform);
	pTexGeode->getOrCreateStateSet()->addUniform(m_pArrowColourUniform);
	m_pArrowStateUniform->set(0);
	m_pArrowColourUniform->set(osg::Vec4(0.0f, 1.0f, 0.0f, 1.0f));

	osg::Geometry* pQuad = new osg::Geometry();
	pQuad->setVertexArray(pvVerts);
	pQuad->setNormalArray(pvNorms);
	pQuad->setNormalBinding(osg::Geometry::BIND_OVERALL);
	pQuad->setTexCoordArray(0, pvTex0);
	pQuad->setTexCoordArray(1, pvTex1);
	pQuad->addPrimitiveSet(new osg::DrawArrays(GL_QUADS, 0, 4));

	m_pArrowShaderSwitch = new osg::Switch();
	m_pArrowShaderSwitch->setNewChildDefaultValue(false);

	// Add texture to switch (to activate when light is on)
	m_pArrowShaderSwitch->addChild(pTexTransform);
	m_pTransformation->addChild(m_pArrowShaderSwitch);
	pTexTransform->addChild(pTexGeode);
	pTexGeode->addDrawable(pQuad);

	// add the texture to the sahpe
	pTexGeode->getOrCreateStateSet()->setTextureAttributeAndModes(0, pTexture2D);

	//setup the callback for the timer function - glow effect
	pTexGeode->setUpdateCallback(this);
	
#pragma endregion
}

Assignment::ControllableTrafficLightFacade::~ControllableTrafficLightFacade()
{
	if (m_pAmber) m_pAmber->unref();
	if (m_pGreen) m_pGreen->unref();
	if (m_pRed) m_pRed->unref();
	if (sm_pRedOn) sm_pRedOn->unref();
	if (sm_pAmberOn) sm_pAmberOn->unref();
	if (sm_pGreenOn) sm_pGreenOn->unref();
	if (sm_pRedOff) sm_pRedOff->unref();
	if (sm_pAmberOff) sm_pAmberOff->unref();
	if (sm_pGreenOff) sm_pGreenOff->unref();
	if (v_pWCP) delete v_pWCP;
	if (m_pArrowShaderSwitch) m_pArrowShaderSwitch->unref();
	if (m_pArrowStateUniform) m_pArrowStateUniform->unref();
	if (m_pArrowColourUniform) m_pArrowColourUniform->unref();
}

void Assignment::ControllableTrafficLightFacade::setArrowShader(bool bState)
{
	// Activate/deactivate the texture & shader node
	if (bState) {
		m_pArrowShaderSwitch->setAllChildrenOn();
	}
	else {
		m_pArrowShaderSwitch->setAllChildrenOff();
	}
}

void Assignment::ControllableTrafficLightFacade::setShaderColour(LightState eState)
{
	// Set the colour of the shader uniform
	if (eState == STOP) {
		m_pArrowColourUniform->set(osg::Vec4(1.0f, 0.0f, 0.0f, 1.0f));
	}
	else if (eState == READY || eState == SLOW) {
		m_pArrowColourUniform->set(osg::Vec4(0.5f, 1.0f, 0.0f, 1.0f));
	}
	else if (eState == GO) {
		m_pArrowColourUniform->set(osg::Vec4(0.0f, 1.0f, 0.0f, 1.0f));
	}
}

osg::Vec3f Assignment::ControllableTrafficLightFacade::getFacadeCollisionPoint()
{
	// Calculate the collision point if it has not been calculated already
	if (!v_pWCP)
	{
		v_pWCP = new osg::Vec3f();
		osg::Vec3f s;
		osg::Quat r, sr;
		// get the path, from the position target to the root, and decompose the resultant matrix to get the world position of the collision target
		osg::computeLocalToWorld(m_pCollisionTarget->getParentalNodePaths(0)[0]).decompose(*v_pWCP, r, s, sr);
	}
	return *v_pWCP;
}

Assignment::ControllableTrafficLightFacade::LightState Assignment::ControllableTrafficLightFacade::getState()
{
	return lState;
}

void Assignment::ControllableTrafficLightFacade::setState(LightState eState)
{
	// Set the state of the traffic light
	lState = eState;
	switch (lState)
	{
	case STOP:
		m_pRed->getOrCreateStateSet()->setAttributeAndModes(sm_pRedOn);
		m_pAmber->getOrCreateStateSet()->setAttributeAndModes(sm_pAmberOff);
		m_pGreen->getOrCreateStateSet()->setAttributeAndModes(sm_pGreenOff);
		break;
	case READY:
		m_pRed->getOrCreateStateSet()->setAttributeAndModes(sm_pRedOn);
		m_pAmber->getOrCreateStateSet()->setAttributeAndModes(sm_pAmberOn);
		m_pGreen->getOrCreateStateSet()->setAttributeAndModes(sm_pGreenOff);
		break;
	case GO:
		m_pRed->getOrCreateStateSet()->setAttributeAndModes(sm_pRedOff);
		m_pAmber->getOrCreateStateSet()->setAttributeAndModes(sm_pAmberOff);
		m_pGreen->getOrCreateStateSet()->setAttributeAndModes(sm_pGreenOn);
		break;
	case SLOW:
		m_pRed->getOrCreateStateSet()->setAttributeAndModes(sm_pRedOff);
		m_pAmber->getOrCreateStateSet()->setAttributeAndModes(sm_pAmberOn);
		m_pGreen->getOrCreateStateSet()->setAttributeAndModes(sm_pGreenOff);
		break;
	case ALL:
		m_pRed->getOrCreateStateSet()->setAttributeAndModes(sm_pRedOn);
		m_pAmber->getOrCreateStateSet()->setAttributeAndModes(sm_pAmberOn);
		m_pGreen->getOrCreateStateSet()->setAttributeAndModes(sm_pGreenOn);
		break;
	case NONE:
		m_pRed->getOrCreateStateSet()->setAttributeAndModes(sm_pRedOff);
		m_pAmber->getOrCreateStateSet()->setAttributeAndModes(sm_pAmberOff);
		m_pGreen->getOrCreateStateSet()->setAttributeAndModes(sm_pGreenOff);
		break;
	}
}
