using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class AI_Manager : MonoBehaviour
{
    public static AI_Manager instance;

    [Header("Spawner Properties:")]
    public Transform spawnerPos;
    public GameObject AIPrefab;
    public GameObject prefabParent;
    public float spawnSpeed = 0.2f;
    private const int maxSpawns = 10;
    public float counter = 0f;
    private int totalSpawns;

    [Header("Animation:")]
    public Animator animator;

    [Header("End Level Properties:")]
    public TextMeshProUGUI aiText;
    public int aiSaved = 0;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(this);
        }
    }

    private void Start()
    {
        totalSpawns = maxSpawns;
        aiText.text = aiSaved + "/" + maxSpawns;
    }

    void Update()
    {
        // Check level is active before spawning
        if (GameManager.instance.levelStarted)
        {
            // Increase coutner to spawn next object
            if (totalSpawns > 0)
            {
                if (counter >= 1)
                {
                    // Animation
                    animator.SetBool("SpawnBool", true);
                    // Instiate object and set parent
                    GameObject newObj = Instantiate(AIPrefab, new Vector3(spawnerPos.position.x, spawnerPos.position.y, 0), Quaternion.identity);
                    newObj.transform.parent = prefabParent.transform;
                    counter = 0f;
                    totalSpawns--;
                }
                else
                {
                    animator.SetBool("SpawnBool", false);
                    counter += spawnSpeed * Time.deltaTime;
                }
            }
        }

        // Check level is complete
        if (aiSaved == maxSpawns)
        {
            GameManager.instance.LevelComplete();
        }
    }

    public void IncreaseSavedAI()
    {
        // Increase UI Text when ai entity reaches the end point/goal
        aiSaved++;
        aiText.text = aiSaved + "/" + maxSpawns;
        // Play audio
        if (aiSaved == maxSpawns)
        {
            AudioManager.instance.Play("winGame");
        } else
        {
            AudioManager.instance.Play("savedRobot");
        }
    }
}
