using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MouseLagMovement : MonoBehaviour
{
    [SerializeField] private GameObject mousePlayer;
    [SerializeField] private List<GameObject> mouseLagList;
    private Vector3 mousePosition;
    private int frameCounter;
    [SerializeField] private int maxFrameCount = 5;

    private void OnDrawGizmos()
    {
        // Draw radius for spawn distance
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, 12f);
    }

    private void Awake()
    {
        Cursor.lockState = CursorLockMode.Confined;
        Cursor.visible = false;
        // Loop children and add to list
        Transform[] mouseBody = mousePlayer.GetComponentsInChildren<Transform>();
        foreach (Transform child in mouseBody)
        {
            if (child.name == mousePlayer.name) { continue; }
            mouseLagList.Add(child.gameObject);
        }
    }

    private void Update()
    {
        // Get mouse position on screen
        mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        mousePosition.z = Camera.main.transform.position.z + Camera.main.nearClipPlane;
    }

    private void FixedUpdate()
    {
        // Mouse position
        transform.position = mousePosition;
        // Set mouse lag position
        frameCounter++;
        if (frameCounter >= maxFrameCount)
        {
            frameCounter = 0;
            for (int i = mouseLagList.Count - 1; i > 0; i--)
            {
                // Set the position of each gameobject
                mouseLagList[i].transform.position = new Vector3(mouseLagList[i-1].transform.position.x, mouseLagList[i - 1].transform.position.y, mouseLagList[i].transform.position.z);
            }
        }
    }
}
