using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using Unity.VisualScripting;
using UnityEngine;

public class PlayerUpgrades : MonoBehaviour
{
    [Header("Upgrade Buttons")]
    [SerializeField] private GameObject cursorSpawnButton;
    [SerializeField] private GameObject cursorCooldownButton;
    [SerializeField] private GameObject cursorDamageButton;

    [Header("Cursor Shooter Upgrade Properties:")]
    [SerializeField] private GameObject cursorBulletPrefab;
    [SerializeField] private float cursorBulletSpeed = 20f;
    // spawn properties
    [SerializeField] private int totalCursorSpawnsModifier = 1;
    [SerializeField] private float cooldownModifier = 1f;
    [SerializeField] private int damageModifier = 0;
    [SerializeField] private float maxCursorSpawnTimer = 5f;
    [SerializeField] private float cursorSpawnTimer;

    private void Awake()
    {
        cursorSpawnTimer = maxCursorSpawnTimer;
    }

    private void Update()
    {
        // Cursor Powerup Timer
        if (cursorSpawnTimer > 0)
        {
            cursorSpawnTimer -= Time.deltaTime * cooldownModifier;
        } else
        {
            // Coroutine to prevent lag from spawning multiple bullets in a single frame
            StartCoroutine(SpawnCursorBullets());
            cursorSpawnTimer = maxCursorSpawnTimer;
        }
    }

    IEnumerator SpawnCursorBullets()
    {
        // Spawn bullets
        int totalSpawns = totalCursorSpawnsModifier;
        while (totalSpawns > 0)
        {
            BulletManager.instance.StraightBulletSpawn(cursorBulletPrefab, cursorBulletSpeed, damageModifier);
            totalSpawns--;
            // Suspends anymore execution of this function (while loop), until the next frame
            //yield return null;
            yield return new WaitForSeconds(0.05f);
        }
    }

    #region Cursor Shooter Upgrades
    public void UpgradeCursorBulletSpawns()
    {
        // Cap the max spawns
        if (totalCursorSpawnsModifier < 10)
        {
            // Increase total spawns
            totalCursorSpawnsModifier++;
            XPManager.instance.LeveledUp();
            if (totalCursorSpawnsModifier >= 10)
            {
                // Disable upgrade button
                cursorSpawnButton.SetActive(false);
                XPManager.instance.DecreaseTotalUpgrades();
            }
        }
    }
    public void UpgradeCursorCooldown()
    {
        // Cap the max cooldown
        if (cooldownModifier < 20f)
        {
            // Increase cooldown modifier
            cooldownModifier++;
            XPManager.instance.LeveledUp();
            if (cooldownModifier >= 20f)
            {
                // Disable upgrade button
                cursorCooldownButton.SetActive(false);
                XPManager.instance.DecreaseTotalUpgrades();
            }
        }
    }
    public void UpgradeIncreaseDamage()
    {
        if (damageModifier < 15)
        {
            damageModifier++;
            XPManager.instance.LeveledUp();
            if (damageModifier >= 15)
            {
                // Disable upgrade button
                cursorDamageButton.SetActive(false);
                XPManager.instance.DecreaseTotalUpgrades();
            }
        }
    }
    #endregion
}
