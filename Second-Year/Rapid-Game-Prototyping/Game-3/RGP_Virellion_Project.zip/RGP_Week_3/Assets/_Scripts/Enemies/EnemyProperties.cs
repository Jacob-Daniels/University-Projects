using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyProperties : Health
{
    [SerializeField] private float maxHealth = 20f;
    private EnemyMovement movementScript;
    public bool isColliding = false;

    [Header("Animation Properties:")]
    [SerializeField] private Animator animator;
    [SerializeField] private float deathAnimationLength;

    [Header("Damage Properties:")]
    [SerializeField] private float damagePerSecond;

    [Header("XP Points:")]
    [SerializeField] private float xpPoints;

    private void Awake()
    {
        health = maxHealth;
        movementScript = gameObject.GetComponent<EnemyMovement>();
    }

    public override void DestroyObject()
    {
        AudioManager.instance.Play("EnemyDeath");
        // Destroy enemy
        SpawnManager.instance.ReduceCurrentEnemies();
        SpawnManager.instance.currentEnemies.Remove(gameObject.transform);
        XPManager.instance.AddXP(xpPoints);
        // Disable collision and movement
        movementScript.StaticMovement();
        gameObject.GetComponent<PolygonCollider2D>().enabled = false;
        // Play death animation then destroy object
        animator.SetBool("DeathAnimation", true);
        Destroy(gameObject, deathAnimationLength);
    }

    private void OnTriggerStay2D(Collider2D collision)
    {
        // Damage player whilst colliding
        if (collision.gameObject.CompareTag("Player"))
        {
            collision.gameObject.GetComponent<PlayerProperties>().DamagePerSecond(damagePerSecond, false);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        // Hit by bullet
        if (collision.gameObject.CompareTag("Bullet"))
        {
            // Damage enemy
            InstantDamage(collision.gameObject.GetComponent<Bullet>().damage, true);
            // Delete bullet
            Destroy(collision.gameObject);
        }
    }
}
