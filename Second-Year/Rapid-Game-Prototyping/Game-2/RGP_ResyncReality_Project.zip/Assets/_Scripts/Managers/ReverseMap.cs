using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class ReverseMap : MonoBehaviour
{
    public static ReverseMap instance;
    public GameObject[] changeObjects;

    [Header("Colour Properties:")]
    public Material blackMaterial;
    public Material whiteMaterial;
    private Color whiteGradient = Color.white;
    private Color blackGradient = Color.black;
    private bool mapState = true;
    [SerializeField] private float gradientSpeed = 255f;
    private float r = 255, g = 255, b = 255;
    public bool GetState() { return mapState; }

    private void Awake()
    {
        // Singlton
        if (instance == null)
        {
            instance = this;
        } else
        {
            Destroy(gameObject);
        }

        // Grab all objects with tag
        changeObjects = GameObject.FindGameObjectsWithTag("PickupObject");
    }

    void Update()
    {
        // Reverse world colours on key press
        if (Input.GetKeyDown(KeyCode.F))
        {
            // Change object properties
            for (int i = 0; i < changeObjects.Length; i++)
            {
                if (changeObjects[i].GetComponent<ObjectSize>().isBlack)
                {
                    changeObjects[i].GetComponent<ObjectSize>().isBlack = false;
                }
                else
                {
                    changeObjects[i].GetComponent<ObjectSize>().isBlack = true;
                }
            }
            // Reverse the map state
            mapState = !mapState;
            //AudioManager.instance.Play("SwapColour");
            AudioManager.instance.PlayRandomPitch("SwapColour", 1f, 3f);
        }
        
        // Change colour
        if (mapState)
        {
            DecreaseColour();
        } else
        {
            IncreaseColour();
        }
    }

    private void DecreaseColour()
    {
        // Change colour
        if (r > 0 && g > 0 && b > 0)
        {
            // Generate new colour
            blackGradient = new Color(r/255, g/255, b/255, 1);
            whiteGradient = new Color(1 - r / 255, 1 - g / 255, 1 - b / 255, 1);
            r -= gradientSpeed * Time.deltaTime;
            g -= gradientSpeed * Time.deltaTime;
            b -= gradientSpeed * Time.deltaTime;
            // Apply color
            blackMaterial.color = blackGradient;
            whiteMaterial.color = whiteGradient;
        }
    }

    private void IncreaseColour()
    {
        // Change colour
        if (r < 255 & g < 255 && b < 255)
        {
            // Generate new colour
            blackGradient = new Color(r / 255, g / 255, b / 255, 1);
            whiteGradient = new Color(1 - r / 255, 1 - g / 255, 1 - b / 255, 1);
            r += gradientSpeed * Time.deltaTime;
            g += gradientSpeed * Time.deltaTime;
            b += gradientSpeed * Time.deltaTime;
            // Apply color
            blackMaterial.color = blackGradient;
            whiteMaterial.color = whiteGradient;
        }
    }
}
