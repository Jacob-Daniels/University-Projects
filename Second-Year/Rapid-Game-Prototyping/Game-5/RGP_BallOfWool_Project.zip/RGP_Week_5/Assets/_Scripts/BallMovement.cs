using System;
using System.Collections;
using System.Collections.Generic;
using System.IO.IsolatedStorage;
using UnityEngine;

public class BallMovement : MonoBehaviour
{
    [SerializeField] private Vector3 targetPosition;
    [SerializeField] private Rigidbody rb;
    [SerializeField] private float moveSpeed;
    [SerializeField] private Vector3 transformScale = new Vector3(5, 5, 5);
    private bool canMove, autoMove;
    [SerializeField] private float scaleIncrease = 0.01f;
    
    [Header("Rotation Properties:")]
    [SerializeField] private Quaternion lookRotation;
    [SerializeField] private Vector3 direction;
    [SerializeField] private float rotationSpeed = 5f;

    // Methods call by UI buttons
    public void StartRolling()
    {
        autoMove = true;
        targetPosition = MeshManager.instance.GetStartPoint();
    }
    public void StopRolling()
    {
        autoMove = false;
    }
    
    private void Update()
    {
        // Scroll up
        if (Input.GetAxisRaw("Mouse ScrollWheel") > 0 && !autoMove)
        {
            canMove = true;
            targetPosition = MeshManager.instance.GetStartPoint();
        }
        // Scroll down
        if (Input.GetAxisRaw("Mouse ScrollWheel") < 0 && !autoMove)
        {
            canMove = false;
        }
        
        // Check ball is within range of segment
        if (Vector3.Distance(transform.position, targetPosition) < 2)
        {
            MeshManager.instance.DeleteFirstSegment();
            MeshManager.instance.CreateMeshSegment();
            targetPosition = MeshManager.instance.GetStartPoint();
            transformScale += new Vector3(scaleIncrease, scaleIncrease, scaleIncrease);
            if (!autoMove) { canMove = false; }
        }
    }

    private void FixedUpdate()
    {
        // Move towards segment position
        if (canMove || autoMove)
        {
            // Move object
            rb.position = Vector3.MoveTowards(rb.position, targetPosition, moveSpeed * Time.deltaTime);
        }
        
        // Rotate object towards target point
        direction = (targetPosition - rb.position).normalized;
        lookRotation = Quaternion.LookRotation(direction);
        rb.rotation = Quaternion.Slerp(rb.rotation, lookRotation, rotationSpeed * Time.deltaTime);
        
        // Apply new scale
        transform.localScale = transformScale * MeshManager.instance.GetRadius();
    }
}
