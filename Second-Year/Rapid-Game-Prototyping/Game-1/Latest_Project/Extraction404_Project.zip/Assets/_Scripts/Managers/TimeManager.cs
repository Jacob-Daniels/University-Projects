using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
using Unity.VisualScripting;

public class TimeManager : MonoBehaviour
{
    [Header("Timer Properties:")]
    public static TimeManager instance;
    public TextMeshProUGUI timerText;
    public const float maxTimer = 30f;
    private float gameTimer;
    private bool playWarning;
    private int audioCounter;

    [Header("Battery Sprite:")]
    public Image batteryImage;
    public Sprite[] batterySprites;

    private void Awake()
    {
        // Assign instance (Singleton)
        if (instance == null)
        {
            instance = this;
        } else
        {
            Destroy(gameObject);
            return;
        }
        // Set variables
        gameTimer = maxTimer;
        batteryImage.sprite = batterySprites[0];
        playWarning = true;
        audioCounter = 0;
    }

    private void Update()
    {
        // Check Level is active
        if (GameManager.instance.levelStarted)
        {
            // Timer
            if (gameTimer <= 0f)
            {
                GameManager.instance.GameOver("The robots ran out of power! You need to be faster!");
            }
            else
            {
                gameTimer -= Time.deltaTime;
                timerText.text = ((int)gameTimer).ToString() + " seconds";
            }
        }
        // Update battery sprite depending on counter value
        UpdateUIBattery();
    }

    private void UpdateUIBattery()
    {
        switch (gameTimer)
        {
            case > 24f:
                // Green sprite
                batteryImage.sprite = batterySprites[0];
                break;
            case > 18f:
                // Yellow sprite
                batteryImage.sprite = batterySprites[1];
                // Play audio
                if (audioCounter == 0)
                {
                    audioCounter = 1;
                    AudioManager.instance.Play("batteryChange");
                }
                break;
            case > 12f:
                // Orange sprite
                batteryImage.sprite = batterySprites[2];
                // Play audio
                if (audioCounter == 1)
                {
                    audioCounter = 2;
                    AudioManager.instance.Play("batteryChange");
                }
                break;
            case > 6f:
                // Red sprite
                batteryImage.sprite = batterySprites[3];
                // Play audio
                if (audioCounter == 2)
                {
                    audioCounter = 3;
                    AudioManager.instance.Play("batteryChange");
                }
                break;
            case > 0f:
                // Play audio warning
                if (playWarning)
                {
                    AudioManager.instance.Play("batteryWarning");
                    playWarning = false;
                }
                // Red warning sprite
                batteryImage.sprite = batterySprites[4];
                break;
        }
    }

    public void ResetTimer()
    {
        // Reset the timer back to max value
        gameTimer = maxTimer;
        playWarning = true;
        audioCounter = 0;
    }
}
