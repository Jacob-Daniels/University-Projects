using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnManager : MonoBehaviour
{
    public static SpawnManager instance;
    [SerializeField] private Transform player;
    [SerializeField] private Transform spawnParent;
    public List<Transform> currentEnemies = new List<Transform>();

    [Header("Spawn Area:")]
    [SerializeField] private float spawnDistanceFromPlayer = 12f;
    [SerializeField] private float[] horizontalSpawnRange = new float[2] { -31f, 31f };
    [SerializeField] private float[] vertixalSpawnRange = new float[2] { -17f, 17f };

    [Header("Wave Properties:")]
    [SerializeField] private EnemyType[] enemyTypes;
    [SerializeField] private int currentWaveValue;
    [SerializeField] private int totalWaveValue;
    [SerializeField] private int waveIncrease = 10;

    [Header("Spawn Properties:")]
    [SerializeField] private int spawnLimitIncrease;
    public List<GameObject> enemiesToSpawn = new List<GameObject>();
    [SerializeField] private float maxSpawnTimer = 1;
    private float spawnTimer;
    [SerializeField] private int maxSpawnLimit = 10;
    [SerializeField] private int currentSpawns;
    private int currentIncrease = 0;

    #region Setters / Getters
    public void ReduceCurrentEnemies() { currentSpawns--; }
    #endregion

    private void Awake()
    {
        // Singleton
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(instance);
        }
    }

    private void Start()
    {
        spawnTimer = maxSpawnTimer;
    }

    private void FixedUpdate()
    {
        // Check if an enemy can be spawned
        if (spawnTimer <= 0f && currentSpawns < maxSpawnLimit)
        {
            // Spawn enemy from list
            if (enemiesToSpawn.Count > 0)
            {
                SpawnEnemyAtRandomPosition(enemiesToSpawn[0]);
            }
        }
        else if (spawnTimer > 0f)
        {
            spawnTimer -= Time.deltaTime;
        }

        // Generate next wave
        if (enemiesToSpawn.Count <= 0) { GenerateWave(); }

        // Increase spawn count until at max
        int increaseLimit = ((int)TimeManager.instance.GetTime() / spawnLimitIncrease) + (maxSpawnLimit - currentIncrease);
        if (increaseLimit > maxSpawnLimit && increaseLimit <= 200)
        {
            maxSpawnLimit = increaseLimit;
            currentIncrease++;
        }
    }

    public void GenerateWave()
    {
        // Increase the wave value
        currentWaveValue = totalWaveValue;
        totalWaveValue += waveIncrease;
        GenerateEnemies();
    }

    public void GenerateEnemies()
    {
        // List of enemies to spawn
        List<GameObject> generatedEnemies = new List<GameObject>();
        // Get random enemies until wave curreny/value is empty
        while (currentWaveValue > 0)
        {
            int randomIndex = Random.Range(0, enemyTypes.Length);
            int randomEnemyCost = enemyTypes[randomIndex].spawnCost;

            // Check if enemy is affordable
            if (currentWaveValue - randomEnemyCost >= 0)
            {
                generatedEnemies.Add(enemyTypes[randomIndex].prefab);
                currentWaveValue -= randomEnemyCost;
            }
            else if (currentWaveValue <= 0)
            {
                // Break as wave is complete
                break;
            }
        }
        enemiesToSpawn.Clear();
        enemiesToSpawn = generatedEnemies;
    }

    private void SpawnEnemyAtRandomPosition(GameObject _EnemyPrefab)
    {
        // Generate random position
        Vector2 newPosition = GenerateRandomPosition();
        // Check the current position is a valid distance from the player
        float distance = Vector2.Distance(newPosition, player.position);
        if (Mathf.Abs(distance) > spawnDistanceFromPlayer)
        {
            // Spawn enemy
            GameObject newEnemy = Instantiate(_EnemyPrefab, new Vector3(newPosition.x, newPosition.y, spawnParent.position.z), Quaternion.identity);
            newEnemy.transform.parent = spawnParent;
            // Remove enemy from list and reset spawn counter
            enemiesToSpawn.RemoveAt(0);
            spawnTimer = maxSpawnTimer;
            currentSpawns++;
            currentEnemies.Add(newEnemy.transform);
        }
    }
    public Vector2 GenerateRandomPosition()
    {
        // Generate a random vector2 position
        return new Vector2(
            Random.Range(horizontalSpawnRange[0], horizontalSpawnRange[1]),
            Random.Range(vertixalSpawnRange[0], vertixalSpawnRange[1]));
    }
}
