using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    [Header("Damage Properties:")]
    [SerializeField] public float damage = 10f;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Destroy"))
        {
            // Remove from list
            if (gameObject.tag == "EnemyBullet")
            {
                SpawnManager.instance.currentEnemies.Remove(gameObject.transform);
            }
            // Delete object when off screen
            Destroy(gameObject);
            return;
        }
        if (collision.gameObject.CompareTag("EnemyBullet") && gameObject.tag != "EnemyBullet")
        {
            // Remove from list
            SpawnManager.instance.currentEnemies.Remove(collision.gameObject.transform);
            // Destroy bullet if it is ally bullet and colliding with enemy
            Destroy(collision.gameObject);
            Destroy(gameObject);
        }
    }
}
