using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;
using System;

public class AudioManager : MonoBehaviour
{
    public static AudioManager instance;
    public Sound[] sounds;

    private bool canPlayEffects = true;

    private void Awake()
    {
        // Singleton
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
        DontDestroyOnLoad(gameObject);
        // Create a component for each sound in the array
        foreach (Sound s in sounds)
        {
            s.souce = gameObject.AddComponent<AudioSource>();
            s.souce.clip = s.clip;
            s.souce.volume = s.volume;
            s.souce.pitch = s.pitch;
            s.souce.loop = s.loop;
        }
    }
    private void Start()
    {
        Play("BackgroundMusic");
    }

    public void Play(string name)
    {
        Sound s = Array.Find(sounds, sound => sound.name == name);
        if (!canPlayEffects) { return; }
        if (s != null)
        {
            s.souce.Play();
        } else
        {
            Debug.Log("Sound '" + name + "' could not be found in sounds array!");
        }
    }

    public void MuteBackgroundMusic()
    {
        // Mute/play backgroun music, depending on current state
        Sound s = Array.Find(sounds, sound => sound.name == "BackgroundMusic");
        if (s != null)
        {
            if (s.souce.isPlaying)
            {
                s.souce.Pause();
            } else
            {
                s.souce.Play();
            }
        }
    }

    public void MuteSoundEffects()
    {
        // Reverse boolean to play sounds
        canPlayEffects = !canPlayEffects;
    }
}
