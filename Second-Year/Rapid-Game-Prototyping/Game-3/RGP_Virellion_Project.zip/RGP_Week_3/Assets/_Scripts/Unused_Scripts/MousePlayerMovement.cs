using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MousePlayerMovement : MonoBehaviour
{
    [SerializeField] private float speed = 20f;
    [SerializeField] private Vector2 velocity;
    [SerializeField] private Rigidbody2D rb;
    [SerializeField] private Transform mouseObject;
    [SerializeField] private Vector3 mousePosition;

    private void Awake()
    {
        Cursor.visible = false;
    }

    private void Update()
    {
        // Get mouse position
        mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        // Set z position to camera z position
        mousePosition.z = Camera.main.transform.position.z + Camera.main.nearClipPlane;
        // Set object position to mouse position
        mouseObject.position = mousePosition;
    }

    private void FixedUpdate()
    {
        rb.position = Vector2.MoveTowards(rb.position, new Vector2(mousePosition.x, mousePosition.y), speed * Time.deltaTime);
    }
}
