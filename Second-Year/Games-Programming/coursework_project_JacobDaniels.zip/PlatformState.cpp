#include "PlatformController.h"
#include "TextureManager.h"

// States
IdleState::IdleState(PlatformController& player) : PlatformState(player) {
	// Set animation counter
	frameCounter = 1.0f;
}

PlatformState* IdleState::Update(float dt, Input input) {
	// Load idle animation sprite
	frameCounter = frameCounter + (2.0f * dt);
	if (frameCounter > 8) {
		frameCounter = 1;
	}
	player.SetSprite(("idle" + to_string((int)frameCounter)));
	// Start walk state
	if (input.Left() || input.Right()) {
		return new WalkState(player);
	}
	// Check for jump input
	if (input.Jump()) {
		return new JumpState(player);
	}
	// Check if player is in air
	if (!player.GetGroundColl()) {
		return new FallingState(player);
	}
	return nullptr;
}

WalkState::WalkState(PlatformController& player) : PlatformState(player) {
	// Set animation counter
	frameCounter = 1.0f;
}

PlatformState* WalkState::Update(float dt, Input input) {
	// Load walk animation sprite
	frameCounter = frameCounter + (2.0f * dt);
	if (frameCounter >= 4) {
		frameCounter = 1;
	}
	player.SetSprite(("walk" + to_string((int)frameCounter)));
	// Move player
	player.SetVelocity(sf::Vector2f(player.GetSpeed() * (input.Right() - input.Left()), 0.0f));
	// Return to idle state when input has stopped
	if (!input.Left() && !input.Right()) {
		return new IdleState(player);
	}
	// Check for jump input
	if (input.Jump()) {
		return new JumpState(player);
	}
	// Check if player is in air
	if (!player.GetGroundColl()) {
		return new FallingState(player);
	}
	return nullptr;
}

JumpState::JumpState(PlatformController& player) : PlatformState(player) {
	// Set animation counter
	frameCounter = 1.0f;
	// Add velocity
	player.GetVelocity()->y = -player.GetJumpSpeed();
	player.GetVelocity()->x *= 0.5f; // Reduce horizontal speed upon jump
}
PlatformState* JumpState::Update(float dt, Input input) {
	// Load walk animation sprite
	frameCounter = frameCounter + (6.0f * dt);
	if (frameCounter < 6) {
		player.SetSprite(("jump" + to_string((int)frameCounter)));
	}
	// Air controls
	if (!(player.GetWallCollLeft() || player.GetWallCollRight()) && (input.Left() || input.Right())) {
		player.IncreaseVelocity((sf::Vector2f((input.Right() - input.Left()), 0.0f) * (player.GetSpeed() * 2) * dt));
	}
	//  Change to falling state
	if (player.GetVelocity()->y > 0) {
		return new FallingState(player);
	}
	// Change to idle state
	if (player.GetGroundColl()) {
		return new IdleState(player);
	}
}

FallingState::FallingState(PlatformController& player) : PlatformState(player) {
	// Set animation counter
	frameCounter = 6.0f;
}

PlatformState* FallingState::Update(float dt, Input input) {
	// Load jump animation backwards (to simulate falling animation)
	frameCounter = frameCounter - (6.0f * dt);
	if ((int)frameCounter > 0) {
		player.SetSprite(("jump" + to_string((int)frameCounter)));
	}
	// Air controls
	if (!(player.GetWallCollLeft() || player.GetWallCollRight()) && (input.Left() || input.Right())) {
		player.IncreaseVelocity((sf::Vector2f((input.Right() - input.Left()), 0.0f) * (player.GetSpeed() * 2) * dt));
	}
	// Slide down wall
	if ((player.GetWallCollLeft() && input.Left()) || player.GetWallCollRight() && input.Right()) {
		player.GetVelocity()->y = 20.0f;
	}
	// Wall jump
	if (input.Jump()) {
		if (player.GetWallCollLeft()) {
			// Jump right off wall
			player.GetVelocity()->y = -player.GetJumpSpeed();
			player.GetVelocity()->x += player.GetSpeed();
		}
		else if (player.GetWallCollRight()) {
			// Jump left off wall
			player.GetVelocity()->y = -player.GetJumpSpeed();
			player.GetVelocity()->x -= player.GetSpeed();
		}
	}
	else {
		// Walk off wall
		player.IncreaseVelocity((sf::Vector2f((input.Right() - input.Left()), 0.0f) * (player.GetSpeed() * 2) * dt));
	}
	// Check grounded
	if (player.GetGroundColl()) {
		return new IdleState(player);
	}
	return nullptr;
}