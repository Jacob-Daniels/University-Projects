#include "CameraController.h"
#include <iostream>

Assignment::CameraController::CameraController(osgViewer::CompositeViewer* compositeViewer, osg::View* view) : m_pCompositeViewer(compositeViewer), m_pCameraView(view), m_pSelectedCar(0)
{
}

Assignment::CameraController::~CameraController()
{
	if (m_pCompositeViewer) delete m_pCompositeViewer;
	if (m_pCameraView) m_pCameraView->unref();
	if (m_pSelectedCar) delete m_pSelectedCar;
}

void Assignment::CameraController::toggleCamera(AnimatedCar* clickedCar)
{
	// Disable previous cars camera
	if (m_pSelectedCar) m_pSelectedCar->setCameraController(0);

	// Set camera to the clicked car (if same car is clicked then disabled camera)
	if (m_pSelectedCar == clickedCar) {
		m_pCameraView->getCamera()->setViewport(new osg::Viewport(0, 0, 1, 1));
		m_pSelectedCar = 0;
	}
	else {
		m_pCameraView->getCamera()->setViewport(new osg::Viewport(0, 0, 400, 400));

		// Set new cars camera
		m_pSelectedCar = clickedCar;
		m_pSelectedCar->setCameraController(this);
	}
}

void Assignment::CameraController::setTransform(osg::Matrixf& m)
{
	// Set the transform of the camera
	osg::Vec3f e, c, u;
	osg::Vec3f t, s;
	osg::Quat r, sr;

	// Decompose the transform to calculate the rotation and set the position of the car to the camera
	c = osg::Vec3f(0.0f, 1.0f, 0.0f);
	u = osg::Vec3f(0.0f, 0.0f, 1.0f);

	m.decompose(t, r, s, sr);

	// Set the rotation and position of where the camera will look
	c = r * c;
	c += t;
	c += r * osg::Vec3f(50.0f, 0.0f, 0.0f); // Apply an offset from the cars local translation

	// Position of the camera, locally to the cars rotation
	e = t + (r * osg::Vec3f(-500.0f, 0.0f, 400.0f));

	// Apply values to the camera position
	// e = The position of the camera
	// c = Point the camera is looking at
	// u = The Viewport rotation around its centre
	m_pCompositeViewer->getView(1)->getCameraManipulator()->setHomePosition(e, c, u);
	m_pCompositeViewer->getView(1)->getCameraManipulator()->home(1);
}
