using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class PlayerProperties : Health
{
    [Header("Health Properties:")]
    [SerializeField] private float maxHealth = 100f;

    private void Start()
    {
        health = maxHealth;
    }

    public override void DestroyObject()
    {
        // End game
        GameManager.instance.EndGame();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        // Hit by enemy bullet
        if (collision.gameObject.CompareTag("EnemyBullet"))
        {
            // Remove from enemy list
            SpawnManager.instance.currentEnemies.Remove(collision.gameObject.transform);
            // Damage enemy
            InstantDamage(collision.gameObject.GetComponent<Bullet>().damage, false);
            Destroy(collision.gameObject);
        }
    }
}
