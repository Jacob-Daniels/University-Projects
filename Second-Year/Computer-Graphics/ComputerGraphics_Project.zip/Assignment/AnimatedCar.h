#pragma once

#include <windows.h>
#include <osg/AnimationPath>
#include <TrafficSystem/CarFacade.h>

namespace Assignment {
	class CameraController;

	class AnimatedCar : public TrafficSystem::CarFacade
	{
	public:
		// Constructor / destructor 
		AnimatedCar(std::string sName, osg::Node* pAsset, osg::Matrix m, bool bVisible);
		virtual ~AnimatedCar();

		void setAnimationPath(osg::AnimationPath* pPath);
		virtual bool run(osg::Object* object, osg::Object* data); // inherted from the osg::callback (in TrafficSystem::CarFacade)
		virtual osg::Vec3f getFacadeCollisionPoint() override; // inhereted from collision target (cars can have collision targets too
		float addControlPoint(std::string sTile, std::string sPoint, osg::AnimationPath* pPath, float fTime, float fSpeed, osg::Vec3f& rvLastPos, bool bFirst);

		void setCameraController(CameraController* pCC);
		CameraController* getCameraController();

		// Animation speed
		void setAnimationSpeed(float fSpeed);
		float getAnimationSpeed();

	protected:
		osg::MatrixTransform* m_pAnimationTransform; // Stores the animation path
		osg::MatrixTransform* m_pCollisionTarget; // Defines the space transformation for the collision volume
		osg::AnimationPathCallback* m_pAnimationPathCallback;
		bool m_bCurrentState;
		float m_fAnimationSpeed;

		CameraController* m_pCameraController;
	};
}