#pragma once
#include <SFML/Graphics.hpp>
#include "Collision.h"
#include "Input.h"
#include "PlatformState.h"
#include "TextureManager.h"
class PlatformState;

class PlatformController
{
protected:
	sf::Sprite sprite;
	sf::Vector2f pos;
	sf::Vector2f size;
	sf::Vector2f gravity;
	sf::Vector2f vel;
	float speed = 50.0f;
	float jumpSpeed = 400.0f;
	bool groundColl;
	bool wallCollLeft;
	bool wallCollRight;
	bool direction;
	// textures
	void LoadAssets() {
		// Load and sort idle knight image
		TextureManager::Instance().AddTexture("assets/knight_idle.png", sf::IntRect(0, 0, 32, 32), "idle1");
		TextureManager::Instance().AddTexture("assets/knight_idle.png", sf::IntRect(32, 0, 32, 32), "idle2");
		TextureManager::Instance().AddTexture("assets/knight_idle.png", sf::IntRect(64, 0, 32, 32), "idle3");
		TextureManager::Instance().AddTexture("assets/knight_idle.png", sf::IntRect(96, 0, 32, 32), "idle4");
		TextureManager::Instance().AddTexture("assets/knight_idle.png", sf::IntRect(128, 0, 32, 32), "idle5");
		TextureManager::Instance().AddTexture("assets/knight_idle.png", sf::IntRect(160, 0, 32, 32), "idle6");
		TextureManager::Instance().AddTexture("assets/knight_idle.png", sf::IntRect(192, 0, 32, 32), "idle7");
		TextureManager::Instance().AddTexture("assets/knight_idle.png", sf::IntRect(224, 0, 32, 32), "idle8");
		TextureManager::Instance().SetTextureFiltering("assets/knight_idle.png", false);
		// Load and sort jump knight image
		TextureManager::Instance().AddTexture("assets/knight_jump.png", sf::IntRect(0, 0, 32, 32), "jump1");
		TextureManager::Instance().AddTexture("assets/knight_jump.png", sf::IntRect(32, 0, 32, 32), "jump2");
		TextureManager::Instance().AddTexture("assets/knight_jump.png", sf::IntRect(64, 0, 32, 32), "jump3");
		TextureManager::Instance().AddTexture("assets/knight_jump.png", sf::IntRect(96, 0, 32, 32), "jump4");
		TextureManager::Instance().AddTexture("assets/knight_jump.png", sf::IntRect(128, 0, 32, 32), "jump5");
		TextureManager::Instance().SetTextureFiltering("assets/knight_jump.png", false);
		// Load and sort walk knight image
		TextureManager::Instance().AddTexture("assets/knight_walk.png", sf::IntRect(0, 0, 32, 32), "walk1");
		TextureManager::Instance().AddTexture("assets/knight_walk.png", sf::IntRect(32, 0, 32, 32), "walk2");
		TextureManager::Instance().AddTexture("assets/knight_walk.png", sf::IntRect(64, 0, 32, 32), "walk3");
		TextureManager::Instance().SetTextureFiltering("assets/knight_walk.png", false);
		TextureManager::Instance().SetSprite("idle1", sprite);
		sprite.setOrigin(sf::Vector2f(16, 0));
		sprite.setScale(sf::Vector2f(2.5f, 2.5f));
	}
	sf::Texture groundTexture;
	sf::Texture airTexture;
	// State
	PlatformState* state;

public:
	PlatformController() {};
	PlatformController(const sf::Vector2f& pos, const sf::Vector2f& size, const sf::Vector2f& gravity);
	void MoveAndCollide(float dt, Collision& collision);
	void Update(float dt, Collision& collision, Input& input);
	void Draw(sf::RenderWindow& window);

	// Getters
	sf::Vector2f* GetVelocity() { return& vel; }
	float GetJumpSpeed() const { return jumpSpeed; }
 	float GetSpeed() const { return speed; }
	bool GetGroundColl() const { return groundColl; }
	bool GetWallCollLeft() const { return wallCollLeft; }
	bool GetWallCollRight() const { return wallCollRight; }
	// Setters
	void SetSprite(string spriteName) { TextureManager::Instance().SetSprite(spriteName, sprite); }
	void SetVelocity(sf::Vector2f newVelocity) { vel = newVelocity; }
	void IncreaseVelocity(sf::Vector2f newVelocity) { vel += newVelocity; }
	void SetGroundedTexture() { sprite.setTexture(groundTexture); }
	void SetAirTexture() { sprite.setTexture(airTexture); }
};
