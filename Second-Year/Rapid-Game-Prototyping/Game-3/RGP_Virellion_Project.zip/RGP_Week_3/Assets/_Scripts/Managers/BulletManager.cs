using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class BulletManager : MonoBehaviour
{
    public static BulletManager instance;
    public Transform bulletParent;

    [Header("Spawn Properties:")]
    private const float radius = 1f;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        } else
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        bulletParent = GameObject.Find("BulletParent").GetComponent<Transform>();
    }

    public void CircularBulletSpawn(GameObject bulletPrefab, Vector3 startPosition, int bulletsToSpawn, float bulletSpeed)
    {
        StartCoroutine(SpawnBullet(bulletPrefab, startPosition, bulletsToSpawn, bulletSpeed));
    }

    IEnumerator SpawnBullet(GameObject bulletPrefab, Vector3 startPosition, int bulletsToSpawn, float bulletSpeed)
    {
        // Spawn a circle of bullets around the transform position given
        float angleStep = (360f / bulletsToSpawn);
        float angle = 0f + Random.Range(0, 80);

        // Set starting angle and spawn bullet
        for (int i = 0; i <= bulletsToSpawn - 1; i++)
        {
            // Calculate bullet direction
            float bulletDirectionXPosition = startPosition.x + Mathf.Sin((angle * Mathf.PI) / 180) * radius;
            float bulletDirectionYPosition = startPosition.y + Mathf.Cos((angle * Mathf.PI) / 180) * radius;
            Vector3 bulletPosition = new Vector3(bulletDirectionXPosition, bulletDirectionYPosition, 0);
            Vector3 bulletMoveDirection = (bulletPosition - startPosition).normalized * bulletSpeed;

            GameObject newBullet = Instantiate(bulletPrefab, startPosition, Quaternion.identity);
            newBullet.transform.parent = bulletParent;
            newBullet.GetComponent<Rigidbody2D>().velocity = new Vector3(bulletMoveDirection.x, bulletMoveDirection.y, 0);

            angle += angleStep;
            // Add bullet to enemy list
            if (newBullet.tag == "EnemyBullet")
            {
                SpawnManager.instance.currentEnemies.Add(newBullet.transform);
            }
            yield return null;
        }
    }

    #region Cursor Bullet
    public void StraightBulletSpawn(GameObject bulletPrefab, float bulletSpeed, int bulletDamageModifier)
    {
        // Get random target
        Vector3 target = FindTarget();

        // Get mouse position & instantiate bullet
        Vector3 mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        mousePosition.z = 2f;
        GameObject cursorBullet = Instantiate(bulletPrefab, mousePosition, Quaternion.identity);
        // Apply damage modifier
        cursorBullet.GetComponent<Bullet>().damage += bulletDamageModifier;

        // Set initial rotation and direction
        Vector3 direction = (target - cursorBullet.transform.position).normalized;
        // 110 if the rotation modifier to ensure the cursor points towards the direction its moving
        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg - 110;
        direction *= bulletSpeed;
        cursorBullet.GetComponent<Rigidbody2D>().rotation = angle;
        // Apply velocity to object
        cursorBullet.GetComponent<Rigidbody2D>().velocity = new Vector3(direction.x, direction.y, 0);
    }

    private Vector3 FindTarget()
    {
        // Get a random target
        Vector3 target;
        List<Transform> targets = SpawnManager.instance.currentEnemies;
        if (targets.Count > 0)
        {
            target = targets[Random.Range(0, targets.Count)].position;
            return target;
        }
        else
        {
            // Assign random position
            Vector2 randomPos = SpawnManager.instance.GenerateRandomPosition();
            return target = new Vector3(randomPos.x, randomPos.y, 2);
        }
    }
    #endregion
}
