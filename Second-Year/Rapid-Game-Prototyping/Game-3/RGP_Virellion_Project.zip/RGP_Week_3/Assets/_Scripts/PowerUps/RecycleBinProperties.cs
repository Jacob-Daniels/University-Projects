using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RecycleBinProperties : MonoBehaviour
{
    [Header("Bullet properties:")]
    [SerializeField] private GameObject bulletPrefab;
    [SerializeField] private int[] bulletsToSpawn = new int[2] { 10, 20};
    [SerializeField] private float bulletSpeed;
    [SerializeField] private float spawnRate;
    [SerializeField] private int maxSpawnRate;

    [Header("PowerUp Properties:")]
    [SerializeField] private float[] damagePerSecond = new float[2] { 8f, 14f };
    public bool isFull = false;
    private int filesStored;
    [SerializeField] private int maxFiles = 10;
    private float timeToDeleteCounter;
    [SerializeField] private float maxTimeToDelete = 10f;

    private void Update()
    {
        // Check whether bin is full or not
        if (isFull)
        {
            // Spawn/shoot bullets when bin is full
            timeToDeleteCounter -= Time.deltaTime;
            SpawnBullets();
        } else
        {
            // Set bin to full
            if (filesStored >= maxFiles)
            {
                isFull = true;
                timeToDeleteCounter = maxTimeToDelete;
            }
        }

        // Reset bin properties (to Empty)
        if (timeToDeleteCounter <= 0f)
        {
            timeToDeleteCounter = maxTimeToDelete;
            filesStored = 0;
            isFull = false;
        }
    }

    private void SpawnBullets()
    {
        if (spawnRate >= maxSpawnRate)
        {
            // Spawn bullets
            spawnRate = 0f;
            BulletManager.instance.CircularBulletSpawn(bulletPrefab, transform.position, Random.Range(bulletsToSpawn[0], bulletsToSpawn[1]), bulletSpeed);
        } else
        {
            // Decrease bullet spawn timer
            spawnRate += Time.deltaTime;
        }
    }

    private void OnTriggerStay2D(Collider2D collision)
    {
        // Detect collision if not full
        if (!isFull)
        {
            if (collision.gameObject.CompareTag("Enemy"))
            {
                int damageToTarget = (int)Random.Range(damagePerSecond[0], damagePerSecond[1]);
                // Check enemy will be destroyed
                if (collision.gameObject.GetComponent<EnemyProperties>().CheckDPSResult(damageToTarget))
                {
                    filesStored++;
                }
                // Damage enemy
                collision.gameObject.GetComponent<EnemyProperties>().DamagePerSecond(damageToTarget, true);
            } else if (collision.gameObject.CompareTag("EnemyBullet"))
            {
                // Remove from enemy list
                SpawnManager.instance.currentEnemies.Remove(collision.gameObject.transform);
                // Destroy bullet and increase files
                filesStored++;
                DamagePopUp.Create(collision.transform.position, 69, true);
                Destroy(collision.gameObject);
            }
        }
    }
}
