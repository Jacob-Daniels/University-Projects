using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MouseColliderPosition : MonoBehaviour
{
    [SerializeField] private float speed = 5f;
    Vector3 mousePosition;

    private void Awake()
    {
        Cursor.lockState = CursorLockMode.Confined;
        Cursor.visible = false;
    }

    void Update()
    {
        // Get mouse position
        mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        // Set z position to camera z position
        mousePosition.z = Camera.main.transform.position.z + Camera.main.nearClipPlane;
        // Set position
        transform.position = mousePosition;
    }
}
