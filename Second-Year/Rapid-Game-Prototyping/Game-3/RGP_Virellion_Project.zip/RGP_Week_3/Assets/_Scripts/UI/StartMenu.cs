using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class StartMenu : MonoBehaviour
{
    [SerializeField] private Image userImage;
    [SerializeField] private Sprite normalSprite;
    [SerializeField] private Sprite errorSprite;
    [SerializeField] private float counter;
    [SerializeField] private float maxCounter;
    private bool isError;

    private void Update()
    {
        
    }
    private void FixedUpdate()
    {
        if (counter <= 0f)
        {
            isError = false;
        }
        else if (counter >= maxCounter)
        {
            isError= true;
            counter = 0.25f;
        }

        if (isError)
        {
            // Set error sprite and decrease counter
            userImage.sprite = errorSprite;
            counter -= 1 * Time.deltaTime;
        } else
        {
            // Set normal sprite and increase counter
            userImage.sprite = normalSprite;
            counter += 1 * Time.deltaTime;
        }
    }

    public void StartGame()
    {
        AudioManager.instance.Play("MouseClick");
        // Change game state and load next scene
        GameManager.StartGame();
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }

    public void QuitGame()
    {
        GameManager.QuitGame();
    }
}
