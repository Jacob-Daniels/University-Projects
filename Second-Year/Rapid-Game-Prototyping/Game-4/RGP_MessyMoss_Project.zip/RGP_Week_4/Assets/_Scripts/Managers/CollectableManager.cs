using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Tilemaps;

public class CollectableManager : MonoBehaviour
{
    public static CollectableManager instance;

    [Header("Collectable properties:")]
    public List<Collectable> collectablesList;
    [SerializeField] private int completeCollectables;

    [SerializeField] private int currentListSize = 1;
    private int maxListSize = 4;

    [Header("Task Properties:")]
    public int tasksCompleted = 0;

    private void Awake()
    {
        // Singleton
        if (instance == null)
        {
            instance = this;
        } else
        {
            Destroy(gameObject);
        }
    }
    private void Start()
    {
        GenerateNewCollectableList();
    }

    public void CollectablePickedUp(Tile _tilePickedUp)
    {
        /*  Prog Note:
         *      Refine the code below
         *      Override the object name for each collectable (to be the name of its tile)
         *      From there, search the list using list.contains (as this will compare the tile being searched to the name of each collectable)
         */

        // Loop collectables to increase count
        foreach (Collectable collectable in collectablesList)
        {
            // Compare pickedup tile to collectable list
            if (collectable.CompareTo(_tilePickedUp) == 0 && collectable.totalCollected < collectable.maxCollection)
            {
                // Increase stack
                collectable.totalCollected++;
                if (collectable.totalCollected == collectable.maxCollection)
                {
                    // All collectables collected for this type
                    completeCollectables++;
                    CheckAllCollectables();
                    UIManager.instance.UpdateCollectableUI();
                    break;
                }
                // Update UI
                UIManager.instance.UpdateCollectableUI();
            }
        }
    }

    private void CheckAllCollectables()
    {
        // Check whether all collectables are complete
        if (completeCollectables == collectablesList.Count)
        {
            AudioManager.instance.Play("Yay");
            // Set new elements after list is complete
            completeCollectables = 0;
            tasksCompleted++;
            if (currentListSize < maxListSize) { currentListSize++; }
            // Generate a new level and list
            UIManager.instance.DisplayTaskCompleteMessage();
            TilemapManager.instance.GenerateNewLevel();
            GenerateNewCollectableList();
        }
    }

    public void GenerateNewCollectableList()
    {
        // Generate new list of collectables
        collectablesList.Clear();

        // Create a new collectable until max stack is met
        List<int> tilesList = new List<int>();
        for (int i = 0; i < currentListSize; i++)
        {
            // Generate a random index to choose a tile for the collectable
            int newTile = UnityEngine.Random.Range(0, TilemapManager.instance.tiles.Length);
            while (tilesList.Contains(newTile))
            {
                newTile = UnityEngine.Random.Range(0, TilemapManager.instance.tiles.Length);
            }
            tilesList.Add(newTile);

            // Create new collectable and add to list
            Collectable newCollectable = new Collectable(TilemapManager.instance.tiles[newTile]);
            collectablesList.Add(newCollectable);
        }
        // Update UI
        UIManager.instance.UpdateCollectableUI();
    }
}
