using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class MeshSegment : MonoBehaviour
{
    // [Header("Mesh Componenets:")]
    // [SerializeField] private MeshFilter meshFilter;
    // [SerializeField] private MeshCollider meshCollider;
    // [SerializeField] private List<Vector3> vertices;
    // [SerializeField] private List<int> triangles;
    // public List<Vector3> startVertices = new List<Vector3>();
    // public List<Vector3> endVertices = new List<Vector3>();
    //
    // private int xSize, ySize, radius, width;
    // private float angle;
    //
    // [Header("Rotation points:")]
    // public Vector3 segmentRotation;
    // public Vector3 startCenterPoint;
    // public Vector3 endCenterPoint;
    //
    // [Header("Mesh Testing:")]
    // [SerializeField] private GameObject testPrefab;
    // [SerializeField] private GameObject testParent;
    //
    //
    // private void Start()
    // {
    //     // Set values
    //     xSize = MeshManager.instance.GetXSize();
    //     ySize = MeshManager.instance.GetYSize();
    //     radius = MeshManager.instance.GetSegRadius();
    //     width = MeshManager.instance.GetSegWidth();
    //     segmentRotation = MeshManager.instance.GetSegmentRotation();
    //
    //     testParent = GameObject.Find("VertexParent");
    //     
    //     // Create mesh
    //     CreateMesh();
    // }
    //
    // public void CreateMesh()
    // {
    //     //Debug.Log(width);
    //     // Get center points
    //     startCenterPoint = new Vector3(transform.position.x, transform.position.y, transform.position.z);
    //     //endCenterPoint = new Vector3(transform.position.x + xSize, transform.position.y, transform.position.z);
    //     endCenterPoint = new Vector3(transform.position.x + (xSize * width), transform.position.y, transform.position.z);
    //     Quaternion rotation = Quaternion.Euler(segmentRotation);
    //     
    //     // TEST OBJECTS
    //     //Instantiate(testPrefab, segmentRotation * (startCenterPoint - startCenterPoint) + startCenterPoint, Quaternion.identity);
    //     //Instantiate(testPrefab, segmentRotation * (endCenterPoint - startCenterPoint) + startCenterPoint, Quaternion.identity);
    //
    //     // Reset Mesh values
    //     //foreach (Transform child in testParent.transform) { Destroy(child.gameObject); }
    //     vertices.Clear();
    //     triangles.Clear();
    //     float zPoint = 0.0f;
    //     float yPoint = 0.0f;
    //
    //     // Create new mesh
    //     Mesh mesh = new Mesh();
    //     mesh.name = "Custom String Mesh";
    //     
    //     // Create a grid of vertices
    //     for (int index = 0, y = 0; y <= ySize; y++)
    //     {
    //         // Angle and position of vertex points y and z
    //         angle = (1.0f / ySize) * (Mathf.PI * 2) * y;
    //         yPoint = Mathf.Cos(angle) * radius;
    //         zPoint = Mathf.Sin(angle) * radius;
    //         // Create row of vectors at same y & z positions
    //         for (int x = 0; x <= xSize*width; x+=width, index++)
    //         {
    //             // Create vertex with a rotation from start center point
    //             vertices.Add((rotation * (new Vector3(transform.position.x + x, transform.position.y + yPoint, transform.position.z + zPoint) - startCenterPoint) + startCenterPoint) - transform.position);
    //
    //             // TEST: Object position
    //             //GameObject obj2 = Instantiate(testPrefab, rotation * (new Vector3(transform.position.x + x, transform.position.y + yPoint, transform.position.z + zPoint) - startCenterPoint) + startCenterPoint, Quaternion.identity);
    //             //obj2.transform.parent = testParent.transform;
    //             
    //             // Grab start and end vertices
    //             if (x == 0)
    //             {
    //                 startVertices.Add(rotation * (new Vector3(transform.position.x, transform.position.y + yPoint, transform.position.z + zPoint) - startCenterPoint) + startCenterPoint);
    //             }
    //             else if (x == xSize * width)
    //             {
    //                 endVertices.Add(rotation * (new Vector3(transform.position.x + (xSize * width), transform.position.y + yPoint, transform.position.z + zPoint) - startCenterPoint) + startCenterPoint);
    //             }
    //         }
    //     }
    //
    //     // Create triangles
    //     for (int vertexIndex = 0, y = 0; y < ySize; y++, vertexIndex++)
    //     {
    //         // Create row of triangles
    //         for (int x = 0; x < xSize; vertexIndex++, x++)
    //         {
    //             triangles.Add(vertexIndex);
    //             triangles.Add(vertexIndex + xSize + 1);
    //             triangles.Add(vertexIndex + 1);
    //             triangles.Add(vertexIndex + xSize + 1);
    //             triangles.Add(vertexIndex + xSize + 2);
    //             triangles.Add(vertexIndex + 1);
    //         }
    //     }
    //
    //     // Apply mesh
    //     mesh.vertices = vertices.ToArray();
    //     mesh.triangles = triangles.ToArray();
    //     meshFilter.mesh = mesh;
    //     //meshCollider.sharedMesh = mesh;
    // }
}
