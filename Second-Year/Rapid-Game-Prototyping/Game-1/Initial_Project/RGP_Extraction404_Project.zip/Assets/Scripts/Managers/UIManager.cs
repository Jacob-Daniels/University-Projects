using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIManager : MonoBehaviour
{
    public void ButtonClick()
    {
        AudioManager.instance.Play("buttonClick");
    }

    public void StartClick()
    {
        AudioManager.instance.Play("startButtonClick");
    }
}
