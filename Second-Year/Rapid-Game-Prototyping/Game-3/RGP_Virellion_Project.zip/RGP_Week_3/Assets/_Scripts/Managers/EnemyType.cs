using UnityEngine;

[System.Serializable]
public class EnemyType
{
    public GameObject prefab;
    public int spawnCost;
}
