#pragma once

#include <Windows.h>
#include <osg/Switch>

namespace Assignment {
	
	typedef std::list<osg::Switch*> ShaderSwitches;
	typedef std::map<std::string, osg::Program*> Shaders;

	class ShaderController
	{
	public:
		ShaderController();
		virtual ~ShaderController();

		osg::Switch* createShaderSwitch(osg::Node* pDefaultNode, std::string shaderName);
		void toggleShader();

		void storeShader(std::string shaderName, osg::Program* pShaderProgram);
		bool findShader(std::string shaderName);
		osg::Program* getShaderByName(std::string shaderName);

	protected:
		ShaderSwitches m_ShaderSwitches;
		ShaderSwitches::iterator m_ssIterator;
		unsigned int m_ChildIndex;

		Shaders m_mShaders;
	};
}