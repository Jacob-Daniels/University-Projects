using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

[System.Serializable]
public class TilemapTiles
{
    public Tilemap tilemap;
    public string[] tilesName;

    // Spawn range properties
    public int maxPossibleSpawns;
    public int[] xSpawnRange;
    public int[] ySpawnRange;
}
