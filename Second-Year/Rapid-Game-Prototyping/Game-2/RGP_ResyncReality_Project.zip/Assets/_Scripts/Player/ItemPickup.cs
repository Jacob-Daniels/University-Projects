using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemPickup : MonoBehaviour
{
    public static ItemPickup instance;
    [Header("Pickup Properties")]
    [SerializeField] Transform pickupParent;
    public GameObject heldObject;
    private Rigidbody heldObjectRB;

    [Header("Item physics properties:")]
    [SerializeField] private float pickupRange = 5.0f;
    [SerializeField] private float reverseRange = 100f;
    [SerializeField] private float pickupForce = 150.0f;
    public float throwForce = 2000.0f;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        } else
        {
            Destroy(gameObject);
        }
    }

    private void Update()
    {
        // Get pickup input
        if (Input.GetMouseButtonDown(0))
        {
            // Hand is empty
            if (heldObject == null)
            {
                // Check if object exists to pickup
                RaycastHit hit;
                if (Physics.Raycast(transform.position, transform.TransformDirection(Vector3.forward), out hit, pickupRange))
                {
                    if (hit.transform.gameObject.tag == "PickupObject")
                    {
                        pickupParent.localPosition = new Vector3(0f, 0f, 6f + hit.transform.localScale.z / 3);
                        PickupItem(hit.transform.gameObject);
                        AudioManager.instance.PlayPitch("Pickup", 1.2f);
                    }
                }
            }
            else
            {
                DropItem();
                AudioManager.instance.PlayPitch("Pickup", 0.8f);
            }
        }
        // Reverse the state of the item in hand
        if (Input.GetMouseButtonDown(1))
        {
            // Reverse item in hand
            if (heldObject != null && heldObject.GetComponent<ObjectSize>().canReverse)
            {
                heldObject.GetComponent<ObjectSize>().ReverseProperties();
                AudioManager.instance.Play("ReverseObject");
            }
            // Reverse item being looked at
            RaycastHit hit;
            if (Physics.Raycast(transform.position, transform.TransformDirection(Vector3.forward), out hit, reverseRange))
            {
                if (hit.transform.gameObject.tag == "PickupObject")
                {
                    if (hit.transform.gameObject.GetComponent<ObjectSize>().canReverse)
                    {
                        hit.transform.gameObject.GetComponent<ObjectSize>().ReverseProperties();
                        AudioManager.instance.Play("ReverseObject");
                    }
                }
            }
        }
        // Move object if one is held
        if (heldObject != null)
        {
            MoveItem();
        }
    }

    private void MoveItem()
    {
        // Check the distance between the object and the hand/pickup position, to move object
        if (Vector3.Distance(heldObject.transform.position, pickupParent.position) > 0.1f)
        {
            // Grab direction to move object to apply force in that direction
            Vector3 moveDirection = (pickupParent.position - heldObject.transform.position);
            heldObjectRB.AddForce(moveDirection * pickupForce);
        }
    }

    private void PickupItem(GameObject objectToPickup)
    {
        if (objectToPickup.GetComponent<Rigidbody>())
        {
            // Set properties to pickup object
            heldObjectRB = objectToPickup.GetComponent<Rigidbody>();
            heldObjectRB.useGravity = false;
            heldObjectRB.drag = 10;
            heldObjectRB.constraints = RigidbodyConstraints.FreezeRotation;
            // Set parent and pickup object
            heldObject = objectToPickup;
            heldObject.transform.parent = pickupParent;
        }
    }

    public void DropItem()
    {
        // Set properties to drop object
        heldObjectRB.useGravity = true;
        heldObjectRB.drag = 0;
        heldObjectRB.constraints = RigidbodyConstraints.None;
        // Remove parent and pickup object
        heldObject.transform.parent = null;
        heldObject = null;
    }

}
