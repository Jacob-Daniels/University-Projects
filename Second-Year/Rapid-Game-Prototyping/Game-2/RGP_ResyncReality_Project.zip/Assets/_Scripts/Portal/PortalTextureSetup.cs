using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PortalTextureSetup : MonoBehaviour
{
    // White camera
    public Camera cameraWhite;
    public Material cameraMatWhite;
    // Black camera
    public Camera cameraBlack;
    public Material cameraMatBlack;

    void Start()
    {
        // White Camera
        if (cameraWhite.targetTexture != null)
        {
            cameraWhite.targetTexture.Release();
        }
        cameraWhite.targetTexture = new RenderTexture(Screen.width, Screen.height, 24);
        cameraMatWhite.mainTexture = cameraWhite.targetTexture;

        // Black Camera
        if (cameraBlack.targetTexture != null)
        {
            cameraBlack.targetTexture.Release();
        }
        cameraBlack.targetTexture = new RenderTexture(Screen.width, Screen.height, 24);
        cameraMatBlack.mainTexture = cameraBlack.targetTexture;
    }

}
