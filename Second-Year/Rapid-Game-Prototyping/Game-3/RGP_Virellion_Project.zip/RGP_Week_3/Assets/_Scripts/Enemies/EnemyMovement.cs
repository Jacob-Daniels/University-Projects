using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMovement : MonoBehaviour
{
    [Header("Movement Properties:")]
    [SerializeField] private MoveType moveType;
    [SerializeField] private float moveSpeed = 10f;
    [SerializeField] private Rigidbody2D rb;

    [Header("Chase Properties:")]
    [SerializeField] private Transform target;
    private Vector2 moveDirection;

    [Header("Random Properties:")]
    private Vector2 randomPosition;
    [SerializeField] private float distanceFromTarget = 5;
    private Vector2 velocity;
    public float smoothTime = 2f;
    // setter
    public void StaticMovement() { moveType = MoveType.Static; }

    private void Awake()
    {
        // Find target when spawned/instantiated
        if (moveType == MoveType.Chase)
        {
            target = GameObject.Find("MouseHead").transform;
        }
    }

    private void Update()
    {
        // Get movement data depending on type
        switch (moveType)
        {
            case MoveType.Chase:
                // Get the direction and angle towards target position
                Vector3 direction = (target.position - transform.position).normalized;
                float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
                rb.rotation = angle;
                moveDirection = direction;
                break;
            case MoveType.Random:
                // Generate new position if close to current target
                if (Mathf.Abs(Vector3.Distance(transform.position, randomPosition)) < distanceFromTarget)
                {
                    randomPosition = SpawnManager.instance.GenerateRandomPosition();
                }
                break;
        }
    }

    private void FixedUpdate()
    {
        // Check movement type
        switch (moveType)
        {
            case MoveType.Chase:
                // Move towards target position
                rb.position = Vector2.MoveTowards(rb.position, target.position, moveSpeed * Time.deltaTime);
                break;
            case MoveType.Random:
                rb.position = Vector2.SmoothDamp(rb.position, randomPosition, ref velocity, smoothTime);
                break;
        }
    }
    
    private enum MoveType
    {
        // Movement states to assign each enemy to
        Static,
        Chase,
        Bounce,
        Random,
    }
}
