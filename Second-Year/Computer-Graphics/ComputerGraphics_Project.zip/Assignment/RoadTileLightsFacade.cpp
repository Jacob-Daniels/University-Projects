#include "ControllableTrafficLightFacade.h"
#include "RoadTileLightsFacade.h"
#include "SelectionHandler.h"
#include <iostream>

Assignment::RoadTileLightsFacade::RoadTileLightsFacade(std::string sName, osg::Node* pAsset, osg::Matrixf m, bool bVisible) : TrafficSystem::RoadFacade(sName, pAsset, m, bVisible), m_uiCount(0), m_itCurrentLight(m_lLights.end())
{
	// Set the callback loop to the matrix transform so that it callsback to a unique value (E.g. pAsset is referencing to the loaded asset, multiple callbacks to this will cause only the first to work)
	m_pTransformation->setUpdateCallback(this);

	m_pRoot->setUserData(new Assignment::SelectionHandler(this));
}

Assignment::RoadTileLightsFacade::~RoadTileLightsFacade()
{
}

void Assignment::RoadTileLightsFacade::addLight(ControllableTrafficLightFacade* pCTL)
{
	// Add a traffic light to the list
	m_lLights.push_back(pCTL);
	m_pTransformation->addChild(pCTL->root());

	pCTL->setState(ControllableTrafficLightFacade::STOP);
}

bool Assignment::RoadTileLightsFacade::run(osg::Object* object, osg::Object* data)
{
	// Timer for each traffic light state
	if (m_uiCount <= 500)	// 300
	{
		if (m_itCurrentLight == m_lLights.end()) m_itCurrentLight = m_lLights.begin();

		if (m_uiCount == 500)	// 300
		{
			// Red State
			m_uiCount = 0;
			if (m_itCurrentLight != m_lLights.end())
			{
				(*m_itCurrentLight)->setState(ControllableTrafficLightFacade::STOP);
				// Disable arrow shader and set colour
				(*m_itCurrentLight)->setShaderColour(ControllableTrafficLightFacade::STOP);
				(*m_itCurrentLight)->setArrowShader(false);
			}

			// Increment light list iterator
			if (m_lLights.size() > 1)
			{
				m_itCurrentLight++;
				if (m_itCurrentLight == m_lLights.end()) m_itCurrentLight = m_lLights.begin();
			}
			// Amber & Red State
			if (m_itCurrentLight != m_lLights.end()) {
				(*m_itCurrentLight)->setState(ControllableTrafficLightFacade::READY);
				// Enable the arrow shader and set colour
				(*m_itCurrentLight)->setArrowShader(true);
				(*m_itCurrentLight)->setShaderColour(ControllableTrafficLightFacade::READY);
			}
		}
		else if (m_uiCount == 50)	// 50
		{
			// Green State
			if (m_itCurrentLight != m_lLights.end())
			{
				(*m_itCurrentLight)->setState(ControllableTrafficLightFacade::GO);
				// Shader colour
				(*m_itCurrentLight)->setShaderColour(ControllableTrafficLightFacade::GO);
			}
		}
		else if (m_uiCount == 450)	// 250
		{
			// Amber state
			if (m_itCurrentLight != m_lLights.end())
			{
				(*m_itCurrentLight)->setState(ControllableTrafficLightFacade::SLOW);
				// Shader colour
				(*m_itCurrentLight)->setShaderColour(ControllableTrafficLightFacade::SLOW);
			}
		}
		m_uiCount++;
	}
	return false;
}