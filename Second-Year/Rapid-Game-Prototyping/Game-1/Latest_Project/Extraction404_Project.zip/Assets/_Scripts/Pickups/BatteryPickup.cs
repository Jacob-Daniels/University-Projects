using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BatteryPickup : MonoBehaviour
{
    public float rotationSpeed = 250f;

    private void Update()
    {
        // Rotate object
        transform.Rotate(0, rotationSpeed * Time.deltaTime, 0);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "AIEntity")
        {
            // Play audio
            AudioManager.instance.Play("rechargeBattery");
            // Reset timer on pickup
            TimeManager.instance.ResetTimer();
            Destroy(gameObject);
        }
    }
}
