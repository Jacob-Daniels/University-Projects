using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;
using System;
using System.Linq;
using Unity.VisualScripting;

public class AudioManager : MonoBehaviour
{
    public static AudioManager instance;
    public Sound[] sounds;

    private void Awake()
    {
        // Singleton
        if (instance == null)
        {
            instance = this;
        } else
        {
            Destroy(gameObject);
        }
        // Create new component for each audio clip
        foreach (Sound s in sounds)
        {
            s.source = gameObject.AddComponent<AudioSource>();
            s.source.clip = s.clip;
            s.source.volume = s.volume;
            s.source.pitch = s.pitch;
            s.source.loop = s.loop;
        }
        // Play background music
        Play("BackgroundMusic");
    }
    private Sound CheckAudioClip(string name)
    {
        // Find audio source and play clip
        Sound s = Array.Find(sounds, sound => sound.name == name);
        // Return clip
        if (s != null)
        {
            return s;
        }
        else
        {
            Debug.Log("Error. Could not find audio clip: " + s.name);
            return null;
        }
    }

    public void Play(string name)
    {
        // Play clip by name
        Sound s = CheckAudioClip(name);
        if (s != null)
        {
            s.source.Play();
        }
    }
    public void PlayRandomPitch(string name, float start, float end)
    {
        // Play clip with random pitch
        Sound s = CheckAudioClip(name);
        if (s != null)
        {
            s.source.pitch = UnityEngine.Random.Range(start, end);
            s.source.Play();
        }
    }

    public void PlayPitch(string name, float newPitch)
    {
        // Play clip with given pitch
        Sound s = CheckAudioClip(name);
        if (s != null)
        {
            s.source.pitch = newPitch;
            s.source.Play();
        }
    }
}
