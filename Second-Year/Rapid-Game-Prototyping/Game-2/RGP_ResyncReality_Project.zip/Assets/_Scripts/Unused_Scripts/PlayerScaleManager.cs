using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerScaleManager : MonoBehaviour
{
    [Header("Properties:")]
    public Transform player;
    public float stopResizeDistance = 5f;
    public float startResizeDistance = 20f;
    public float smallestSize = 0.1f;
    public float largestSize = 4f;

    private float initialScale;
    public float distanceFromPlayer;
    public float distancePercentage;
    private float previousDistance;

    [Header("Scale type:")]
    public bool upscaleToDistance = false;
    public bool downscaleToDistance = false;
    public bool downscaleByDistance = false;
    public bool upscaleByDistance = false;

    private void OnDrawGizmos()
    {
        // Draw radius (DELETE FOR BUILT VERSION OF THE GAME
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, stopResizeDistance);
        Gizmos.color = Color.blue;
        Gizmos.DrawWireSphere(transform.position, startResizeDistance);
    }

    private void Awake()
    {
        // Assign values
        player = GameObject.Find("Player").GetComponent<Transform>();
        initialScale = player.transform.localScale.x;
    }

    private void Update()
    {
        // Check type of scale to call to
        if (upscaleToDistance)
        {
            UpscaleToDistance();
        }
        else if (downscaleToDistance)
        {
            //DownscaleToDistance();
        }
        else if (downscaleByDistance)
        {
            //DownscaleByDistance();
        }
        else if (upscaleByDistance)
        {
            //UpscaleByDistance();
        }
    }

    #region Upscale by distance
    public void UpscaleByDistance()
    {
        // Reduce players size the closer to the object
        // Calculate distance
        distanceFromPlayer = Vector3.Distance(transform.position, player.position);

        // Calculate percentage for resizing player
        if (distanceFromPlayer > startResizeDistance)
        {
            distancePercentage = 100f;
        }
        else
        {
            distancePercentage = Mathf.Abs(startResizeDistance / distanceFromPlayer);
        }
        // Set previous distance
        if (distanceFromPlayer > startResizeDistance)
        {
            previousDistance = distanceFromPlayer;
            initialScale = player.localScale.x;
        }

        // Resize player
        if (distanceFromPlayer < startResizeDistance && distanceFromPlayer > stopResizeDistance)
        {
            // Moving towards the object
            if (previousDistance > distanceFromPlayer)
            {
                // Change players size by local size
                //float newScale = Mathf.Abs(initialScale * distancePercentage);
                float newScale = Mathf.Abs(initialScale * 1.01f);
                if (newScale > smallestSize && newScale < largestSize)
                {
                    player.transform.localScale = new Vector3(newScale, newScale, newScale);
                }
            }
            else
            {
                // Reset initial scale to prevent reverting players original scale
                initialScale = player.localScale.x;
            }
        }
        previousDistance = distanceFromPlayer;
    }
    #endregion

    #region Scale by distance
    public void DownscaleByDistance()
    {
        // Reduce players size the closer to the object
        // Calculate distance
        distanceFromPlayer = Vector3.Distance(transform.position, player.position);

        // Calculate percentage for resizing player
        if (distanceFromPlayer > startResizeDistance)
        {
            distancePercentage = 100f;
        }
        else
        {
            distancePercentage = Mathf.Abs(distanceFromPlayer / startResizeDistance);
        }
        // Set previous distance
        if (distanceFromPlayer > startResizeDistance)
        {
            previousDistance = distanceFromPlayer;
            initialScale = player.localScale.x;
        }

        // Resize player
        if (distanceFromPlayer < startResizeDistance && distanceFromPlayer > stopResizeDistance)
        {
            // Moving towards the object
            if (previousDistance > distanceFromPlayer)
            {
                // Change players size by local size
                float newScale = Mathf.Abs(initialScale * distancePercentage);
                if (newScale > smallestSize && newScale < initialScale)
                {
                    player.transform.localScale = new Vector3(newScale, newScale, newScale);
                }
            }
            else
            {
                // Reset initial scale to prevent reverting players original scale
                initialScale = player.localScale.x;
            }
        }
        previousDistance = distanceFromPlayer;
    }
    #endregion

    #region Downscale to distance
    private void DownscaleToDistance()
    {
        // Scale players size to the distance to/from an object
        // Calculate distance
        distanceFromPlayer = Vector3.Distance(transform.position, player.position);

        // Calculate percentage for resizing player
        if (distanceFromPlayer > startResizeDistance)
        {
            distancePercentage = 100f;
        }
        else
        {
            distancePercentage = Mathf.Abs(startResizeDistance / distanceFromPlayer);
        }

        // Resize player
        if (distanceFromPlayer < startResizeDistance && distanceFromPlayer > stopResizeDistance)
        {
            // Set scale by percentage
            float newScale = Mathf.Abs(initialScale * distancePercentage);
            if (newScale > smallestSize && newScale < largestSize)
            {
                player.transform.localScale = new Vector3(newScale, newScale, newScale);
            }
        }
    }
    #endregion

    #region Scale to distance
    private void UpscaleToDistance()
    {
        // Scale players size to the distance to/from an object
        // Calculate distance
        distanceFromPlayer = Vector3.Distance(transform.position, player.position);

        // Calculate percentage for resizing player
        if (distanceFromPlayer > startResizeDistance)
        {
            distancePercentage = 100f;
        }
        else
        {
            distancePercentage = Mathf.Abs(distanceFromPlayer / startResizeDistance);
        }

        // Resize player
        if (distanceFromPlayer < startResizeDistance && distanceFromPlayer > stopResizeDistance)
        {
            // Set scale by percentage
            float newScale = Mathf.Abs(initialScale * distancePercentage);
            if (newScale > smallestSize && newScale < initialScale)
            {
                player.transform.localScale = new Vector3(newScale, newScale, newScale);
            }
        }
    }
    #endregion
}
