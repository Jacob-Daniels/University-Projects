using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public CharacterController controller;
    public float speed = 12f;
    public float jumpHeight = 2.5f;

    [Header("Ground Properties:")]
    public float gravity = -9.81f;
    public Transform groundCheck;
    public float groundDistance = 0.4f;
    public LayerMask groundMask, groundMask2;

    [SerializeField] private Vector3 velocity;
    bool isGrounded, isGrounded2;

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(groundCheck.position, groundDistance);
    }

    void Update()
    {
        isGrounded = Physics.CheckSphere(groundCheck.position, groundDistance, groundMask);
        isGrounded2 = Physics.CheckSphere(groundCheck.position, groundDistance, groundMask2);
        // Grounded
        if ((isGrounded && velocity.y < 0) || (isGrounded2 && velocity.y < 0))
        {
            velocity.y = -5f;
        }

        // Get movement input
        float x = Input.GetAxis("Horizontal");
        float z = Input.GetAxis("Vertical");

        // Get local movement direction (from direction facing)
        Vector3 move = transform.right * x + transform.forward * z;

        // Move player
        controller.Move(move * speed * Time.deltaTime);

        // Player Jump
        if (Input.GetButtonDown("Jump") && (isGrounded || isGrounded2))
        {
            AudioManager.instance.Play("Jump");
            velocity.y = Mathf.Sqrt(jumpHeight * -2f * gravity);
        }

        // Gravity
        velocity.y += gravity * Time.deltaTime;
        controller.Move(velocity * Time.deltaTime);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Finish")
        {
            GameManager.instance.GameComplete();
        }
    }
}
