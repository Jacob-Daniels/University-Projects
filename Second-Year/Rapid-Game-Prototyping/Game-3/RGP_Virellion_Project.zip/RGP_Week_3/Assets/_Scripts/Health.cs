using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Health : MonoBehaviour
{
    public float health;
    [SerializeField] private float takeDamageMaxTimer = 0.1f;
    private float takeDamageTimer = 0.1f;

    public virtual void DestroyObject() { }

    private void Update()
    {
        // Reduce damage timer
        if (takeDamageTimer > 0f)
        {
            takeDamageTimer -= Time.deltaTime;
        }
    }

    public void DamagePerSecond(float damagePerSecond, bool isEnemy)
    {
        // Return if enemy can't take damage
        if (!CanTakeDamage())
        {
            return;
        }
        // Destroy enemy or remove health over time
        if (health - damagePerSecond * Time.deltaTime < 0f)
        {
            DestroyObject();
        }
        else
        {
            health -= damagePerSecond * Time.deltaTime;
            // Display damage output
            DamagePopUp.Create(transform.position, (int)(damagePerSecond * Time.deltaTime * 10), isEnemy);
            takeDamageTimer = takeDamageMaxTimer;
        }
    }

    public void InstantDamage(float instantDamage, bool isEnemy)
    {
        // Display damage popup
        DamagePopUp.Create(transform.position, (int)instantDamage, isEnemy);
        // Destroy enemy or remove health
        if (health - instantDamage < 0f)
        {
            DestroyObject();
        }
        else
        {
            health -= instantDamage;
        }
    }

    public bool CheckDPSResult(float damage)
    {
        // Break if enemy cant take damage
        if (!CanTakeDamage())
        {
            return false;
        }
        // Return true if object will be destroyed after taking damage
        if (health - damage * Time.deltaTime < 0f)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    private bool CanTakeDamage()
    {
        // Can enemy take damage
        if (takeDamageTimer <= 0f)
        {
            return true;
        } else
        {
            return false;
        }
    }
}
