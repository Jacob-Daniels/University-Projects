using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager instance;
    [Header("Game Over:")]
    public static bool gameOver;
    public GameObject GameOverUI;
    public TextMeshProUGUI gameoverText;
    public bool levelStarted;

    [Header("End Level:")]
    public GameObject winPanel;

    private void Awake()
    {
        // Singleton
        if (instance == null)
        {
            instance = this;
        } else
        {
            Destroy(gameObject);
            return;
        }
        // Set variables
        gameOver = false;
        levelStarted = false;
        if (winPanel) winPanel.SetActive(false);
    }

    public void PauseGame()
    {
        Time.timeScale = 0.0f;
    }

    public void ResumeGame()
    {
        Time.timeScale = 1.0f;
    }
    
    public void StartLevel()
    {
        // Start Level
        if (!levelStarted)
        {
            TilemapManager.instance.tileLimitText.text = "Controls remaining: \u221E";
            levelStarted = true;
        }
    }

    public void LevelComplete()
    {
        // Game won
        winPanel.SetActive(true);
        if (!gameOver)
        {
            gameOver = true;
            PauseGame();
        }
    }

    public void RestartLevel()
    {
        // Reload level
        ResumeGame();
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    public void ReturnToMainMenu()
    {
        // Load the main menu scene
        ResumeGame();
        SceneManager.LoadScene(0);
    }
    
    public void GameOver(string gmText)
    {
        // Display game over ui
        gameoverText.text = gmText;
        GameOverUI.SetActive(true);
        // Pause game
        if (!gameOver)
        {
            gameOver = true;
            PauseGame();
        }
    }
}
