using Mono.Cecil;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;
using System;

public class TilemapManager : MonoBehaviour
{
    public static TilemapManager instance;

    [Header("Tilemap Spawn Properties:")]
    public TilemapTiles[] tilemapTiles;
    [SerializeField] private int[] tileRotations;

    [Header("Tile Spawn Properties:")]
    public TileProperties[] tiles;
    // 38 x 22 full border = 836
    // 36 x 20 spawn radius = 720
    [SerializeField] private int currentTilesSpawned;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        } else
        {
            Destroy(gameObject);
        }
        // Spawn level
        GenerateNewLevel();
    }
    
    public void GenerateNewLevel()
    {
        // Iterate through each tilemap to spawn tiles for new level
        foreach (TilemapTiles _tilemap in tilemapTiles)
        {
            // Reset tilemap and tiles counter
            _tilemap.tilemap.ClearAllTiles();
            currentTilesSpawned = 0;
            // Loop the tile types for tilemap
            foreach (string _tileName in _tilemap.tilesName)
            {
                // Find tile in array by name
                TileProperties currentTile = Array.Find(tiles, tile => tile.name == _tileName);
                if (currentTile == null)
                { 
                    Debug.Log("No tile named: " + _tileName);
                    continue;
                }

                // Reset total tile count
                currentTile.totalspawn = 0;
                // Break if tilemap is full
                if (currentTilesSpawned >= _tilemap.maxPossibleSpawns) { break; }
                // Spawn a random number of each tile on the tilemap (depending on its max spawns)
                for (int i = 0; i <= UnityEngine.Random.Range(currentTile.minSpawn, currentTile.maxSpawn); i++)
                {
                    // Check if tilemap is full
                    if (currentTilesSpawned >= _tilemap.maxPossibleSpawns) { break; }

                    // Generate random position & Spawn tile on tilemap (ensure tile doesn't already exist at position);
                    Vector3Int tilePosition = new Vector3Int(UnityEngine.Random.Range(_tilemap.xSpawnRange[0], _tilemap.xSpawnRange[1]), UnityEngine.Random.Range(_tilemap.ySpawnRange[0], _tilemap.ySpawnRange[1]), 0);
                    while (_tilemap.tilemap.GetTile(tilePosition) != null)
                    {
                        tilePosition = new Vector3Int(UnityEngine.Random.Range(_tilemap.xSpawnRange[0], _tilemap.xSpawnRange[1]), UnityEngine.Random.Range(_tilemap.ySpawnRange[0], _tilemap.ySpawnRange[1]), 0);
                    }

                    // Check if tile can be rotated
                    Matrix4x4 tileTransform;
                    if (currentTile.canRotate)
                    {
                        tileTransform = Matrix4x4.Translate(new Vector3(0, 0, 1)) * Matrix4x4.Rotate(Quaternion.Euler(0, 0, tileRotations[UnityEngine.Random.Range(0, 4)]));
                    }
                    else
                    {
                        tileTransform = Matrix4x4.Translate(new Vector3(0, 0, 1)) * Matrix4x4.Rotate(Quaternion.Euler(0, 0, 0));
                    }
                    // Set the tile properties before placing on tilemap (rotation & position)
                    TileChangeData tileData = new TileChangeData
                    {
                        position = tilePosition,
                        tile = currentTile.tile,
                        color = Color.white,
                        transform = tileTransform
                    };
                    // Place tile on tilemap
                    _tilemap.tilemap.SetTile(tileData, false);
                    // Increase coutners
                    currentTile.totalspawn++;
                    currentTilesSpawned++;
                }
            }
        }
    }
}
