using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class AI_Spawner : MonoBehaviour
{
    public static AI_Spawner instance;

    [Header("Spawner Properties:")]
    public GameObject AIPrefab;
    public GameObject prefabParent;
    public float spawnSpeed = 0.2f;
    public const int maxSpawns = 10;
    public float counter = 0f;
    private int totalSpawns;

    [Header("Animation:")]
    public Animator animator;

    [Header("AI Saved Properties:")]
    public TextMeshProUGUI aiText;
    private int aiSaved = 0;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        } else
        {
            Destroy(this);
        }
    }

    private void Start()
    {
        totalSpawns = maxSpawns;
        aiText.text = aiSaved + "/" + maxSpawns;
    }

    void Update()
    {
        // Check level is active before spawning
        if (GameManager.instance.levelStarted)
        {
            // Increase coutner to spawn next object
            if (totalSpawns > 0)
            {
                if (counter >= 1)
                {
                    // Animation
                    animator.SetBool("SpawnBool", true);
                    // Instiate object and set parent
                    GameObject newObj = Instantiate(AIPrefab, new Vector3(transform.position.x, transform.position.y, 0), Quaternion.identity);
                    newObj.transform.parent = prefabParent.transform;
                    counter = 0f;
                    totalSpawns--;
                }
                else
                {
                    animator.SetBool("SpawnBool", false);
                    counter += spawnSpeed * Time.deltaTime;
                }
            }
        }
    }

    public void IncreaseSavedAI()
    {
        // Increase UI Text when ai entity reaches the end point/goal
        aiSaved++;
        aiText.text = aiSaved + "/" + maxSpawns;
    }
}
