using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    [SerializeField] private Camera playerCamera;
    [SerializeField] private float moveSpeed;
    [SerializeField] private float rotationSpeed;
    [SerializeField] private LayerMask layerMask;

    private RaycastHit hit;
    private Vector3 targetPosition;
    private bool movePlayer = false;

    private void Update()
    {
        // Get screen mouse position, and convert to world position
        Ray ray = playerCamera.ScreenPointToRay(Input.mousePosition);
        if (Physics.Raycast(ray, out hit, Mathf.Infinity, layerMask))
        {
            targetPosition = hit.point;
            if (Vector3.Distance(hit.point, transform.position) > 1)
            {
                movePlayer = true;
            } else
            {
                movePlayer = false;
            }
        } else
        {
            movePlayer = false;
        }


    }

    private void FixedUpdate()
    {
        // Move position of object to mouse position
        if (movePlayer)
        {
            transform.position = Vector3.MoveTowards(transform.position, targetPosition, moveSpeed * Time.deltaTime);
            // Rotation
            float offsetY = 45.0f;
            Vector3 direction = new Vector3(targetPosition.x - transform.position.x, (targetPosition.y - transform.position.y) + offsetY, targetPosition.z - transform.position.z).normalized;
            transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(direction), moveSpeed * Time.deltaTime);
            // Clamp angles
            transform.eulerAngles = new Vector3(0, transform.eulerAngles.y, 90);
        }
    }
}
