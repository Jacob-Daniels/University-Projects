using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using Unity.VisualScripting;
using UnityEngine;

public class ObjectSize : MonoBehaviour
{
    [Header("Size properties:")]
    [SerializeField] private float scaleSpeed = 2f;
    public bool isBlack = false;
    public bool canReverse = false;
    [SerializeField] Vector3 largestSize;
    [SerializeField] Vector3 smallestSize;

    private void Awake()
    {
        // Ensure object is reversed
        if (canReverse)
        {
            isBlack = false;
        }
    }

    private void Update()
    {
        // Set the size depending on objects state
        if (canReverse)
        {
            ReverseForm();
        }
        else
        {
            CheckSize();
        }
    }

    public void ReverseProperties()
    {
        isBlack = !isBlack;
    }

    private void CheckSize()
    {
        // Resize object depending on colour/material
        if (!isBlack)
        {
            transform.localScale = Vector3.Lerp(transform.localScale, smallestSize, Time.deltaTime * scaleSpeed);
        } else
        {
            transform.localScale = Vector3.Lerp(transform.localScale, largestSize, Time.deltaTime * scaleSpeed);
        }
    }

    private void ReverseForm()
    {
        // Reversed size and material
        if (!isBlack)
        {
            transform.localScale = Vector3.Lerp(transform.localScale, smallestSize, Time.deltaTime * scaleSpeed);
        }
        else
        {
            transform.localScale = Vector3.Lerp(transform.localScale, largestSize, Time.deltaTime * scaleSpeed);
        }
    }
}
