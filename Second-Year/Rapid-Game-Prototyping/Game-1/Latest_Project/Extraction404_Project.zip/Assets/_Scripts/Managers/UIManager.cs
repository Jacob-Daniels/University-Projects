using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIManager : MonoBehaviour
{
    [SerializeField] private GameObject pauseMenuPanel;

    private void Update()
    {
        // Check pause button was pressed
        if (Input.GetKeyDown(KeyCode.Escape) || Input.GetKeyDown(KeyCode.P))
        {
            PauseMenuState();
        }
    }

    public void PauseMenuState()
    {
        // Check to pause/unpause the game
        if (pauseMenuPanel.activeSelf)
        {
            GameManager.instance.ResumeGame();
            pauseMenuPanel.SetActive(false);
        }
        else
        {
            GameManager.instance.PauseGame();
            pauseMenuPanel.SetActive(true);
        }
    }

    public void ButtonClick()
    {
        AudioManager.instance.Play("buttonClick");
    }

    public void StartClick()
    {
        AudioManager.instance.Play("startButtonClick");
    }
}
