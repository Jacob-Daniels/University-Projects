using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

[System.Serializable]
public class Collectable : TileProperties, IComparable<Tile>
{
    public int maxCollection;
    public int totalCollected;

    public Collectable() { }
    public Collectable(TileProperties newTile)
    {
        tile = newTile.tile;
        sprite = newTile.sprite;
        name = newTile.name;
        maxSpawn = newTile.maxSpawn;
        minSpawn = newTile.minSpawn;
        totalspawn = newTile.totalspawn;
        canRotate = newTile.canRotate;
        maxCollectable = newTile.maxCollectable;
        
        // Check whether to collect all total spawned tiles or a random amount
        if (maxCollectable)
        {
            maxCollection = totalspawn;
        } else
        {
            maxCollection = UnityEngine.Random.Range(1,totalspawn / 3);
        }
        totalCollected = 0;
    }

    public int CompareTo(Tile other)
    {
        if (this.tile == other)
        {
            // same as
            return 0;
        }
        // 1 = greater & -1 = less than
        return 1;
    }
}
