using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class TimeManager : MonoBehaviour
{
    public static TimeManager instance;
    [SerializeField] private TextMeshProUGUI timerText;
    [SerializeField] private float currentGameTime;

    // Getters
    public float GetTime() { return currentGameTime; }
    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        } else
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        currentGameTime = 0f;
    }

    private void Update()
    {
        // Increase timer
        currentGameTime += Time.deltaTime;
        // Display time on screen
        DisplayTime();
    }

    private void DisplayTime()
    {
        // Format timer to string
        float minutes = Mathf.FloorToInt(currentGameTime / 60);
        float seconds = Mathf.FloorToInt(currentGameTime % 60);

        timerText.text = string.Format("{0:00} : {1:00}", minutes, seconds);
    }
}
