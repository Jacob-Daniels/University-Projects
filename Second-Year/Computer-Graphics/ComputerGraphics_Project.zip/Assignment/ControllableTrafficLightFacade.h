#pragma once

#include <windows.h>
#include <osg/Material>
#include <TrafficSystem/TrafficLightFacade.h>

#define ARROW_SHADER

namespace Assignment
{
	class ControllableTrafficLightFacade: public TrafficSystem::TrafficLightFacade, public osg::Callback
	{
	public:
		enum LightState
		{
			STOP,
			READY,
			GO,
			SLOW,
			ALL,
			NONE,
		};

		ControllableTrafficLightFacade(std::string sname, osg::Node* pAsset, osg::Matrixf m, bool bVisible);
		virtual ~ControllableTrafficLightFacade();
		virtual osg::Vec3f getFacadeCollisionPoint() override;

		void setState(LightState eState);
		LightState getState();

		void setArrowShader(bool bState);
		void setShaderColour(LightState eState);

	protected:
		LightState lState;
		static osg::Material* sm_pRedOn;
		static osg::Material* sm_pGreenOn;
		static osg::Material* sm_pAmberOn;
		static osg::Material* sm_pRedOff;
		static osg::Material* sm_pGreenOff;
		static osg::Material* sm_pAmberOff;

		osg::Geode* m_pAmber;
		osg::Geode* m_pRed;
		osg::Geode* m_pGreen;

		osg::Vec3f* v_pWCP;

		// Arrow Shader for controllable state display
		osg::Switch* m_pArrowShaderSwitch;
		osg::Uniform* m_pArrowStateUniform;
		osg::Uniform* m_pArrowColourUniform;
	};
}
