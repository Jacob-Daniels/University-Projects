using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UIElements;

public class ButtonHover : MonoBehaviour
{
    [SerializeField] private Color hoveredColour;
    [SerializeField] private Color defaultColour;

    public void OnHoverEnter(TextMeshProUGUI textColour)
    {
        // Change alpha colour of button text
        textColour.color = defaultColour;
    }

    public void OnHoverExit(TextMeshProUGUI textColour)
    {
        // Change alpha colour of button text
        textColour.color = hoveredColour;
    }
}
