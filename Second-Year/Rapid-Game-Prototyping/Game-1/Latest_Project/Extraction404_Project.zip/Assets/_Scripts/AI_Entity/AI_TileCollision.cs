using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;
using UnityEngine.Tilemaps;

public class AI_TileCollision : MonoBehaviour
{
    public AI_Movement movementScript;
    public AI_Modifiers modScipt;

    private void OnTriggerStay2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Modifier")
        {
            GetCollisionTile("Stay");
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Modifier")
        {
            GetCollisionTile("Enter");
        }
        // AI collising with hazard
        if (collision.gameObject.tag == "Hazard")
        {
            GameManager.instance.GameOver("A robot died! Lets try again!");
            Destroy(gameObject);
        }
    }

    void GetCollisionTile(string trigType)
    {
        // Array of surrounding vector positions
        Vector3Int[] checkTiles = new Vector3Int[12];
        Vector3Int colTilePos = TilemapManager.instance.modifierTilemap.WorldToCell(gameObject.transform.position);
        // Loop column elements
        int index = 0;
        for (int y = colTilePos.y + 1; y > colTilePos.y - 3; y--)
        {
            // Loop row elements
            for (int x = colTilePos.x - 1; x < colTilePos.x + 2; x++, index++)
            {
                checkTiles[index] = new Vector3Int(x, y, colTilePos.z);
            }
        }
        // Loop tiles and place on map
        foreach (Vector3Int tilePos in checkTiles)
        {
            // Check whether tile colliding is a modifier tile
            AnimatedTile trigTile = TilemapManager.instance.CheckTileColl(tilePos);
            if (trigTile != null)
            {
                // Check tigger type before applying force
                if (trigType == "Stay")
                {
                    CheckTileTypeOnStay(trigTile);
                } else if (trigType == "Enter")
                {
                    CheckTileTypeOnEnter(trigTile);
                }
            }
        }
    }

    private void CheckTileTypeOnStay(AnimatedTile trigTile)
    {
        // Check tile type of collision
        if (trigTile == TilemapManager.instance.tiles[1])
        {
            // up
            modScipt.UpForce();
        }
        else if (trigTile == TilemapManager.instance.tiles[2])
        {
            // down
            modScipt.DownForce();
        }
        else if (trigTile == TilemapManager.instance.tiles[3])
        {
            // left
            modScipt.LeftForce();
        }
        else if (trigTile == TilemapManager.instance.tiles[4])
        {
            // Right
            modScipt.RightForce();
        }
        if (trigTile == TilemapManager.instance.tiles[5])
        {
            // Reduce velocity
            modScipt.ResetVelocity();
        }
    }

    private void CheckTileTypeOnEnter(AnimatedTile trigTile)
    {
        if (trigTile == TilemapManager.instance.tiles[6])
        {
            // Change direction
            modScipt.FlipDirection();
        }
    }
}