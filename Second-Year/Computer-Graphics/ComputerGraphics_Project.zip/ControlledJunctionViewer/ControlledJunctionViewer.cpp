#include <windows.h>
#include <iostream>
#include <osgViewer/Viewer>
#include <osgViewer/ViewerEventHandlers>
#include <osgViewer/CompositeViewer>
#include <osgGA/StateSetManipulator>
#include <osgDB/ReadFile>
#include <osgGA/DriveManipulator>
#include <osgGA/TrackballManipulator>

#include <Common/Facade.h>
#include <Common/FacadeFactory.h>
#include <Common/Printer.h>
#include <Common/AssetLibrary.h>
#include <Common/FacadeManufactory.h>
#include <Common/NodeFinder.h>

#include <TrafficSystem/RoadFacadeFactory.h>
#include <TrafficSystem/RoadFacade.h>
#include <TrafficSystem/TrafficLightFacadeFactory.h>
#include <TrafficSystem/TrafficLightFacade.h>
#include <TrafficSystem/CarFacadeFactory.h>
#include <TrafficSystem/CarFacade.h>
#include <TrafficSystem/AnimationPointFinder.h>
#include <TrafficSystem/Collider.h>

#include <Assignment/AnimatedCar.h>
#include <Assignment/AnimatedCarFactory.h>
#include <Assignment/CameraController.h>
#include <Assignment/ControllableTrafficLightFacade.h>
#include <Assignment/ControllableTrafficLightFacadeFactory.h>
#include <Assignment/LightCycleController.h>
#include <Assignment/PedestrianTrafficLightFacade.h>
#include <Assignment/PedestrianTrafficLightFacadeFactory.h>
#include <Assignment/RoadTileLightsFacadeFactory.h>
#include <Assignment/RoadTileLightsFacade.h>
#include <Assignment/RoadTilePedestrianLightFacadeFactory.h>
#include <Assignment/RoadTilePedestrianLightFacade.h>
#include <Assignment/SelectionHandler.h>
#include <Assignment/ShaderController.h>

#include "InteractionHandler.h"

// The root of the scene tree
osg::Group* g_pRoot;
Assignment::ShaderController* g_pShaderController;
float g_fTile = 472.0f;

bool g_bNames = false;
bool g_bAnimationPoints = false;
bool g_bAnimationNames = false;

// Declare funcitons
void keyFunction(char c);
void displayAnimationPoints();
void createRoadSystem();
void createControlledTrafficLights();
void createAnimatedCars();
void createSceneModels();
void loadShaders();

int main()
{
	// Camera viewers (main and side)
	osgViewer::View* viewer = new osgViewer::View;
	osgViewer::View* viewer2 = new osgViewer::View;

	// Scene viewer
	osgViewer::CompositeViewer compositeViewer;

	// Create camera controller
	Assignment::CameraController* cameraController = new Assignment::CameraController(&compositeViewer, viewer2);

	// Instantiate each factory
	Common::FacadeManufactory::start();
	Common::FacadeManufactory::instance()->addFactory("RoadTile", new TrafficSystem::RoadFacadeFactory());
	Common::FacadeManufactory::instance()->addFactory("ControllableLightRoadTile", new Assignment::RoadTileLightsFacadeFactory());
	Common::FacadeManufactory::instance()->addFactory("PedestrianLightRoadTile", new Assignment::RoadTilePedestrianLightFacadeFactory());
	Common::FacadeManufactory::instance()->addFactory("TrafficLight", new Assignment::ControllableTrafficLightFacadeFactory());
	Common::FacadeManufactory::instance()->addFactory("PedestrianTrafficLight", new Assignment::PedestrianTrafficLightFacadeFactory());
	Common::FacadeManufactory::instance()->addFactory("AnimatedCar", new Assignment::AnimatedCarFactory());
	Common::FacadeManufactory::instance()->addFactory("Default-Facade", new Common::FacadeFactory());
	Common::AssetLibrary::start();

	// Load each asset into the asset library
	Common::AssetLibrary::instance()->loadAsset("Road-Straight", "../../Data/roadStraight.osgb");
	Common::AssetLibrary::instance()->loadAsset("Road-TJunction", "../../Data/roadTJunction.osgb");
	Common::AssetLibrary::instance()->loadAsset("Road-XJunction", "../../Data/roadXJUnction.osgb");
	Common::AssetLibrary::instance()->loadAsset("Road-Curve", "../../Data/roadCurve.osgb");
	Common::AssetLibrary::instance()->loadAsset("TrafficLight", "../../Data/raaTrafficLight.osgb");
	Common::AssetLibrary::instance()->loadAsset("Car-Delta", "../../Data/Lancia-Delta.obj");
	Common::AssetLibrary::instance()->loadAsset("Car-Stratos", "../../Data/Lancia-Stratos/source/lshfg4.fbx");
	Common::AssetLibrary::instance()->loadAsset("Car-Dumptruck", "../../OpenSceneGraph-Data/dumptruck.osgt");
	Common::AssetLibrary::instance()->loadAsset("Car-Veyron", "../../Data/car-veyron.OSGB");
	Common::AssetLibrary::instance()->loadAsset("Fountain-Model", "../../OpenSceneGraph-Data/fountain.osgt");
	Common::AssetLibrary::instance()->loadAsset("Cube-Model", "../../Data/cube.obj");

	// Create node tree
	g_pRoot = new osg::Group();
	g_pRoot->ref();

	// Create a shader controller, that allows the user to switch the direction of the root (default has no shader)
	g_pShaderController = new Assignment::ShaderController();

	// Lighting controller (Turn on day & night cycle)
	Assignment::LightCycleController* pLightCycleController = new Assignment::LightCycleController(g_pRoot);
	/*
	Assessment note:
		- I had tried to make the lighting effect the shaders that were implemented in the scene, but failed.
		- I think this is becuase the shaders have their own lighting source, which overrides the current lighting in the osg scene.

		- My solution was to create a uniform for each of the shaders and pass in the current lighting into the fragment, via a vec4.
		- I removed this method from my 'downArrow.frag' shader as I couldn't get the lighting to affect the shader correctly.
	*/

	// Apply default shaders
	loadShaders();

	// Create Road system
	createRoadSystem();

	// Create traffic lights
	createControlledTrafficLights();

	// Create animated cars
	createAnimatedCars();

	// Create other scene models
	createSceneModels();

	// Display animation points for testing
	//displayAnimationPoints();

	// Window properties
	osg::GraphicsContext::Traits* pTraits = new osg::GraphicsContext::Traits();
	pTraits->x = 100;
	pTraits->y = 100;
	pTraits->width = 1200;
	pTraits->height = 960;
	pTraits->windowDecoration = true;
	pTraits->doubleBuffer = true;
	pTraits->sharedContext = 0;
	pTraits->readDISPLAY();
	pTraits->setUndefinedScreenDetailsToDefaultScreen();
	osg::GraphicsContext* pGraphicsContext = osg::GraphicsContext::createGraphicsContext(pTraits);

	// Main Camera properties
	osg::Camera* pCamera = viewer->getCamera();
	pCamera->setGraphicsContext(pGraphicsContext);
	pCamera->setViewport(new osg::Viewport(0, 0, pTraits->width, pTraits->height));
	GLenum buffer = pTraits->doubleBuffer ? GL_BACK : GL_FRONT;
	pCamera->setDrawBuffer(buffer);
	pCamera->setReadBuffer(buffer);
	viewer->setCamera(pCamera);

	// Add event handlers to main viewer
	viewer->addEventHandler(new osgViewer::ThreadingHandler);
	viewer->addEventHandler(new osgGA::StateSetManipulator(viewer->getCamera()->getOrCreateStateSet()));
	viewer->addEventHandler(new osgViewer::WindowSizeHandler);
	viewer->addEventHandler(new osgViewer::StatsHandler);
	viewer->addEventHandler(new osgViewer::RecordCameraPathHandler);
	viewer->addEventHandler(new osgViewer::LODScaleHandler);
	viewer->addEventHandler(new osgViewer::ScreenCaptureHandler);
	viewer->addEventHandler(new InteractionHandler(keyFunction, cameraController, g_pShaderController, pLightCycleController));

	// Side Camera properties
	osg::Camera* pSideCamera = viewer2->getCamera();
	pSideCamera->setGraphicsContext(pGraphicsContext);
	pSideCamera->setViewport(new osg::Viewport(0, 0, 1, 1));	// When resizing, set to 1, 1 rather than 0, 0 to prevent issues with the matrix
	GLenum sideCamBuffer = pTraits->doubleBuffer ? GL_BACK : GL_FRONT;
	pSideCamera->setDrawBuffer(sideCamBuffer);
	pSideCamera->setReadBuffer(sideCamBuffer);
	viewer2->setCamera(pSideCamera);

	// Set the scene to render
	viewer->setSceneData(g_pRoot);
	viewer2->setSceneData(g_pRoot);

	compositeViewer.addView(viewer);
	compositeViewer.addView(viewer2);

	// present the 3D window
	compositeViewer.realize();

	// start rendering loop
	return compositeViewer.run();
}

void loadShaders()
{
	// Create a default shader (Later remove, once the shader controller can store shaders)
	osg::Shader* pVertShader = new osg::Shader(osg::Shader::VERTEX);
	osg::Shader* pFragShader = new osg::Shader(osg::Shader::FRAGMENT);
	pVertShader->loadShaderSourceFromFile("../../shaders/toon.vert");
	pFragShader->loadShaderSourceFromFile("../../shaders/toon.frag");
	
	osg::Program* pToonShaderProgram = new osg::Program();
	pToonShaderProgram->addShader(pVertShader);
	pToonShaderProgram->addShader(pFragShader);

	// Add shaders to shader controller
	g_pShaderController->storeShader("ToonShader", pToonShaderProgram);

	// Create a 'brick' shader for the cube assets
	osg::Shader* pVertShader2 = new osg::Shader(osg::Shader::VERTEX);
	osg::Shader* pFragShader2 = new osg::Shader(osg::Shader::FRAGMENT);
	pVertShader2->loadShaderSourceFromFile("../../shaders/brick.vert");
	pFragShader2->loadShaderSourceFromFile("../../shaders/brick.frag");

	osg::Program* pBrickShaderProgram = new osg::Program();
	pBrickShaderProgram->addShader(pVertShader2);
	pBrickShaderProgram->addShader(pFragShader2);

	g_pShaderController->storeShader("BrickShader", pBrickShaderProgram);

	// Create a 'brick' shader for the cube assets
	osg::Shader* pVertShader3 = new osg::Shader(osg::Shader::VERTEX);
	osg::Shader* pFragShader3 = new osg::Shader(osg::Shader::FRAGMENT);
	pVertShader3->loadShaderSourceFromFile("../../shaders/toonTexture.vert");
	pFragShader3->loadShaderSourceFromFile("../../shaders/toonTexture.frag");

	osg::Program* pToonTextureShaderProgram = new osg::Program();
	pToonTextureShaderProgram->addShader(pVertShader3);
	pToonTextureShaderProgram->addShader(pFragShader3);

	g_pShaderController->storeShader("ToonTextureShader", pToonTextureShaderProgram);
}

void createRoadSystem() {

	// Hard coded track system.
	// Once animation pathing is automated, look into creating a randomly generated track

	// Create matrix for each road tile
	osg::Matrixf m0, m1, m2, m3, m4, m5, m6, m7, m8, m9, m10, m11, m12, m13, m14, m15, m16, m17, m18, m19, m20, m21, m22, m23, m24, m25, m26, m27, m28, m29, m30;
	m0 = osg::Matrix::rotate(osg::DegreesToRadians(0.0f), osg::Vec3f(0.0f, 0.0f, 1.0f)) * osg::Matrix::translate(0.0f, 0.0f, 0.0f);
	m1 = osg::Matrix::rotate(osg::DegreesToRadians(90.0f), osg::Vec3f(0.0f, 0.0f, 1.0f)) * osg::Matrix::translate(0.0f, 1.0f * g_fTile, 0.0f);
	m2 = osg::Matrix::rotate(osg::DegreesToRadians(90.0f), osg::Vec3f(0.0f, 0.0f, 1.0f)) * osg::Matrix::translate(0.0f, 2.0f * g_fTile, 0.0f);
	m3 = osg::Matrix::rotate(osg::DegreesToRadians(0.0f), osg::Vec3f(0.0f, 0.0f, 1.0f)) * osg::Matrix::translate(-1.0f * g_fTile, 2.0f * g_fTile, 0.0f);
	m4 = osg::Matrix::rotate(osg::DegreesToRadians(0.0f), osg::Vec3f(0.0f, 0.0f, 1.0f)) * osg::Matrix::translate(-2.0f * g_fTile, 2.0f * g_fTile, 0.0f);
	m5 = osg::Matrix::rotate(osg::DegreesToRadians(-90.0f), osg::Vec3f(0.0f, 0.0f, 1.0f)) * osg::Matrix::translate(-3.0f * g_fTile, 2.0f * g_fTile, 0.0f);
	m6 = osg::Matrix::rotate(osg::DegreesToRadians(-90.0f), osg::Vec3f(0.0f, 0.0f, 1.0f)) * osg::Matrix::translate(-3.0f * g_fTile, 1.0f * g_fTile, 0.0f);
	m7 = osg::Matrix::rotate(osg::DegreesToRadians(0.0f), osg::Vec3f(0.0f, 0.0f, 1.0f)) * osg::Matrix::translate(-3.0f * g_fTile, 0.0f, 0.0f);
	m8 = osg::Matrix::rotate(osg::DegreesToRadians(90.0f), osg::Vec3f(0.0f, 0.0f, 1.0f)) * osg::Matrix::translate(-2.0f * g_fTile, 0.0f, 0.0f);
	m9 = osg::Matrix::rotate(osg::DegreesToRadians(0.0f), osg::Vec3f(0.0f, 0.0f, 1.0f)) * osg::Matrix::translate(-1.0f * g_fTile, 0.0f, 0.0f);
	m10 = osg::Matrix::rotate(osg::DegreesToRadians(90.0f), osg::Vec3f(0.0f, 0.0f, 1.0f)) * osg::Matrix::translate(-2.0f * g_fTile, -1.0f * g_fTile, 0.0f);
	m11 = osg::Matrix::rotate(osg::DegreesToRadians(0.0f), osg::Vec3f(0.0f, 0.0f, 1.0f)) * osg::Matrix::translate(-2.0f * g_fTile, -2.0f * g_fTile, 0.0f);
	m12 = osg::Matrix::rotate(osg::DegreesToRadians(0.0f), osg::Vec3f(0.0f, 0.0f, 1.0f)) * osg::Matrix::translate(-1.0f * g_fTile, -2.0f * g_fTile, 0.0f);
	m13 = osg::Matrix::rotate(osg::DegreesToRadians(-90.0f), osg::Vec3f(0.0f, 0.0f, 1.0f)) * osg::Matrix::translate(0.0f, -2.0f * g_fTile, 0.0f);
	m14 = osg::Matrix::rotate(osg::DegreesToRadians(90.0f), osg::Vec3f(0.0f, 0.0f, 1.0f)) * osg::Matrix::translate(0.0f, -1.0f * g_fTile, 0.0f);
	m15 = osg::Matrix::rotate(osg::DegreesToRadians(0.0f), osg::Vec3f(0.0f, 0.0f, 1.0f)) * osg::Matrix::translate(1.0f * g_fTile, -2.0f * g_fTile, 0.0f);
	m16 = osg::Matrix::rotate(osg::DegreesToRadians(0.0f), osg::Vec3f(0.0f, 0.0f, 1.0f)) * osg::Matrix::translate(2.0f * g_fTile, -2.0f * g_fTile, 0.0f);
	m17 = osg::Matrix::rotate(osg::DegreesToRadians(90.0f), osg::Vec3f(0.0f, 0.0f, 1.0f)) * osg::Matrix::translate(3.0f * g_fTile, -2.0f * g_fTile, 0.0f);
	m18 = osg::Matrix::rotate(osg::DegreesToRadians(90.0f), osg::Vec3f(0.0f, 0.0f, 1.0f)) * osg::Matrix::translate(3.0f * g_fTile, -1.0f * g_fTile, 0.0f);
	m19 = osg::Matrix::rotate(osg::DegreesToRadians(90.0f), osg::Vec3f(0.0f, 0.0f, 1.0f)) * osg::Matrix::translate(3.0f * g_fTile, 0.0f, 0.0f);
	m20 = osg::Matrix::rotate(osg::DegreesToRadians(0.0f), osg::Vec3f(0.0f, 0.0f, 1.0f)) * osg::Matrix::translate(2.0f * g_fTile, 0.0f, 0.0f);
	m21 = osg::Matrix::rotate(osg::DegreesToRadians(0.0f), osg::Vec3f(0.0f, 0.0f, 1.0f)) * osg::Matrix::translate(1.0f * g_fTile, 0.0f, 0.0f);
	m22 = osg::Matrix::rotate(osg::DegreesToRadians(90.0f), osg::Vec3f(0.0f, 0.0f, 1.0f)) * osg::Matrix::translate(3.0f * g_fTile, 1.0f * g_fTile, 0.0f);
	m23 = osg::Matrix::rotate(osg::DegreesToRadians(0.0f), osg::Vec3f(0.0f, 0.0f, 1.0f)) * osg::Matrix::translate(4.0f * g_fTile, 0.0f, 0.0f);
	m24 = osg::Matrix::rotate(osg::DegreesToRadians(90.0f), osg::Vec3f(0.0f, 0.0f, 1.0f)) * osg::Matrix::translate(5.0f * g_fTile, 0.0f, 0.0f);
	m25 = osg::Matrix::rotate(osg::DegreesToRadians(90.0f), osg::Vec3f(0.0f, 0.0f, 1.0f)) * osg::Matrix::translate(5.0f * g_fTile, 1.0f * g_fTile, 0.0f);
	m26 = osg::Matrix::rotate(osg::DegreesToRadians(180.0f), osg::Vec3f(0.0f, 0.0f, 1.0f)) * osg::Matrix::translate(5.0f * g_fTile, 2.0f * g_fTile, 0.0f);
	m27 = osg::Matrix::rotate(osg::DegreesToRadians(0.0f), osg::Vec3f(0.0f, 0.0f, 1.0f)) * osg::Matrix::translate(4.0f * g_fTile, 2.0f * g_fTile, 0.0f);
	m28 = osg::Matrix::rotate(osg::DegreesToRadians(90.0f), osg::Vec3f(0.0f, 0.0f, 1.0f)) * osg::Matrix::translate(3.0f * g_fTile, 2.0f * g_fTile, 0.0f);
	m29 = osg::Matrix::rotate(osg::DegreesToRadians(0.0f), osg::Vec3f(0.0f, 0.0f, 1.0f)) * osg::Matrix::translate(2.0f * g_fTile, 2.0f * g_fTile, 0.0f);
	m30 = osg::Matrix::rotate(osg::DegreesToRadians(0.0f), osg::Vec3f(0.0f, 0.0f, 1.0f)) * osg::Matrix::translate(1.0f * g_fTile, 2.0f * g_fTile, 0.0f);

	g_pRoot->addChild(Common::FacadeManufactory::instance()->create("ControllableLightRoadTile", "rt_XJunction_1", Common::AssetLibrary::instance()->getAsset("Road-XJunction"), m0, true)->root());
	g_pRoot->addChild(Common::FacadeManufactory::instance()->create("RoadTile", "rt_Straight_1", Common::AssetLibrary::instance()->getAsset("Road-Straight"), m1, true)->root());
	g_pRoot->addChild(Common::FacadeManufactory::instance()->create("RoadTile", "rt_TJunction_1", Common::AssetLibrary::instance()->getAsset("Road-TJunction"), m2, true)->root());
	g_pRoot->addChild(Common::FacadeManufactory::instance()->create("RoadTile", "rt_Straight_2", Common::AssetLibrary::instance()->getAsset("Road-Straight"), m3, true)->root());
	g_pRoot->addChild(Common::FacadeManufactory::instance()->create("PedestrianLightRoadTile", "rt_Straight_3", Common::AssetLibrary::instance()->getAsset("Road-Straight"), m4, true)->root());
	g_pRoot->addChild(Common::FacadeManufactory::instance()->create("RoadTile", "rt_Curve_1", Common::AssetLibrary::instance()->getAsset("Road-Curve"), m5, true)->root());
	g_pRoot->addChild(Common::FacadeManufactory::instance()->create("RoadTile", "rt_Straight_4", Common::AssetLibrary::instance()->getAsset("Road-Straight"), m6, true)->root());
	g_pRoot->addChild(Common::FacadeManufactory::instance()->create("RoadTile", "rt_Curve_2", Common::AssetLibrary::instance()->getAsset("Road-Curve"), m7, true)->root());
	g_pRoot->addChild(Common::FacadeManufactory::instance()->create("RoadTile", "rt_TJunction_2", Common::AssetLibrary::instance()->getAsset("Road-TJunction"), m8, true)->root());
	g_pRoot->addChild(Common::FacadeManufactory::instance()->create("RoadTile", "rt_Straight_5", Common::AssetLibrary::instance()->getAsset("Road-Straight"), m9, true)->root());
	g_pRoot->addChild(Common::FacadeManufactory::instance()->create("PedestrianLightRoadTile", "rt_Straight_6", Common::AssetLibrary::instance()->getAsset("Road-Straight"), m10, true)->root());
	g_pRoot->addChild(Common::FacadeManufactory::instance()->create("RoadTile", "rt_Curve_3", Common::AssetLibrary::instance()->getAsset("Road-Curve"), m11, true)->root());
	g_pRoot->addChild(Common::FacadeManufactory::instance()->create("RoadTile", "rt_Straight_7", Common::AssetLibrary::instance()->getAsset("Road-Straight"), m12, true)->root());
	g_pRoot->addChild(Common::FacadeManufactory::instance()->create("ControllableLightRoadTile", "rt_TJunction_3", Common::AssetLibrary::instance()->getAsset("Road-TJunction"), m13, true)->root());
	g_pRoot->addChild(Common::FacadeManufactory::instance()->create("RoadTile", "rt_Straight_8", Common::AssetLibrary::instance()->getAsset("Road-Straight"), m14, true)->root());
	g_pRoot->addChild(Common::FacadeManufactory::instance()->create("PedestrianLightRoadTile", "rt_Straight_10", Common::AssetLibrary::instance()->getAsset("Road-Straight"), m15, true)->root());
	g_pRoot->addChild(Common::FacadeManufactory::instance()->create("RoadTile", "rt_Straight_11", Common::AssetLibrary::instance()->getAsset("Road-Straight"), m16, true)->root());
	g_pRoot->addChild(Common::FacadeManufactory::instance()->create("RoadTile", "rt_Curve_4", Common::AssetLibrary::instance()->getAsset("Road-Curve"), m17, true)->root());
	g_pRoot->addChild(Common::FacadeManufactory::instance()->create("RoadTile", "rt_Straight_12", Common::AssetLibrary::instance()->getAsset("Road-Straight"), m18, true)->root());
	g_pRoot->addChild(Common::FacadeManufactory::instance()->create("RoadTile", "rt_XJunction_2", Common::AssetLibrary::instance()->getAsset("Road-XJunction"), m19, true)->root());
	g_pRoot->addChild(Common::FacadeManufactory::instance()->create("PedestrianLightRoadTile", "rt_Straight_13", Common::AssetLibrary::instance()->getAsset("Road-Straight"), m20, true)->root());
	g_pRoot->addChild(Common::FacadeManufactory::instance()->create("RoadTile", "rt_Straight_14", Common::AssetLibrary::instance()->getAsset("Road-Straight"), m21, true)->root());
	g_pRoot->addChild(Common::FacadeManufactory::instance()->create("RoadTile", "rt_Straight_15", Common::AssetLibrary::instance()->getAsset("Road-Straight"), m22, true)->root());
	g_pRoot->addChild(Common::FacadeManufactory::instance()->create("RoadTile", "rt_Straight_16", Common::AssetLibrary::instance()->getAsset("Road-Straight"), m23, true)->root());
	g_pRoot->addChild(Common::FacadeManufactory::instance()->create("RoadTile", "rt_Curve_5", Common::AssetLibrary::instance()->getAsset("Road-Curve"), m24, true)->root());
	g_pRoot->addChild(Common::FacadeManufactory::instance()->create("RoadTile", "rt_Straight_17", Common::AssetLibrary::instance()->getAsset("Road-Straight"), m25, true)->root());
	g_pRoot->addChild(Common::FacadeManufactory::instance()->create("RoadTile", "rt_Curve_6", Common::AssetLibrary::instance()->getAsset("Road-Curve"), m26, true)->root());
	g_pRoot->addChild(Common::FacadeManufactory::instance()->create("RoadTile", "rt_Straight_18", Common::AssetLibrary::instance()->getAsset("Road-Straight"), m27, true)->root());
	g_pRoot->addChild(Common::FacadeManufactory::instance()->create("ControllableLightRoadTile", "rt_TJunction_4", Common::AssetLibrary::instance()->getAsset("Road-TJunction"), m28, true)->root());
	g_pRoot->addChild(Common::FacadeManufactory::instance()->create("RoadTile", "rt_Straight_19", Common::AssetLibrary::instance()->getAsset("Road-Straight"), m29, true)->root());
	g_pRoot->addChild(Common::FacadeManufactory::instance()->create("RoadTile", "rt_Straight_20", Common::AssetLibrary::instance()->getAsset("Road-Straight"), m30, true)->root());
}

void createControlledTrafficLights() {
	// Loop all facades to instantiate controllable lights on the specified tiles (In this case: All junctions)
	int iTLCount = 0;
	for (Common::FacadeMap::iterator it = Common::Facade::facades().begin(); it != Common::Facade::facades().end(); it++) {

		// Add traffic lights to X Junction
		if (it->second->asset() == Common::AssetLibrary::instance()->getAsset("Road-XJunction"))
		{
			// Create instance of trafficlight controller
			if (Assignment::RoadTileLightsFacade* pRTL = dynamic_cast<Assignment::RoadTileLightsFacade*>(it->second)) {

				// Create matrix positions for traffic lights
				osg::Matrix m0, m1, m2, m3;
				m0 = osg::Matrixf::scale(0.03f, 0.03f, 0.03f) * osg::Matrixf::rotate(osg::DegreesToRadians(-90.0f), 0.0f, 0.0f, 1.0f) * osg::Matrixf::translate(-220.0f, 170.0f, 0.0f);
				m1 = osg::Matrixf::scale(0.03f, 0.03f, 0.03f) * osg::Matrixf::rotate(osg::DegreesToRadians(0.0f), 0.0f, 0.0f, 1.0f) * osg::Matrixf::translate(-170.0f, -220.0f, 0.0f);
				m2 = osg::Matrixf::scale(0.03f, 0.03f, 0.03f) * osg::Matrixf::rotate(osg::DegreesToRadians(90.0f), 0.0f, 0.0f, 1.0f) * osg::Matrixf::translate(220.0f, -170.0f, 0.0f);
				m3 = osg::Matrixf::scale(0.03f, 0.03f, 0.03f) * osg::Matrixf::rotate(osg::DegreesToRadians(180.0f), 0.0f, 0.0f, 1.0f) * osg::Matrixf::translate(170.0f, 220.0f, 0.0f);

				// Instantiate controlled traffic lights
				pRTL->addLight(dynamic_cast<Assignment::ControllableTrafficLightFacade*>(Common::FacadeManufactory::instance()->create("TrafficLight", "TrafficLight_" + std::to_string(iTLCount++), Common::AssetLibrary::instance()->cloneAsset("TrafficLight"), m0, true)));
				pRTL->addLight(dynamic_cast<Assignment::ControllableTrafficLightFacade*>(Common::FacadeManufactory::instance()->create("TrafficLight", "TrafficLight_" + std::to_string(iTLCount++), Common::AssetLibrary::instance()->cloneAsset("TrafficLight"), m1, true)));
				pRTL->addLight(dynamic_cast<Assignment::ControllableTrafficLightFacade*>(Common::FacadeManufactory::instance()->create("TrafficLight", "TrafficLight_" + std::to_string(iTLCount++), Common::AssetLibrary::instance()->cloneAsset("TrafficLight"), m2, true)));
				pRTL->addLight(dynamic_cast<Assignment::ControllableTrafficLightFacade*>(Common::FacadeManufactory::instance()->create("TrafficLight", "TrafficLight_" + std::to_string(iTLCount++), Common::AssetLibrary::instance()->cloneAsset("TrafficLight"), m3, true)));
			}
		}

		// Add traffic lights to T-Junctions
		if (it->second->asset() == Common::AssetLibrary::instance()->getAsset("Road-TJunction"))
		{
			// Create instance of trafficlight controller
			if (Assignment::RoadTileLightsFacade* pRTL = dynamic_cast<Assignment::RoadTileLightsFacade*>(it->second)) {

				// Create matrix positions for traffic lights
				osg::Matrix m0, m1, m2;
				m0 = osg::Matrixf::scale(0.03f, 0.03f, 0.03f) * osg::Matrixf::rotate(osg::DegreesToRadians(-90.0f), 0.0f, 0.0f, 1.0f) * osg::Matrixf::translate(-220.0f, 170.0f, 0.0f);
				m1 = osg::Matrixf::scale(0.03f, 0.03f, 0.03f) * osg::Matrixf::rotate(osg::DegreesToRadians(0.0f), 0.0f, 0.0f, 1.0f) * osg::Matrixf::translate(-170.0f, -220.0f, 0.0f);
				m2 = osg::Matrixf::scale(0.03f, 0.03f, 0.03f) * osg::Matrixf::rotate(osg::DegreesToRadians(180.0f), 0.0f, 0.0f, 1.0f) * osg::Matrixf::translate(170.0f, 220.0f, 0.0f);

				// Instantiate controlled traffic lights
				pRTL->addLight(dynamic_cast<Assignment::ControllableTrafficLightFacade*>(Common::FacadeManufactory::instance()->create("TrafficLight", "TrafficLight_" + std::to_string(iTLCount++), Common::AssetLibrary::instance()->cloneAsset("TrafficLight"), m0, true)));
				pRTL->addLight(dynamic_cast<Assignment::ControllableTrafficLightFacade*>(Common::FacadeManufactory::instance()->create("TrafficLight", "TrafficLight_" + std::to_string(iTLCount++), Common::AssetLibrary::instance()->cloneAsset("TrafficLight"), m1, true)));
				pRTL->addLight(dynamic_cast<Assignment::ControllableTrafficLightFacade*>(Common::FacadeManufactory::instance()->create("TrafficLight", "TrafficLight_" + std::to_string(iTLCount++), Common::AssetLibrary::instance()->cloneAsset("TrafficLight"), m2, true)));
			}
		}

		// Add a pedestrian traffic light to a straight tile
		if (it->second->asset() == Common::AssetLibrary::instance()->getAsset("Road-Straight"))
		{
			if (Assignment::RoadTilePedestrianLightFacade* pPTL = dynamic_cast<Assignment::RoadTilePedestrianLightFacade*>(it->second)) {

				osg::Matrix m0, m1;
				m0 = osg::Matrixf::scale(0.03f, 0.03f, 0.03f) * osg::Matrixf::rotate(osg::DegreesToRadians(-90.0f), 0.0f, 0.0f, 1.0f) * osg::Matrixf::translate(-25.0f, 170.0f, 0.0f);
				m1 = osg::Matrixf::scale(0.03f, 0.03f, 0.03f) * osg::Matrixf::rotate(osg::DegreesToRadians(90.0f), 0.0f, 0.0f, 1.0f) * osg::Matrixf::translate(25.0f, -170.0f, 0.0f);

				pPTL->addLight(dynamic_cast<Assignment::PedestrianTrafficLightFacade*>(Common::FacadeManufactory::instance()->create("PedestrianTrafficLight", "PedestrianTrafficLight_" + std::to_string(iTLCount++), Common::AssetLibrary::instance()->cloneAsset("TrafficLight"), m0, true)));
				pPTL->addLight(dynamic_cast<Assignment::PedestrianTrafficLightFacade*>(Common::FacadeManufactory::instance()->create("PedestrianTrafficLight", "PedestrianTrafficLight_" + std::to_string(iTLCount++), Common::AssetLibrary::instance()->cloneAsset("TrafficLight"), m1, true)));
			}
		}
	}
}

void createAnimatedCars() {
	// Car 1 (Yellow car)
	osg::Matrixf mC = osg::Matrixf::scale(40.0f, 40.0f, 40.0f) *
		osg::Matrix::rotate(osg::DegreesToRadians(90.0f), osg::Vec3(0.0f, 0.0f, 1.0f)) *
		osg::Matrixf::translate(0.0f, 0.0f, 25.0f);

	g_pRoot->addChild(g_pShaderController->createShaderSwitch(Common::FacadeManufactory::instance()->create("AnimatedCar", "Car_1", Common::AssetLibrary::instance()->getAsset("Car-Delta"), mC, true)->root(), "ToonShader"));
	// Find car object and then create animation path
	if (Assignment::AnimatedCar* pAC = dynamic_cast<Assignment::AnimatedCar*>(Common::Facade::findFacade("Car_1")))
	{
		// Set up basic animation path
		osg::AnimationPath* pPath = new osg::AnimationPath();

		float fSpeed = 150.0f;
		float fTime = 0.0f;
		osg::Vec3f vLastPos;

		// Create animation points
		fTime = pAC->addControlPoint("rt_Curve_2", "0", pPath, fTime, fSpeed, vLastPos, true);
		fTime = pAC->addControlPoint("rt_Curve_2", "1", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_2", "2", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_TJunction_2", "5", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_TJunction_2", "6", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_TJunction_2", "7", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_6", "1", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_6", "3", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_3", "0", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_3", "1", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_3", "2", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_7", "2", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_7", "0", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_TJunction_3", "8", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_TJunction_3", "9", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_TJunction_3", "7", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_8", "2", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_8", "0", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_XJunction_1", "8", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_XJunction_1", "2", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_1", "2", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_1", "0", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_TJunction_1", "0", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_TJunction_1", "1", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_TJunction_1", "2", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_2", "1", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_2", "3", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_3", "1", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_3", "3", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_1", "0", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_1", "1", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_1", "2", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_4", "2", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_4", "0", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_2", "0", pPath, fTime, fSpeed, vLastPos, false);	// Back to first point for smooth reset
		// Apply animation path
		pAC->setAnimationPath(pPath);
	}
	
	// Car 2 (Blue car)
	osg::Matrixf mC2 = osg::Matrixf::rotate(osg::DegreesToRadians(90.0f), 1.0f, 0.0f, 0.0f) *
		osg::Matrixf::rotate(osg::DegreesToRadians(180.0f), 0.0f, 0.0f, 1.0f) *
		osg::Matrixf::translate(0.0f, 0.0f, 0.0f);

	g_pRoot->addChild(g_pShaderController->createShaderSwitch(Common::FacadeManufactory::instance()->create("AnimatedCar", "Car_2", Common::AssetLibrary::instance()->getAsset("Car-Stratos"), mC2, true)->root(), "ToonShader"));
	// Find car object and then create animation path
	if (Assignment::AnimatedCar* pAC = dynamic_cast<Assignment::AnimatedCar*>(Common::Facade::findFacade("Car_2")))
	{
		// Set up basic animation path
		osg::AnimationPath* pPath = new osg::AnimationPath();
		float fSpeed = 200.0f;
		float fTime = 0.0f;
		osg::Vec3f vLastPos;

		// Create animation points
		fTime = pAC->addControlPoint("rt_Straight_4", "2", pPath, fTime, fSpeed, vLastPos, true);
		fTime = pAC->addControlPoint("rt_Straight_4", "0", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_2", "0", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_2", "1", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_2", "2", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_TJunction_2", "5", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_TJunction_2", "6", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_TJunction_2", "7", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_6", "1", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_6", "3", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_3", "0", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_3", "1", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_3", "2", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_7", "2", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_7", "0", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_TJunction_3", "8", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_TJunction_3", "9", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_TJunction_3", "7", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_8", "2", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_8", "0", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_XJunction_1", "8", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_XJunction_1", "2", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_1", "2", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_1", "0", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_TJunction_1", "0", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_TJunction_1", "1", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_TJunction_1", "2", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_2", "1", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_2", "3", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_3", "1", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_3", "3", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_1", "0", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_1", "1", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_1", "2", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_4", "2", pPath, fTime, fSpeed, vLastPos, false); // Back to first point for smooth reset
		// Apply animation path
		pAC->setAnimationPath(pPath);
	}

	// Car 3 (Dumptruck)
	osg::Matrixf mC3 = osg::Matrixf::scale(7.0f, 7.0f, 7.0f) *
		osg::Matrixf::rotate(osg::DegreesToRadians(0.0f), 0.0f, 0.0f, 1.0) *
		osg::Matrixf::translate(60.0f, -15.0f, 40.0f);

	g_pRoot->addChild(g_pShaderController->createShaderSwitch(Common::FacadeManufactory::instance()->create("AnimatedCar", "Car_3", Common::AssetLibrary::instance()->getAsset("Car-Dumptruck"), mC3, true)->root(), "ToonShader"));
	// Find car object and then create animation path
	if (Assignment::AnimatedCar* pAC = dynamic_cast<Assignment::AnimatedCar*>(Common::Facade::findFacade("Car_3")))
	{
		// Set up basic animation path
		osg::AnimationPath* pPath = new osg::AnimationPath();
		float fSpeed = 150.0f;
		float fTime = 0.0f;
		osg::Vec3f vLastPos;

		// Create animation points
		fTime = pAC->addControlPoint("rt_Straight_8", "2", pPath, fTime, fSpeed, vLastPos, true);
		fTime = pAC->addControlPoint("rt_Straight_8", "0", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_XJunction_1", "8", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_XJunction_1", "9", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_XJunction_1", "7", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_5", "1", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_5", "3", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_TJunction_2", "8", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_TJunction_2", "9", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_TJunction_2", "7", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_6", "1", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_6", "3", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_3", "0", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_3", "1", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_3", "2", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_7", "2", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_7", "0", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_TJunction_3", "8", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_TJunction_3", "9", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_TJunction_3", "7", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_8", "2", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_8", "0", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_XJunction_1", "8", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_XJunction_1", "15", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_XJunction_1", "10", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_14", "2", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_14", "0", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_13", "2", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_13", "0", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_XJunction_2", "5", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_XJunction_2", "6", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_XJunction_2", "7", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_12", "1", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_12", "3", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_4", "3", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_4", "4", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_4", "5", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_11", "1", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_11", "3", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_10", "1", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_10", "3", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_TJunction_3", "5", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_TJunction_3", "6", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_TJunction_3", "7", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_8", "2", pPath, fTime, fSpeed, vLastPos, false); // Back to first point for smooth reset

		// Apply animation path
		pAC->setAnimationPath(pPath);
	}
	
	// Car 4 (Veyron car)
	osg::Matrixf mC4 = osg::Matrixf::scale(12.0f, 12.0f, 12.0f) *
		osg::Matrix::rotate(osg::DegreesToRadians(90.0f), osg::Vec3(0.0f, 0.0f, 1.0f)) *
		osg::Matrixf::translate(0.0f, 0.0f, 35.0f);

	g_pRoot->addChild(g_pShaderController->createShaderSwitch(Common::FacadeManufactory::instance()->create("AnimatedCar", "Car_4", Common::AssetLibrary::instance()->getAsset("Car-Veyron"), mC4, true)->root(), "ToonShader"));
	// Find car object and then create animation path
	if (Assignment::AnimatedCar* pAC = dynamic_cast<Assignment::AnimatedCar*>(Common::Facade::findFacade("Car_4")))
	{
		// Set up basic animation path
		osg::AnimationPath* pPath = new osg::AnimationPath();
		float fSpeed = 250.0f;
		float fTime = 0.0f;
		osg::Vec3f vLastPos;

		// Create animation points
		fTime = pAC->addControlPoint("rt_Straight_20", "2", pPath, fTime, fSpeed, vLastPos, true);
		fTime = pAC->addControlPoint("rt_Straight_20", "0", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_19", "2", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_19", "0", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_TJunction_4", "5", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_TJunction_4", "4", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_18", "2", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_18", "0", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_6", "3", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_6", "4", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_6", "5", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_17", "1", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_17", "3", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_5", "3", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_5", "4", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_5", "5", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_16", "1", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_16", "3", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_XJunction_2", "8", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_XJunction_2", "9", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_XJunction_2", "7", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_12", "1", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_12", "3", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_4", "3", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_4", "4", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_4", "5", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_11", "1", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_11", "3", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_10", "1", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_10", "3", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_TJunction_3", "5", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_TJunction_3", "4", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_7", "1", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_7", "3", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_3", "3", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_3", "4", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_3", "5", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_6", "2", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_6", "0", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_TJunction_2", "0", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_TJunction_2", "1", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_TJunction_2", "2", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_2", "3", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_2", "4", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_2", "5", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_4", "1", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_4", "3", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_1", "3", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_1", "4", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Curve_1", "5", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_3", "2", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_3", "0", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_2", "2", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_2", "0", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_TJunction_1", "5", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_TJunction_1", "4", pPath, fTime, fSpeed, vLastPos, false);
		fTime = pAC->addControlPoint("rt_Straight_20", "2", pPath, fTime, fSpeed, vLastPos, false); // Back to initial animation point

		// Apply animation path
		pAC->setAnimationPath(pPath);
	}
}

void createSceneModels()
{
	// Fountain model
	osg::Matrixf mR = osg::Matrixf::scale(0.5f, 0.5f, 0.5f) *
		osg::Matrix::rotate(osg::DegreesToRadians(90.0f), osg::Vec3(0.0f, 0.0f, 1.0f)) *
		osg::Matrixf::translate(1.0f * g_fTile, 1.0f * g_fTile, 0.0f);
	g_pRoot->addChild(Common::FacadeManufactory::instance()->create("Default-Facade", "Fountain_1", Common::AssetLibrary::instance()->getAsset("Fountain-Model"), mR, true)->root());

	// Loop to create and position walls
	int wallIndex = 0;
	for (int i = -2; i < 5; i++) {
		// Create position
		osg::Matrixf mTM = osg::Matrixf::scale(g_fTile / 4, 10.0f, g_fTile / 4) *
			osg::Matrix::rotate(osg::DegreesToRadians(0.0f), osg::Vec3(0.0f, 0.0f, 1.0f)) *
			osg::Matrixf::translate((i - 0.25f) * g_fTile, 2.5f * g_fTile, g_fTile / 4);
		
		//g_pRoot->addChild(g_pShaderController->createShaderSwitch(Common::FacadeManufactory::instance()->create("Default-Facade", "Wall_" + std::to_string(wallIndex), Common::AssetLibrary::instance()->getAsset("Cube-Model"), mTM, true)->root(), "BrickShader"));
		
		g_pRoot->addChild(Common::FacadeManufactory::instance()->create("Default-Facade", "Wall_" + std::to_string(wallIndex), Common::AssetLibrary::instance()->getAsset("Cube-Model"), mTM, true)->root());
		// Apply shader
		if (Common::Facade* pWall = Common::Facade::findFacade("Wall_" + std::to_string(wallIndex)))
		{
			pWall->asset()->getOrCreateStateSet()->setAttributeAndModes(g_pShaderController->getShaderByName("BrickShader"), osg::StateAttribute::ON);
		}

		// Second wall segment
		osg::Matrixf mTM2 = osg::Matrixf::scale(g_fTile / 4, 10.0f, g_fTile / 4) *
			osg::Matrix::rotate(osg::DegreesToRadians(0.0f), osg::Vec3(0.0f, 0.0f, 1.0f)) *
			osg::Matrixf::translate((i + 0.25f) * g_fTile, 2.5f * g_fTile, g_fTile / 4);
		//g_pRoot->addChild(g_pShaderController->createShaderSwitch(Common::FacadeManufactory::instance()->create("Default-Facade", "Wall_" + std::to_string(++wallIndex), Common::AssetLibrary::instance()->getAsset("Cube-Model"), mTM2, true)->root(), "BrickShader"));

		g_pRoot->addChild(Common::FacadeManufactory::instance()->create("Default-Facade", "Wall_" + std::to_string(++wallIndex), Common::AssetLibrary::instance()->getAsset("Cube-Model"), mTM2, true)->root());
		// Apply shader
		if (Common::Facade* pWall = Common::Facade::findFacade("Wall_" + std::to_string(wallIndex)))
		{
			pWall->asset()->getOrCreateStateSet()->setAttributeAndModes(g_pShaderController->getShaderByName("BrickShader"), osg::StateAttribute::ON);
		}
	}
}

void keyFunction(char c)
{
	switch (c)
	{
	case 'h':
		std::cout << "Assignment Viewer - key options" << std::endl;
		std::cout << "\tp - print scene tree to console" << std::endl;
		std::cout << "\td - toggle visibility of the collider detection boxes" << std::endl;
		std::cout << "\tn - toggle name display for road tiles" << std::endl;
		std::cout << "\ta - toggle animation point display for road tiles" << std::endl;
		std::cout << "\tz - toggle animation point name display for road tiles" << std::endl;

		break;
	case 'p':
	{
		Common::Printer printer;
		printer.traverse(*g_pRoot);
	}
	break;
	case 'd':
		TrafficSystem::Collider::toggleVisible();
		break;
	case 'n':
		g_bNames = !g_bNames;
		for (Common::FacadeMap::iterator it = Common::Facade::facades().begin(); it != Common::Facade::facades().end(); it++)
			if (TrafficSystem::RoadFacade* pRF = dynamic_cast<TrafficSystem::RoadFacade*>(it->second))
				pRF->enableNames(g_bNames);
		break;
	case 'a':
		g_bAnimationPoints = !g_bAnimationPoints;
		for (Common::FacadeMap::iterator it = Common::Facade::facades().begin(); it != Common::Facade::facades().end(); it++)
			if (TrafficSystem::RoadFacade* pRF = dynamic_cast<TrafficSystem::RoadFacade*>(it->second))
				pRF->enableAnimationPoints(g_bAnimationPoints);
		break;
	case 'z':
		g_bAnimationNames = !g_bAnimationNames;
		for (Common::FacadeMap::iterator it = Common::Facade::facades().begin(); it != Common::Facade::facades().end(); it++)
			if (TrafficSystem::RoadFacade* pRF = dynamic_cast<TrafficSystem::RoadFacade*>(it->second))
				pRF->enableAnimationIDs(g_bAnimationNames);
		break;
	}
}

void displayAnimationPoints() {
	// Toggle the collision boxes
	TrafficSystem::Collider::toggleVisible();
	// DISPLAY TILE PROPERTIES FOR ANIMATION
	for (Common::FacadeMap::iterator it = Common::Facade::facades().begin(); it != Common::Facade::facades().end(); it++)
	{
		if (TrafficSystem::RoadFacade* pRF = dynamic_cast<TrafficSystem::RoadFacade*>(it->second))
		{
			pRF->enableAnimationIDs(true);
			pRF->enableNames(true);
			pRF->enableAnimationPoints(true);

			// Add the tile name to the billboards over the road tile
			osg::Billboard* pBB = new osg::Billboard();
			pBB->setNormal(osg::Vec3f(0.0f, 0.0f, 1.0f));
			osgText::Text* pT = new osgText::Text();
			pT->setText(it->first);

			pBB->addDrawable(pT);
			pBB->setPosition(0, osg::Vec3f(0.0f, 0.0f, 60.0f));
			pRF->scale()->addChild(pBB);
		}
	}
}