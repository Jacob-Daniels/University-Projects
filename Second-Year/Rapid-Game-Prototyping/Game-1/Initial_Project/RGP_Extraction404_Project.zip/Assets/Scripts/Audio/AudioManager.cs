using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;
using System;

public class AudioManager : MonoBehaviour
{
    public static AudioManager instance;
    public Sound[] sounds;

    public void Awake()
    {
        if (instance == null)
        {
            instance = this;
        } else
        {
            Destroy(this);
            return;
        }
        DontDestroyOnLoad(gameObject);

        // Loop all sounds to create a new audiosource component for each
        foreach (Sound s in sounds)
        {
            s.source = gameObject.AddComponent<AudioSource>();
            s.source.clip = s.clip;
            s.source.volume = s.volume;
            s.source.pitch = s.pitch;
            s.source.loop = s.loop;
        }
    }
    private void Start()
    {
        // Play background music on startup
        Play("backgroundMusic");
    }

    public void Play(string name)
    {
        // Find audio clip in array
        Sound s = Array.Find(sounds, sound => sound.name == name);

        // Check clip isn't null
        if (s == null)
        {
            Debug.Log("Audio clip '" + name + "' is not found");
            return;
        }
        // Play audio clip
        s.source.Play();
    }
}
