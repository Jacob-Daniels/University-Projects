using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PushObject : MonoBehaviour
{
    private void OnControllerColliderHit(ControllerColliderHit hit)
    {
        Rigidbody rb = hit.collider.attachedRigidbody;
        if (hit.gameObject.tag == "PushObject")
        {
            rb.velocity = hit.moveDirection * 5f;
        }
    }
}
