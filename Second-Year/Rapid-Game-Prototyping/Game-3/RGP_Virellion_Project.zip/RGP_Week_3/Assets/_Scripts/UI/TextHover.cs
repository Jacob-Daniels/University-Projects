using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;

public class TextHover : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    public Color normalColour;
    public Color hoverColour;

    public void OnPointerEnter(PointerEventData eventData)
    {
        // Set colour on mouse hover
        this.GetComponent<TextMeshProUGUI>().color = hoverColour;
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        // Set colour on mouse exit
        this.GetComponent<TextMeshProUGUI>().color = normalColour;
    }
}
