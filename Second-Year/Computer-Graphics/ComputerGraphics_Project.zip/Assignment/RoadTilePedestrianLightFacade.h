#pragma once
#include <iostream>
#include <TrafficSystem/RoadFacade.h>

namespace TrafficSystem
{
	class TrafficLightFacade;
}

namespace Assignment
{
	class PedestrianTrafficLightFacade;

	typedef std::list<PedestrianTrafficLightFacade*> PedLights;

	class RoadTilePedestrianLightFacade : public TrafficSystem::RoadFacade, public osg::Callback
	{
	public:
		RoadTilePedestrianLightFacade(std::string sName, osg::Node* pAsset, osg::Matrixf m, bool bVisible);
		virtual ~RoadTilePedestrianLightFacade();

		void addLight(PedestrianTrafficLightFacade* pPTL);

		void toggleState();
		virtual bool run(osg::Object* object, osg::Object* data);

	protected:
		PedLights m_plLights;
		PedLights::iterator m_itCurrentPLight;

		unsigned int m_uiCount;
	};
}