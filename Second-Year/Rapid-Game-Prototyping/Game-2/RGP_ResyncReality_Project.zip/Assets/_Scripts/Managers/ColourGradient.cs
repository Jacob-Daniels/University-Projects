using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ColourGradient : MonoBehaviour
{
    public Material material;
    private Color newColour;
    [SerializeField] private float gradientSpeed = 150f;
    [SerializeField] private float alpha = 0.8f;
    private float r = 255, g = 255, b = 255;
    private bool flipColor = true;
    
    private void Update()
    {
        if (flipColor)
        {
            DecreaseColour();
        } else
        {
            IncreaseColour();
        }
    }

    private void DecreaseColour()
    {
        // Change colour
        if (r > 0 && g > 0 && b > 0)
        {
            // Generate new colour
            newColour = new Color(1 - r / 255, 1 - g / 255, 1 - b / 255, alpha);
            r -= gradientSpeed * Time.deltaTime;
            g -= gradientSpeed * Time.deltaTime;
            b -= gradientSpeed * Time.deltaTime;
            // Apply color
            material.color = newColour;
        } else
        {
            flipColor = false;
        }
    }

    private void IncreaseColour()
    {
        // Change colour
        if (r < 255 & g < 255 && b < 255)
        {
            // Generate new colour
            newColour = new Color(1 - r / 255, 1 - g / 255, 1 - b / 255, alpha);
            r += gradientSpeed * Time.deltaTime;
            g += gradientSpeed * Time.deltaTime;
            b += gradientSpeed * Time.deltaTime;
            // Apply color
            material.color = newColour;
        } else
        {
            flipColor = true;
        }
    }
}
