#include "ShaderController.h"
#include <osg/Program>
#include <osg/Material>
#include <iostream>

Assignment::ShaderController::ShaderController() : m_ChildIndex(0), m_ShaderSwitches(0), m_ssIterator(m_ShaderSwitches.end())
{
}

Assignment::ShaderController::~ShaderController()
{
}

osg::Switch* Assignment::ShaderController::createShaderSwitch(osg::Node* pDefaultNode, std::string shaderName)
{
	// Create the shader switch and add default node
	osg::Switch* pShaderSwitch = new osg::Switch();
	pShaderSwitch->addChild(pDefaultNode, true);

	// Create new shader root
	osg::Group* pShaderRoot = new osg::Group();
	pShaderRoot->addChild(pDefaultNode);

	// Add shader
	if (findShader(shaderName)) {
		pShaderRoot->getOrCreateStateSet()->setAttributeAndModes(m_mShaders[shaderName], osg::StateAttribute::ON);
	}

	// Add shader node to the switch
	pShaderSwitch->addChild(pShaderRoot, false);

	// Add switch to list
	m_ShaderSwitches.push_back(pShaderSwitch);

	return pShaderSwitch;
}

void Assignment::ShaderController::toggleShader()
{
	// Increase child counter (to determine which switch child will be active)
	if (++m_ChildIndex >= 2) m_ChildIndex = 0;

	// Loop the shader list to toggle each of the elements
	for (m_ssIterator = m_ShaderSwitches.begin(); m_ssIterator != m_ShaderSwitches.end(); m_ssIterator++) {
		// Disable previous root
		(*m_ssIterator)->setAllChildrenOff();
		// Enable new root
		(*m_ssIterator)->setValue(m_ChildIndex, true);
	}
}

void Assignment::ShaderController::storeShader(std::string shaderName, osg::Program* pShaderProgram)
{
	// Add shader to map
	m_mShaders.insert({ shaderName, pShaderProgram });
}

bool Assignment::ShaderController::findShader(std::string shaderName)
{
	// Find the shader
	if (m_mShaders.find(shaderName) == m_mShaders.end()) return false;
	return true;
}

osg::Program* Assignment::ShaderController::getShaderByName(std::string shaderName)
{
	if (findShader(shaderName)) return m_mShaders[shaderName];
	return nullptr;
}
