using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShortcutManager : MonoBehaviour
{
    private void Update()
    {
        // Number key shortcuts to select a control/tile from the UI
        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            TilemapManager.instance.SetTile(0);
            TilemapManager.instance.UpdateMouseHover();
        } else if (Input.GetKeyDown(KeyCode.Alpha2))
        {
            TilemapManager.instance.SetTile(1);
            TilemapManager.instance.UpdateMouseHover();
        }
        else if (Input.GetKeyDown(KeyCode.Alpha3))
        {
            TilemapManager.instance.SetTile(2);
            TilemapManager.instance.UpdateMouseHover();
        }
        else if (Input.GetKeyDown(KeyCode.Alpha4))
        {
            TilemapManager.instance.SetTile(3);
            TilemapManager.instance.UpdateMouseHover();
        } else if (Input.GetKeyDown(KeyCode.Alpha5))
        {
            TilemapManager.instance.SetTile(4);
            TilemapManager.instance.UpdateMouseHover();
        } else if (Input.GetKeyDown(KeyCode.Alpha6))
        {
            TilemapManager.instance.SetTile(5);
            TilemapManager.instance.UpdateMouseHover();
        } else if (Input.GetKeyDown(KeyCode.Alpha7))
        {
            TilemapManager.instance.SetTile(6);
            TilemapManager.instance.UpdateMouseHover();
        }
    }

}
