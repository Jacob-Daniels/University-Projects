using System.Collections;
using System.Collections.Generic;
using System.Threading;
using TMPro;
using UnityEngine;

public class DamagePopUp : MonoBehaviour
{
    private TextMeshPro damageText;
    private Color textColor;
    private float fadeTimer = 0.75f;
    private static int sortingOrder;

    private void Awake()
    {
        damageText = transform.GetComponent<TextMeshPro>();
    }

    public static DamagePopUp Create(Vector3 spawnPosition, int damageAmount, bool isEnemy)
    {
        // Instantiate a popup message at position given
        GameObject popUpTransform = Instantiate(GameManager.instance.damagePopupPrefab, spawnPosition, Quaternion.identity);
        DamagePopUp damagePopUp = popUpTransform.GetComponent<DamagePopUp>();
        popUpTransform.transform.parent = GameManager.instance.popupParent;
        damagePopUp.SetUp(damageAmount, isEnemy);
        return damagePopUp;
    }

    public void SetUp(int damageAmount, bool isEnemy)
    {
        // Convert damage amount into string
        damageText.text = damageAmount.ToString();
        // Set text colour depending on type (player or enemy)
        if (isEnemy)
        {
            AudioManager.instance.Play("EnemyDamaged");
            textColor = damageText.color;
        }
        else
        {
            AudioManager.instance.Play("PlayerDamaged");
            textColor = Color.red;
            damageText.color = textColor;
        }
        // Order text layer (display latest on top)
        sortingOrder++;
        damageText.sortingOrder = sortingOrder;
    }

    private void Update()
    {
        // Move text position upwards
        float moveYSpeed = 5f;
        transform.position += new Vector3(0, moveYSpeed) * Time.deltaTime;

        // Time to fade text
        fadeTimer -= Time.deltaTime;
        if (fadeTimer < 0f)
        {
            // Fade text away by reducing alpha
            float fadeSpeed = 2.5f;
            textColor.a -= fadeSpeed * Time.deltaTime;
            // Assign new colour
            damageText.color = textColor;
            // Destroy object when it is not visible
            if (textColor.a < 0f)
            {
                Destroy(gameObject);
            }
        }
    }
}
