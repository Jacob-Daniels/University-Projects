using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveObject : MonoBehaviour
{
    [SerializeField] private Vector3 startPos;
    [SerializeField] private Vector3 endPos;
    [SerializeField] private float speed = 10f;
    private bool isControlled = false;
    [SerializeField] private ObjectController controller;

    private void Awake()
    {
        // Set start pos and controller
        startPos = transform.position;
        if (controller != null)
        {
            isControlled = true;
        }
    }

    private void Update()
    {
        if (isControlled)
        {
            // Move object if controller is active
            if (!controller.isOpen)
            {
                MoveToStart();
            } else
            {
                MoveToEnd();
            }
        } else
        {
            // Move object depending on state
            if (ReverseMap.instance.GetState())
            {
                MoveToStart();
            }
            else
            {
                MoveToEnd();
            }
        }
    }
    private void MoveToStart()
    {
        transform.position = Vector3.MoveTowards(transform.position, startPos, speed * Time.deltaTime);
    }
    private void MoveToEnd()
    {
        transform.position = Vector3.MoveTowards(transform.position, endPos, speed * Time.deltaTime);
    }
}
