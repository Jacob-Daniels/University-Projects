using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class MagnifyingGlass : MonoBehaviour
{
    public static MagnifyingGlass instance;

    [Header("Magnifying Glass:")]
    public Transform mgTilemap;

    private Vector3 mousePosition;
    private Vector3 mouseOffset;
    private bool pressed;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        } else
        {
            Destroy(gameObject);
        }
    }

    private void Update()
    {
        mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        mousePosition.z = 0f;

        // Get input to drag
        if (Input.GetMouseButtonDown(0))
        {
            // Grab raycast from toolmanager and check mouse is on magnifying glass (frame)
            RaycastHit2D hit = ToolManager.instance.hit;
            if (!pressed && hit.collider != null)
            {
                if (hit.collider.CompareTag("Frame")) {
                    // Calc offset from mouse to center of magnifying glass
                    mouseOffset = mousePosition - mgTilemap.position;
                    pressed = true;
                    ToolManager.instance.SetCanUseTool(false);
                    AudioManager.instance.Play("MagnifyingGlass");
                }
            }
        }
        if (Input.GetMouseButtonUp(0))
        {
            if (pressed)
            {
                AudioManager.instance.Play("MagnifyingGlass2");
                pressed = false;
                ToolManager.instance.SetCanUseTool(true);
            }
        }

        // If mouse is pressed then move magnifying glass object
        if (pressed)
        {
            // Move position of magnifying glass tilemaps
            mgTilemap.GetComponent<Rigidbody2D>().position = mousePosition - mouseOffset;
            //mgTilemap.position = mousePosition - mouseOffset;

            // Set bounds for mgFrame
            if (mgTilemap.position.x > 15f)
            {
                mgTilemap.position = new Vector3(15f, mgTilemap.position.y, mgTilemap.position.z);
            }
            else if (mgTilemap.position.x < -15f)
            {
                mgTilemap.position = new Vector3(-15f, mgTilemap.position.y, mgTilemap.position.z);
            }
            if (mgTilemap.position.y > 7f)
            {
                mgTilemap.position = new Vector3(mgTilemap.position.x, 7f, mgTilemap.position.z);
            }
            else if (mgTilemap.position.y < -7f)
            {
                mgTilemap.position = new Vector3(mgTilemap.position.x, -7f, mgTilemap.position.z);
            }
        }
    }

    public void DisableScript()
    {
        // Disable script and reset variables
        pressed = false;
        enabled = false;
    }
}
