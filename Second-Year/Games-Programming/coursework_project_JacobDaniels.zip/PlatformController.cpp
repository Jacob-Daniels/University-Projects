#include "PlatformController.h"

PlatformController::PlatformController(const sf::Vector2f& pos, const sf::Vector2f& size, const sf::Vector2f& gravity) : pos(pos), size(size), vel(sf::Vector2f(0, 0)), gravity(gravity)
{
	// Load assets
	LoadAssets();
	sprite.setPosition(pos);

	// Assign first state
	state = new IdleState(*this);
}

void PlatformController::MoveAndCollide(float dt, Collision& collision)
{
	groundColl = false;
	wallCollLeft = false;
	wallCollRight = false;
	float depth;
	sf::Vector2f normal;
	// move and accelerate
	pos += vel * dt;
	vel += gravity * dt;
	// collision
	if (vel.x < 0.0f)
		direction = false;
	if (vel.x > 0.0f)
		direction = true;
	if (collision.Overlap(CollisionQuad(pos-sf::Vector2f(16.0f,0.0f), size), depth, normal))
	{
		if (vel.x * normal.x + vel.y * normal.y < 0.0f) // proper collision, not moving away
		{
			pos += normal * depth;
			vel = sf::Vector2f(0, 0);
		}
		if (normal.x > 0.0f)
		{
			wallCollLeft = true;
		}
		else if (normal.x < 0.0f) {
			wallCollRight = true;
		}
		else if (normal.y < 0.0f) {
			groundColl = true;
		}
	}
}

void PlatformController::Update(float dt, Collision& collision, Input& input)
{
	// Player movement
	MoveAndCollide(dt, collision);

	// Check for new state
	PlatformState* newState = state->Update(dt, input);
	if (newState != nullptr) {
		delete state;
		state = newState;
	}
}

void PlatformController::Draw(sf::RenderWindow& window)
{
	// Flip sprite
	if (!direction)
		sprite.setScale(-1.0f, 1.0f);
	else
		sprite.setScale(1.0f, 1.0f);

	sprite.setPosition(pos);
	window.draw(sprite);
}