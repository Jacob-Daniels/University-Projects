#include <windows.h>
#include <osg/Geode>
#include <iostream>

#include "AnimatedCar.h"
#include "ControllableTrafficLightFacade.h"
#include "SelectionHandler.h"

#include <TrafficSystem/TrafficLightFacade.h>
#include <TrafficSystem/RoadFacade.h>

#include <Common/NodeFinderT.h>
#include <Common/AssetLibrary.h>

#include "CameraController.h"

Assignment::AnimatedCar::AnimatedCar(std::string sName, osg::Node* pAsset, osg::Matrix m, bool bVisible) : TrafficSystem::CarFacade(sName, pAsset, m, bVisible), m_pAnimationTransform(new osg::MatrixTransform()), m_pCollisionTarget(new osg::MatrixTransform()), m_pCameraController(0), m_pAnimationPathCallback(0), m_bCurrentState(false), m_fAnimationSpeed(0)
{
	// Insert the animation transform into the facade sub tree to allow it to control an empty space transform
	// Take note of the order of these operations. This avoids the existing objects being unref() and deleted
	m_pAnimationTransform->addChild(m_pTransformation);
	m_pRoot->removeChild(m_pTransformation);
	m_pRoot->addChild(m_pAnimationTransform);
	m_pAnimationTransform->setDataVariance(osg::Object::DYNAMIC);

	// Find the car type to position the detector collision box correctly
	if (asset() == Common::AssetLibrary::instance()->getAsset("Car-Stratos")) {
		// Set the bounds and position of the cars detection collision box
		setTransform(osg::Matrixf::translate(-100.0f, -2.5f, 40.0f));
		setBound(osg::Vec3f(80.0f, 32.0f, 160.0f));
	}
	else if (asset() == Common::AssetLibrary::instance()->getAsset("Car-Delta")) {
		setTransform(osg::Matrixf::translate(1.0f, -2.5f, -0.7f));
		setBound(osg::Vec3f(4.0f, 2.0f, 0.8f));
	}
	else if (asset() == Common::AssetLibrary::instance()->getAsset("Car-Dumptruck")) {
		// Dumptruck detector
		setTransform(osg::Matrixf::translate(10.0f, 11.0f, -6.5f));
		setBound(osg::Vec3f(12.5f, 20.0f, 5.0f));
	}
	else if (asset() == Common::AssetLibrary::instance()->getAsset("Car-Veyron")) {
		// Dumptruck detector
		setTransform(osg::Matrixf::translate(3.0f, -12.0f, -3.0f));
		setBound(osg::Vec3f(14.0f, 8.0f, 2.5f));
	}

	// Store car data (using 'SelectionHandler') to be later called to when user interacts with the scene
	m_pRoot->setUserData(new Assignment::SelectionHandler(this));

	// Add a collision detector to the back of the car - can be used to stop cars hitting eachother
	//m_pCollisionTarget->addChild(new osg::ShapeDrawable(new osg::Sphere(osg::Vec3f(0.0f, 0.0f, 0.0f), 20.0f)));	// Disable this line to hide the collision sphere at the back of the car
	m_pCollisionTarget->setMatrix(osg::Matrix::translate(-110.0f, 0.0f, 0.0f));
	m_pAnimationTransform->addChild(m_pCollisionTarget);
}

Assignment::AnimatedCar::~AnimatedCar()
{
	if (m_pAnimationTransform) m_pAnimationTransform->unref();
	if (m_pCollisionTarget) m_pCollisionTarget->unref();
	if (m_pAnimationPathCallback) m_pAnimationPathCallback->unref();
	if (m_pCameraController) delete m_pCameraController;
}

void Assignment::AnimatedCar::setAnimationPath(osg::AnimationPath* pPath)
{
	// Assign animation path and set up a callback for it to loop through the path
	m_pAnimationPathCallback = new osg::AnimationPathCallback(pPath);
	m_pAnimationTransform->setUpdateCallback(m_pAnimationPathCallback);
}

// Callback function - called on each update traversal
bool Assignment::AnimatedCar::run(osg::Object* object, osg::Object* data)
{
	// Default state set to false (not colliding) before searching for collision
	m_bCurrentState = false;

	// Used to detect the world space position on the collision targets and text for inclusion in the detector volume
	// Get the world to local matrix for the collide volume to recalculate every call
	osg::Matrix mW2L = osg::computeWorldToLocal(m_pPosition->getParentalNodePaths(0)[0]);

	// Loop through all the facades to find those that implment the collision target interface, remember this is a map 
	for (Common::FacadeMap::iterator it = facades().begin(); it != facades().end(); it++)
	{
		// Use dynamic cast to determine whether this object implements the collision target interface
		if (TrafficSystem::CollisionTarget* pCT = dynamic_cast<TrafficSystem::CollisionTarget*>(it->second))
		{
			// Check for traffic light collision
			if (Assignment::ControllableTrafficLightFacade* pTrafficLightFacade = dynamic_cast<Assignment::ControllableTrafficLightFacade*>(pCT))
			{
				// Get world position collision point
				osg::Vec3f vTargetPosition = pTrafficLightFacade->getFacadeCollisionPoint();

				// Now we need to transfer the world position collision target to the frame of reference (coordinate system) for the collide volume
				vTargetPosition = vTargetPosition * mW2L;

				// Finally test to see if the collision target is inside the detector volume
				if (m_pGeode->getBoundingBox().contains(vTargetPosition))
				{
					// Detect light state
					if (pTrafficLightFacade->getState() == Assignment::ControllableTrafficLightFacade::STOP) {
						// Pause animation path
						m_bCurrentState = true;
						break;
					}
				}
				continue;
			}

			// Check for car collision
			if (AnimatedCar* pAnimatedCar = dynamic_cast<AnimatedCar*>(pCT)) {
				// Get world position collision point
				osg::Vec3f vTargetPosition = pCT->getFacadeCollisionPoint();

				// Now we need to transfer the world position collision target to the frame of reference (coordinate system) for the collide volume
				vTargetPosition = vTargetPosition * mW2L;

				// Finally test to see if the collision target is inside the detector volume
				if (m_pGeode->getBoundingBox().contains(vTargetPosition))
				{
					// Hit a car, set state to true
					m_bCurrentState = true;
					break;
				}
			}
		}
	}
	// Set the animation path state (paused if car is colliding)
	m_pAnimationPathCallback->setPause(m_bCurrentState);

	// Check the car has a camera assigned
	if (m_pCameraController)
	{
		osg::Matrixf m = osg::computeLocalToWorld(m_pAnimationTransform->getParentalNodePaths(0)[0]);
		m_pCameraController->setTransform(m);
	}

	return false;
}

osg::Vec3f Assignment::AnimatedCar::getFacadeCollisionPoint()
{
	osg::Vec3f t, s;
	osg::Quat r, sr;
	// get the path, from the position target to the root, and decompose the resultant matrix to get the world position of the collision target
	osg::computeLocalToWorld(m_pCollisionTarget->getParentalNodePaths(0)[0]).decompose(t, r, s, sr);
	return t;
}


float Assignment::AnimatedCar::addControlPoint(std::string sTile, std::string sPoint, osg::AnimationPath* pPath, float fTime, float fSpeed, osg::Vec3f& rvLastPos, bool bFirst = false)
{
	//find the facade for the tile we want
	Common::Facade* pF = Common::Facade::findFacade(sTile);

	// setup finder to look for animation point
	Common::NodeFinderT<osg::MatrixTransform> finder(sPoint);

	// use finder to find point in the tile
	if (osg::MatrixTransform* pMT = finder.find(pF->root()))
	{
		// find all the routes between the found anaimation point and the scene root
		// remember there could be many as we have re-used this bit of geometry. We need the one that passes through the root node of this facade
		osg::NodePathList npl = pMT->getParentalNodePaths(0);

		// loop through all of the node paths we have found
		for (osg::NodePathList::iterator it = npl.begin(); it != npl.end(); it++)
		{
			// test to see of the current node path is the one that passes through the facade we are considering now
			if (std::find(it->begin(), it->end(), pF->root()) != it->end())
			{
				//we now have the correct route for the animation point we are using

				// calulate the local to world matrix for this route
				osg::Matrix m = osg::computeLocalToWorld(*it);

				//decompose the matrix to get the world translation	and rotation
				osg::Vec3f t, s;
				osg::Quat r, sr;
				m.decompose(t, r, s, sr);

				// if this is not the first control point calculate the time needed to move from the last position
				if (!bFirst)
				{
					float fDistance = (t - rvLastPos).length();
					fTime += fDistance / fSpeed;
				}

				// update the last position - remember this has been passed by reference so we can updated in this function
				rvLastPos = t;

				// add the control point to the animation path
				pPath->insert(fTime, osg::AnimationPath::ControlPoint(t, r));

				// return the updated time 
				return fTime;
			}
		}
	}
	return fTime;
}

void Assignment::AnimatedCar::setCameraController(CameraController* pCC)
{
	// Assign the camera
	m_pCameraController = pCC;
}

Assignment::CameraController* Assignment::AnimatedCar::getCameraController()
{
	// Return the camera type
	return m_pCameraController;
}

void Assignment::AnimatedCar::setAnimationSpeed(float fSpeed)
{
	// Set the animation speed
	m_fAnimationSpeed = fSpeed;
}

float Assignment::AnimatedCar::getAnimationSpeed()
{
	// Return animation speed
	return m_fAnimationSpeed;
}
