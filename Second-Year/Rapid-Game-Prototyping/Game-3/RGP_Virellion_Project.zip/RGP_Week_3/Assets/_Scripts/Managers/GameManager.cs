using Newtonsoft.Json.Bson;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager instance;
    public static GameState currentGameState;
    private GameState previousState;

    [Header("Damage Pop-up Properties:")]
    public GameObject damagePopupPrefab;
    public Transform popupParent;

    private void Awake()
    {
        // Singleton
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
        // Set game state
        currentGameState = GameState.Start;
    }

    #region Private Game State Methods
    public static void StartGame()
    {
        currentGameState = GameState.Active;
    }
    public void RestartGame()
    {
        // Reload the current scene
        Time.timeScale = 1;
        // Load first scene
        SceneManager.LoadScene(0);
    }
    public void PauseGame()
    {
        // Pause game and display pause menu
        currentGameState = GameState.Paused;
        Time.timeScale = 0;
        UIManager.instance.pauseMenu.SetActive(true);
        Cursor.visible = true;
    }
    public void ResumeGame()
    {
        // Hide pause menu and resume game
        currentGameState = GameState.Active;
        UIManager.instance.pauseMenu.SetActive(false);
        Time.timeScale = 1;
        Cursor.visible = false;
    }
    public void EndGame()
    {
        AudioManager.instance.Play("GameOver");
        currentGameState = GameState.End;
        UIManager.instance.gameOverMenu.SetActive(true);
        Time.timeScale = 0;
        Cursor.visible = true;
    }
    public static void QuitGame()
    {
        Application.Quit();
    }
    #endregion

    public enum GameState
    {
        Start,
        Restart,
        Active,
        Paused,
        Resume,
        End
    }
}
