using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerSize : MonoBehaviour
{
    public bool isSmall = false;
    public float scaleSpeed = 1f;
    public Vector3 smallSize;
    public Vector3 largeSize;

    private void Update()
    {
        if (isSmall)
        {
            transform.localScale = Vector3.Lerp(transform.localScale, smallSize, scaleSpeed * Time.deltaTime);
        } else
        {
            transform.localScale = Vector3.Lerp(transform.localScale, largeSize, scaleSpeed * Time.deltaTime);
        }
    }
}
