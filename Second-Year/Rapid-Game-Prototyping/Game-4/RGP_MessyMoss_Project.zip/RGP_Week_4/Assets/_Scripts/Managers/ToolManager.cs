using System;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.SearchService;
using UnityEngine.Tilemaps;

public class ToolManager : MonoBehaviour
{
    public static ToolManager instance;

    [Header("Mouse tilemap properties:")]
    [SerializeField] private Tilemap mouseTilemap;
    [SerializeField] private Tile hoverTile;
    private Vector3Int prevMousePosition;
    public RaycastHit2D hit;
    Vector3 mousePosition;
    public Vector3Int mouseTilemapPos;

    [Header("Tools:")]
    [SerializeField] private string[] toolsArray;
    [SerializeField] private string selectedTool;
    private bool canUseTool = true;
    private string previousTool;

    [Header("Tool Scripts:")]
    [SerializeField] private MagnifyingGlass handScript;
    [SerializeField] private DiggingTools diggingScript;
    private const string handTag = "Hand";
    private const string shovelTag = "Shovel";
    private const string hammerTag = "Hammer";

    // Getters
    public string GetHandTag() { return handTag; }
    public string GetShovelTag() { return shovelTag; }
    public string GetHammerTag() { return hammerTag; }
    public bool GetCanUseTool() { return canUseTool; }
    // Setters
    public void SetCanUseTool(bool canUse) { canUseTool = canUse; }

    private void Awake()
    {
        // Singleton
        if (instance == null)
        {
            instance = this;
        } else
        {
            Destroy(gameObject);
        }
        // Get components
        handScript = gameObject.GetComponent<MagnifyingGlass>();
    }

    private void Update()
    {
        // Shortcuts for tools
        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            // Hand Tool
            SelectNewToolByName("Hand");
        } else if (Input.GetKeyDown(KeyCode.Alpha2))
        {
            // Shovel
            SelectNewToolByName("Shovel");
        }
        else if (Input.GetKeyDown(KeyCode.Alpha3))
        {
            // Hammer
            SelectNewToolByName("Hammer");
        }

        // Raycast2D Mouse
        hit = Physics2D.Raycast(Camera.main.ScreenToWorldPoint(Input.mousePosition), Vector2.zero);

        // Mouse position to world and tile cell
        mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        mouseTilemapPos = mouseTilemap.WorldToCell(mousePosition);

        // Display outline tile on mouse position
        DisplayMouseHover();

        // Deselect all tools when tool is changed
        if (previousTool != selectedTool)
        {
            DeselectAllTools();
            previousTool = selectedTool;

            // Select new tool
            if (selectedTool == shovelTag || selectedTool == hammerTag || selectedTool == handTag)
            {
                diggingScript.enabled = true;
                diggingScript.SetSelectedTool(selectedTool);
            }
            else
            {
                DeselectAllTools();
            }
        }
    }

    private void DeselectAllTools()
    {
        diggingScript.DisableScript();
    }

    private void DisplayMouseHover()
    {
        // Display hover tile when mouse is inside magnifying glass
        if (hit.collider == null) { return; }
        if (hit.collider.CompareTag("Frame") || hit.collider.CompareTag("Frame Background"))
        {
            // Remove hover tile, if mouse is on frame/magnifying glass
            mouseTilemap.SetTile(prevMousePosition, null);
        }
        else
        {
            // Display tile on tilemap at new position
            if (!mouseTilemapPos.Equals(prevMousePosition))
            {
                mouseTilemap.SetTile(prevMousePosition, null);
                mouseTilemap.SetTile(mouseTilemapPos, hoverTile);
                prevMousePosition = mouseTilemapPos;
            }
        }
    }

    public void SelectNewToolByName(string _newTool)
    {
        // Select a new tool by name 
        string selectNewTool = Array.Find(toolsArray, tool => tool == _newTool);
        if (selectNewTool != null)
        {
            selectedTool = selectNewTool;
        } else
        {
            Debug.Log(String.Format("Tool '{0}' is not found!", _newTool));
        }
    }

    public void SelectNewToolByIndex(int _index)
    {
        // Select new tool by index (within range)
        if (_index >= 0 && _index < toolsArray.Length)
        {
            selectedTool = toolsArray[_index];
        } else
        {
            Debug.Log(String.Format("Tool index '{0}' is out of range!", _index));
        }
    }
}
