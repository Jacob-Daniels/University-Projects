using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MouseLook : MonoBehaviour
{
    public float mouseSensitivity = 400f;
    public Transform playerBody;
    float xRotation = 0f;
    [SerializeField] private Slider sensitivitySlider;

    private void Awake()
    {
        sensitivitySlider.value = mouseSensitivity;
    }

    void Start()
    {
        // Hide & Lock cursor
        Cursor.lockState = CursorLockMode.Locked;
    }

    void Update()
    {
        // Get mouse input
        float mouseX = Input.GetAxis("Mouse X") * mouseSensitivity * Time.deltaTime;
        float mouseY = Input.GetAxis("Mouse Y") * mouseSensitivity * Time.deltaTime;

        // Mouse Y movement
        xRotation -= mouseY;
        xRotation = Mathf.Clamp(xRotation, -90f, 90f); // Clamp rotation
        transform.localRotation = Quaternion.Euler(xRotation, 0f, 0f);

        // Mouse X movement
        playerBody.Rotate(Vector3.up * mouseX);
    }

    public void SensitivitySlider(float value)
    {
        // Set sensitivity with slider
        mouseSensitivity = value;
    }
}
