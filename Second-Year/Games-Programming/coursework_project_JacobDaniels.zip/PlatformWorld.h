#pragma once
#include <SFML/Graphics.hpp>
#include <string>
#include "Collision.h"
#include "PlatformController.h"
#include "Input.h"
#include <random>

class PlatformWorld
{
	Collision physics;
	unique_ptr<PlatformController> controller;
	Input input;
	vector<sf::RectangleShape> sprites;
public:
	PlatformWorld() 
	{
		controller = make_unique<PlatformController>(sf::Vector2f(200, 300), sf::Vector2f(32,32), sf::Vector2f(0, 600));
	};

	int CountPlatformPixels()
	{
		int numPlatforms = sprites.size();
		int count = 0;
		for (int i = 0; i < sprites.size(); i++)
			count += sprites[i].getSize().x * sprites[i].getSize().y;
		return count;
	}
	void AddPlatform(const sf::Vector2f& pos, const sf::Vector2f& size)
	{
		// add a collider to the physics world
		physics.AddStaticCollider(pos, size);
		// add a graphics sprite
		sprites.push_back(sf::RectangleShape(size));
		sprites[sprites.size() - 1].setPosition(pos);
		sprites[sprites.size() - 1].setFillColor(sf::Color(200, 40, 0, 255));
	}

	void Update(float dt)
	{
		input.Update();
		controller->Update(dt, physics, input);
	}

	void Draw(sf::RenderWindow& window)
	{
		for (auto s : sprites)
			window.draw(s);
		controller->Draw( window );
	}
};