using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;
using UnityEngine.UIElements;

[System.Serializable]
public class TileProperties
{
    public Tile tile;
    public Sprite sprite;
    public string name;
    public int maxSpawn;
    public int minSpawn;
    public int totalspawn;
    public bool canRotate;
    public bool maxCollectable;
}
