#pragma once

#include <windows.h>
#include <osgGA/GUIEventHandler>
#include <Assignment/CameraController.h>
#include <Assignment/ShaderController.h>
#include <Assignment/LightCycleController.h>

typedef void (KEY_FUNC)(char c);

class InteractionHandler : public osgGA::GUIEventHandler
{
public:
	InteractionHandler(KEY_FUNC* pFunc, Assignment::CameraController* pCamController, Assignment::ShaderController* pShaderController, Assignment::LightCycleController* pLightCycleController);
	virtual ~InteractionHandler();
	virtual bool handle(const osgGA::GUIEventAdapter& ea, osgGA::GUIActionAdapter& aa, osg::Object*, osg::NodeVisitor*);

protected:
	KEY_FUNC* m_pFunc;
	Assignment::CameraController* m_pCameraController;
	Assignment::ShaderController* m_pShaderController;
	Assignment::LightCycleController* m_pLightCycleController;
};
