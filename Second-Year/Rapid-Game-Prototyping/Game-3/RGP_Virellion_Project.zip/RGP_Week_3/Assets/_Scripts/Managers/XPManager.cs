using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class XPManager : MonoBehaviour
{
    public static XPManager instance;

    [Header("Upgrades Properties:")]
    [SerializeField] private GameObject upgradePanel;

    [Header("XP Properties:")]
    [SerializeField] private int currentLevel = 2;
    [SerializeField] private float currentXP;
    [SerializeField] private float nextLevelXP;
    [SerializeField] private float xpMultiplier;
    [SerializeField] private int totalUpgrades = 3;
    public void DecreaseTotalUpgrades() { totalUpgrades--; }

    private void Awake()
    {
        // Singleton
        if (instance == null)
        {
            instance = this;
        } else
        {
            Destroy(gameObject);
        }
    }

    public void AddXP(float addXP)
    {
        // Increase xp
        currentXP += addXP;
        // Check to level up
        if (currentXP >= nextLevelXP && totalUpgrades > 0)
        {
            AudioManager.instance.PlayRandomPitch("UpgradeMenu", 1, 2);
            LevelUp();
        }
    }

    private void LevelUp()
    {
        Cursor.visible = true;
        Time.timeScale = 0;
        upgradePanel.SetActive(true);
        // Set xp for next level
        nextLevelXP += ((int)Mathf.Floor((currentLevel - 1) + (300.0f * Mathf.Pow(2.0f, (currentLevel - 1) / 7.0f)))) / 4;
        currentLevel++;
        //nextLevelXP = (nextLevelXP * xpMultiplier) + TimeManager.instance.GetTime();
        //nextLevelXP += nextLevelXP * xpMultiplier;
    }

    public void LeveledUp()
    {
        // Close ui upon leveling up
        upgradePanel.SetActive(false);
        Cursor.visible = false;
        Time.timeScale = 1;
    }
}
