#pragma once

#include <windows.h>
#include <osgViewer/Viewer>
#include <osgViewer/CompositeViewer>
#include "AnimatedCar.h"


namespace Assignment {

	class AnimatedCar;

	class CameraController
	{
	public:
		CameraController(osgViewer::CompositeViewer* compositeViewer, osg::View* view);
		virtual ~CameraController();

		void toggleCamera(AnimatedCar* clickedCar);

		void setTransform(osg::Matrixf& m);

	protected:
		AnimatedCar* m_pSelectedCar;
		osgViewer::CompositeViewer* m_pCompositeViewer;
		osg::View* m_pCameraView;
	};
}