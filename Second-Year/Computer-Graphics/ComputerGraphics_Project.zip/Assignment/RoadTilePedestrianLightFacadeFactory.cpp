#include "RoadTilePedestrianLightFacadeFactory.h"
#include "RoadTilePedestrianLightFacade.h"

Assignment::RoadTilePedestrianLightFacadeFactory::RoadTilePedestrianLightFacadeFactory()
{
}

Assignment::RoadTilePedestrianLightFacadeFactory::~RoadTilePedestrianLightFacadeFactory()
{
}

Common::Facade* Assignment::RoadTilePedestrianLightFacadeFactory::create(std::string sName, osg::Node* pModelRoot, osg::Matrixf rTransform, bool bVisible)
{
	return new Assignment::RoadTilePedestrianLightFacade(sName, pModelRoot, rTransform, bVisible);
}
