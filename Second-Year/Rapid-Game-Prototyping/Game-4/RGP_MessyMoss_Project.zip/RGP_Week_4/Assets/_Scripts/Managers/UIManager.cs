using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{
    public static UIManager instance;
    [Header("Pause Properties:")]
    [SerializeField] private GameObject pausePanel;
    [SerializeField] private bool isPaused;

    [Header("Tool Panel Properties:")]
    [SerializeField] private RectTransform[] panels;
    [SerializeField] private RectTransform toolsPanel;
    [SerializeField] private Transform mgTilemap;

    [Header("Collectable Panel Properties:")]
    [SerializeField] private Transform[] collectableContainers;
    [SerializeField] private TextMeshProUGUI tasksCompletedText;
    [SerializeField] private GameObject taskCompleteMessage;
    [SerializeField] private float taskCompleteTimer;
    [SerializeField] private float taskScale;
    bool scaleDir;

    [Header("Personalise Panel Properties:")]
    [SerializeField] private Image frameImage;
    [SerializeField] private Image frameBackgroundImage;
    [SerializeField] private FrameType[] frames;
    [SerializeField] private FrameType[] frameBackgrounds;
    [SerializeField] private int frameIndex;
    [SerializeField] private int frameBackgroundIndex;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        } else
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        UpdateCollectableUI();
    }

    private void Update()
    {
        // Flip panel position depending on position of magnifying glass
        if (mgTilemap.position.x > 3)
        {
            foreach (RectTransform panel in panels)
            {
                panel.offsetMin = new Vector2(-5, panel.offsetMin.y);
                panel.offsetMax = new Vector2(-1500, panel.offsetMax.y);
            }
        }
        else if (mgTilemap.position.x < -3)
        {
            foreach (RectTransform panel in panels)
            {
                panel.offsetMin = new Vector2(1500, panel.offsetMin.y);
                panel.offsetMax = new Vector2(5, panel.offsetMax.y);
            }
        }

        // Pause game
        if (Input.GetKeyDown(KeyCode.Escape) || Input.GetKeyDown(KeyCode.P))
        {
            if (pausePanel.activeSelf)
            {
                pausePanel.SetActive(false);
            } else
            {
                pausePanel.SetActive(true);
            }
        }

        // Task Complete timer
        if (taskCompleteTimer >= 0)
        {
            if (!scaleDir)
            {
                if (taskScale > 1.5f) { scaleDir = true; } 
                // Make text larger
                taskScale += Time.deltaTime;
            } else
            {
                if (taskScale < 0.5f) { scaleDir = false; }
                // Make text smaller
                taskScale -= Time.deltaTime;
            }
            taskCompleteTimer -= Time.deltaTime;
            taskCompleteMessage.transform.position = Camera.main.WorldToScreenPoint(MagnifyingGlass.instance.mgTilemap.position);
            taskCompleteMessage.transform.localScale = new Vector3(taskScale, taskScale, 1f);
        }
        else
        {
            taskCompleteMessage.SetActive(false);
        }
    }

    public void DisplayTaskCompleteMessage()
    {
        // Display well done message on screen when a task is completed
        taskCompleteMessage.SetActive(true);
        taskCompleteTimer = 2f;
        taskScale = 0.5f;
    }

    public void UpdateCollectableUI()
    {
        // Collectable List
        int numCollectables = CollectableManager.instance.collectablesList.Count;
        for (int i = 0; i < 4; i++)
        {
            if (i < numCollectables)
            {
                // Grab current collectable from loop iteration
                Collectable currentCollectable = CollectableManager.instance.collectablesList[i];
                // Set properties of collectable
                collectableContainers[i].GetChild(0).GetComponent<Image>().sprite = currentCollectable.sprite;
                collectableContainers[i].GetChild(1).GetComponent<TextMeshProUGUI>().text = currentCollectable.name;
                // Calculate total remaining
                int toCollect = currentCollectable.maxCollection - currentCollectable.totalCollected;
                string stackText;
                if (toCollect <= 0)
                {
                    stackText = "Complete!";
                } else
                {
                    stackText = toCollect.ToString() + " remaining";
                }
                collectableContainers[i].GetChild(2).GetComponent<TextMeshProUGUI>().text = stackText;
                // Set Alpha
                collectableContainers[i].GetChild(0).GetComponent<Image>().color = new Color(255, 255, 255, 1);
                collectableContainers[i].GetChild(1).GetComponent<TextMeshProUGUI>().color = new Color(255, 255, 255, 1);
                collectableContainers[i].GetChild(2).GetComponent<TextMeshProUGUI>().color = new Color(255, 255, 255, 1);
            } else
            {
                // Hide element
                collectableContainers[i].GetChild(0).GetComponent<Image>().color = new Color(255, 255, 255, 0);
                collectableContainers[i].GetChild(1).GetComponent<TextMeshProUGUI>().color = new Color(255, 255, 255, 0);
                collectableContainers[i].GetChild(2).GetComponent<TextMeshProUGUI>().color = new Color(255, 255, 255, 0);
            }
        }
        // Tasks completed
        tasksCompletedText.text = CollectableManager.instance.tasksCompleted.ToString();
    }
    public void IncreaseFrameIndex()
    {
        // Disable old frame and enable new
        frames[frameIndex].frame.SetActive(false);
        if (frameIndex == frames.Length - 1)
        {
            frameIndex = 0;
        } else
        {
            frameIndex++;
        }
        frames[frameIndex].frame.SetActive(true);
        // Display frame sprite
        frameImage.sprite = frames[frameIndex].sprite;
    }
    public void DecreaseFrameIndex()
    {
        // Disable old frame and enable new
        frames[frameIndex].frame.SetActive(false);
        if (frameIndex == 0)
        {
            frameIndex = frames.Length - 1;
        } else
        {
            frameIndex--;
        }
        frames[frameIndex].frame.SetActive(true);
        // Display frame sprite
        frameImage.sprite = frames[frameIndex].sprite;
    }
    public void IncreaseFrameBackgroundIndex()
    {
        // Disable old frame and enable new
        frameBackgrounds[frameBackgroundIndex].frame.SetActive(false);
        if (frameBackgroundIndex == frameBackgrounds.Length - 1)
        {
            frameBackgroundIndex = 0;
        }
        else
        {
            frameBackgroundIndex++;
        }
        frameBackgrounds[frameBackgroundIndex].frame.SetActive(true);
        // Display frame sprite
        frameBackgroundImage.sprite = frameBackgrounds[frameBackgroundIndex].sprite;
    }
    public void DecreaseFrameBackgroundIndex()
    {
        // Disable old frame and enable new
        frameBackgrounds[frameBackgroundIndex].frame.SetActive(false);
        if (frameBackgroundIndex == 0)
        {
            frameBackgroundIndex = frameBackgrounds.Length - 1;
        }
        else
        {
            frameBackgroundIndex--;
        }
        frameBackgrounds[frameBackgroundIndex].frame.SetActive(true);
        // Display frame sprite
        frameBackgroundImage.sprite = frameBackgrounds[frameBackgroundIndex].sprite;
    }

    public void MuteMusicButton()
    {
        AudioManager.instance.MuteBackgroundMusic();
    }
    public void MuteEffectsButton()
    {
        AudioManager.instance.MuteSoundEffects();
    }
}
