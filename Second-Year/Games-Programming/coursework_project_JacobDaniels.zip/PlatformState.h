#pragma once
#include "PlatformController.h"
class PlatformController;

// States
class PlatformState {
protected:
	PlatformController& player;
	float frameCounter;
public:
	PlatformState(PlatformController& player) : player(player) {}
	virtual PlatformState* Update(float dt, Input input) = 0;
};

// Idle
class IdleState : public PlatformState {
public:
	IdleState(PlatformController& player);
	virtual PlatformState* Update(float dt, Input input) override;
};

// Walking state
class WalkState : public PlatformState {
public:
	WalkState(PlatformController& player);
	virtual PlatformState* Update(float dt, Input input) override;
};

// Jump state
class JumpState : public PlatformState {
public:
	JumpState(PlatformController& player);
	virtual PlatformState* Update(float dt, Input input) override;
};

// Falling State (In air)
class FallingState : public PlatformState {
public:
	FallingState(PlatformController& player);
	virtual PlatformState* Update(float dt, Input input) override;
};